//get allspace
var parkingSpaceForAdmin ={ 
    addres: process.env.REACT_APP_ADMIN_BACKEND_URL+"/getAllParkingSpace "
    ,result:[{'id':"",'space_no':"",'type':"",'enabled':""},["it will be in array of dict format"]]
    //[{"id":1,"space_no":101,"type":2,"enabled":false},{"id":2,"space_no":102,"type":4,"enabled":false}]
    ,
    method:"get"
    ,
    requiredData:"",
    additional:"if enabled false then it should be shown in gray else normal if enbled is true give disable button else enable button "
}

//enbable disable
var parkingSpaceStatusForAdmin ={ 
    addres: process.env.REACT_APP_ADMIN_BACKEND_URL+"/updateParkingSpaceStatus "
    ,result:["response will be sucessflly enabled if status is true or disabled if status is false",[" string data will be retuned "]]
    // sucessfully disabled parking space  for status false
//sucessfully enabaled parking space for true
//invalid status value if wrong status sent
//space data not found if wrong id sent
    ,
    method:"post"
    ,
    requiredData:{id:column_id,status:"false for disabling or true for enabling"},
    additional:"update the data in state using sent data  to api, in then block  update the record  where id is equal to sent id"
}

//Add
var addParkingSpaceAdmin ={ 
    addres: process.env.REACT_APP_ADMIN_BACKEND_URL+"/addParkingSpace"
    ,result:["it will send new entry",[" response will be a dict "]]
    //parking space number exists! if duplicate space no
    //
    //something went wrong if error or data not sent error
    // sucessfull 
    // {
    //     "enabled": true,
    //     "createdAt": "2024-07-05T17:40:33.209Z",
    //     "updatedAt": "2024-07-05T17:40:33.209Z",
    //     "id": 1,
    //     "type": 2,
    //     "space_no": "444"
    // }
    ,
    method:"post"
    ,
    requiredData:{space_no:"10 char",type:"2 or 4 from dropdown",},
    additional:"add the retuned entry to existing space data"
}

//edit
var addParkingSpaceAdmin ={ 
    addres: process.env.REACT_APP_ADMIN_BACKEND_URL+"/editaParkingSpace"
    ,result:["it will send edited entry",[" response will be a dict "]]
    // {
    //     "id": 2,
    //     "space_no": "4444",
    //     "type": 4,
    //     "enabled": true,
    //     "createdAt": "2024-07-05T18:30:42.000Z",
    //     "updatedAt": "2024-07-05T18:30:42.000Z"
    // }
    ,
    method:"post"
    ,
    requiredData:{id:"column id"  ,space_no:"10 char",type:"2 or 4 from dropdown",},
    // {
   
    //     "id":2,
    //     "space_no":"444",
    //     "type":4
    //  }
    //send all data while sending change the data which is edited if its not edited keep it default value
    additional:"find the edited in state and edit itwith new value"
}


//get slot
var getSlot={
 api:"/getSlot",
 method:"post"
    ,
requiredDataid:{
   
    "entryTime":"Tue, 16 Jul 2024 01:11:00 GMT",
    "exitTime":"Fri, 19 Jul 2024 13:54:00 GMT",
     "vehicleType":4,
     "vehicleId":2,
     "userId":16
 
 }
}
if ("slotavailable")
{
var res={
    "entryTime": "2024-07-19T14:11:00.000Z",
    "exitTime": "2024-07-19T13:54:00.000Z",
    "space_id": 4,
    "bookingSlotFile": "./bookings/0c361e09-51c4-451f-835c-17e8ce1760fb.json"
}
}
else{
//  slot not available ....error

}




var generateOrder={
    api:"/generateOrder",
    method:"post",
    requiredData:
        {
   
            "amount":500,
            "bookingSlotFile": "./bookings/f184b176-11de-460c-b3c7-482c7cce1268.json"
        },
    
    respose:{
    "id": "order_OWBrYkbeBSp76J",
    "amount": 500,
    "currency": "INR",
    "status": "created",
    "bookingSlotFile": "./bookings/f184b176-11de-460c-b3c7-482c7cce1268.json"
}
}


var RESERVE={api:"/reserve",
requiredData:{
   
    
    "bookingSlotFile": "./bookings/aa8afdd4-affb-47d5-969f-7a521894ca9c.json",
    "paymentDetail":{"orderId":3666,"test":"55"} //data recived after payment
}
}

response:"slot booked sucessfullly"



//userId from auth
axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/getVehicle",{customerId:userId},{
    headers: {
      'Content-Type': 'application/json',
    }
    }).then((response)=>{
    
    // setVehicleData(response.data)
   
    
    }).catch((err)=>{

      toast.error("something went wrong")

})




  mybookings={
    api:process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/mybookings",
    method:"post"
    ,
    requiredData:{id:"userid"}, //userid from auth context
    result:"array of dicts"
  }
  //method to devide date and time

  date:reservationEntryTime.toISOString().split('T')[0]
  time:reservationEntryTime.toISOString().split('T')[1]
 //   response  [
//     {
//         "reservation": {
//             "id": 1,
//             "space_id": 1,
//             "customer_id": 2,
//             "vehicle_id": 2,
//             "reservation_entry_time": "2024-05-10T05:00:00.000Z",
//             "reservation_exit_time": "2024-05-10T10:00:00.000Z"
//         },
//         "vehicle": {
//             "licenceNo": "licence",
//             "vehicleType": "4",
//             "color": "red"
//         },
//         "parkingSpace": {
//             "id": 1,
//             "space_no": "444",
//             "type": 2
//         },
//         "payment": {}
//     },
//     {
//         "reservation": {
//             "id": 2,
//             "space_id": 1,
//             "customer_id": 2,
//             "vehicle_id": 13,
//             "reservation_entry_time": "2024-05-10T05:00:00.000Z",
//             "reservation_exit_time": "2024-05-10T05:00:00.000Z"
//         },
//         "vehicle": {
//             "licenceNo": "df",
//             "vehicleType": "4",
//             "color": "purple"
//         },
//         "parkingSpace": {
//             "id": 1,
//             "space_no": "444",
//             "type": 2
//         },
//         "payment": {}
//     }
// ]

















//model method "ADD" for adding
//   <AddVehicleModal setVehicleData={setVehicleData} Vehicledata={Vehicledata}setModalState={setModalState} ModalState={modalState}  method={modalMethod} defaultValue={vehicleModalValue}/>
     




// {
//     "development": {
//       "username": "root",
//       "password": "Veeraj@27",
//       "database": "parking_lot_management_system",
//       "host": "localhost",
//       "dialect": "mysql"
//     },
//     "test": {
//       "username": "root",
//       "password": "Veeraj@27",
//       "database": "parking_lot_management_system",
//       "host": "localhost",
//       "dialect": "mysql"
//     },
//     "production": {
//       "username": "root",
//       "password": "Veeraj@27",
//       "database": "parking_lot_management_system",    
//       "host": "localhost",
//       "dialect": "mysql"
//     }
//   }
  


// sql statement to set space availability to availale

// UPDATE parking_lot_management_system.space_availability
// SET `1AM` = true,
//     `2AM` = true,
//     `3AM` = true,
//     `4AM` = true,
//     `5AM` = true,
//     `6AM` = true,
//     `7AM` = true,
//     `8AM` = true,
//     `9AM` = true,
//     `10AM` = true,
//     `11AM` = true,
//     `12AM` = true,
//     `1PM` = true,
//     `2PM` = true,
//     `3PM` = true,
//     `4PM` = true,
//     `5PM` = true,
//     `6PM` = true,
//     `7PM` = true,
//     `8PM` = true,
//     `9PM` = true,
//     `10PM` = true,
//     `11PM` = true,
//     `12PM` = true
// WHERE id != null