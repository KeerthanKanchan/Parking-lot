import React from "react";

function FeatureCardComponent(props) {
    if (props.reverse){
        return (
            <div className="feature-card-reverse">
                <div className="card-image">
                    <img src={props.image} alt="feature-img"/>
                </div>
                <div className="card-body">
                    <h3>{props.title}</h3>
                    <p>{props.description}</p>
                </div>
            </div>
            );
    } else {
        return (
        <div className="feature-card">
            <div className="card-image">
                <img src={props.image} alt="feature-img"/>
            </div>
            <div className="card-body">
                <h3>{props.title}</h3>
                <p>{props.description}</p>
            </div>
        </div>
        );
    }
}

export default FeatureCardComponent;
