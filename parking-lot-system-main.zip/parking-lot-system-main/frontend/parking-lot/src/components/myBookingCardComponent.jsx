import React from "react";
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { red } from "@mui/material/colors";
import { Button, Divider } from "@mui/material";
import LocalParkingIcon from '@mui/icons-material/LocalParking';
import parkingIcon from '../assets/images/parking-car.png';
import entryIcon from '../assets/images/entry.png';
import exitIcon from '../assets/images/exit.png';
import { Link, useNavigate } from "react-router-dom";



export default function MyBookingCardComponent(props) {

    const navigate = useNavigate();

    function getDetails(){
        localStorage.setItem('invoiceDetails', JSON.stringify(props.bookingDetails));
        navigate('/invoice');
    }
    const now = new Date();
    return (
        <Card sx={{ display: 'flex', flexDirection:'column', borderRadius: '10px', bgcolor: 'red', m:2}}>
            <Box sx={{ display: 'flex', justifyContent:'space-between', width: '100%', alignItems: 'center', bgcolor: 'white'}}>
                <CardContent sx={{ bgcolor:red}}>
                    <Typography component="div" variant="caption">
                        Entry
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                        {props.entryTime}
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                        {props.entryDate}
                    </Typography>
                </CardContent>
                
                <CardContent  sx={{textAlign: "center"}}>
                    <Typography component="div" variant='caption'>
                        Vehicle
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                        {props.vehicleNumber}
                    </Typography>
                  
                    <Typography component="div" variant="caption">
                        Parking spot
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                        {props.parkingSpace}
                    </Typography>
                </CardContent>

                <CardContent sx={{textAlign: "end"}}>
                    <Typography component="div" variant="caption">
                        Exit
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                        {props.exitTime}
                    </Typography>
                    <Typography variant="subtitle1" component="div">
                    {props.exitDate}
                    </Typography>
                </CardContent>
            </Box >
            <Box sx={{display: 'flex', pl: 4, pr:4, alignItems:'center', bgcolor: 'white',  position:'relative', justifyContent: 'space-between'}}>
                <img src={entryIcon} alt="parking-img" style={{height:'40px', width:'40px', display:"inline"}}/>
                <Divider  style={{width: '30%', backgroundColor: '#1F2833'}}/>
                <img src={parkingIcon} alt="parking-img" style={{height:'40px'}}/>
                <Divider style={{width: '30%', backgroundColor: '#1F2833'}}/>
                <img src={exitIcon} alt="parking-img" style={{height:'40px', width:'40px'}}/>

            <Box sx={{width:'20px', height: '20px', borderRadius: '100px', bgcolor:'#1F2833', position: 'absolute', top: '10px', right: '-10px'}} />
            <Box sx={{width:'20px', height: '20px', borderRadius: '100px', bgcolor:'#1F2833', position: 'absolute', top: '10px', left: '-10px'}} />
            </Box>

            <Box sx={{ display: 'flex', justifyContent:'space-between', width: '100%', pt: 1, pb:1, bgcolor: 'white'}}>
                <Typography variant="subtitle1"  sx={{pl: 2}}>
                        ₹{props.price}
                </Typography>
                <Typography variant="subtitle1" component="div">
                        RESRV-{props.parkingId}
                    </Typography>
                <Typography variant="subtitle1" sx={{pr: 2}}>
               
                   <Button onClick={getDetails}>Invoice</Button>
                   
                </Typography>
            </Box>
        </Card>
    );
}