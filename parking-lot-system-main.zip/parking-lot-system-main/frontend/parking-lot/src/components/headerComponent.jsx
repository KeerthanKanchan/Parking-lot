import * as React from "react";
import PropTypes from "prop-types";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import Avatar from "@mui/material/Avatar";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../services/auth/authContext";
import { fontWeight } from "@mui/system";
import ManagePriceModal from "./managePriceModal";
// import useMediaQuery from "@mui/material/useMediaQuery";
// import { useTheme } from "@mui/material/styles";


function NavbarComponent() {

  const {isAuthenticated,logout,userId, userRole} = useAuth();
  // const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [anchorElUser, setAnchorElUser] = React.useState(null);
  const[profileIcon, setProfileIcon]= React.useState("/static/images/avatar/2.jpg")
  const [selectedItem, setSelectedItem] = React.useState("Home");
  var [modalState,setModalState]=React.useState(false)
  var navigate=useNavigate();

  const drawerWidth = 240;
  // const navItems = ["Home", "Book", "My Bookings"]
  const navItems = isAuthenticated ? userRole === 'CUSTOMER' ? [
    {text: "Home", textLink: "/"},
    {text: "Book", textLink: "/booking"},
    {text: "My Bookings", textLink: "/my-bookings"},
    {text: "Contact Us", textLink: "/contact-us"},
    {text: "About Us", textLink: "/about-us"}
  ] : [ 
    {text: "Dashboard", textLink: "/dashboard"},
    {text: "Entry/Exit", textLink: "/entryexit"},
    {text: "Manage Space", textLink: "/manageSpace"},
    {text: "Reservations", textLink: "/reservation"},
    {text: "Report", textLink: "/report"},
    {text: "Contact Us", textLink: "/contact-us"},
    {text: "About Us", textLink: "/about-us"}
  ] : [
    {text: "Home", textLink: "/"},
    {text: "Contact Us", textLink: "/contact-us"},
    {text: "About Us", textLink: "/about-us"}
  ];


  const settings = isAuthenticated ? userRole=="ADMIN"? [ "Helpline","manage price",  "Logout"]:["Profile", "Helpline",  "Logout"] : [,"LogIn"];

  React.useEffect(()=>{
   
    if(isAuthenticated)
      {
        axios.post(process.env.REACT_APP_COMMON_BACKEND_URL+"/profile",{id:userId},{
          headers: {
            'Content-Type': 'application/json',
          }
        }).then((response)=>{
        
          setProfileIcon(`data:image/jpeg;base64,${response.data}`)
          
        }).catch((err)=>{ 
          console.error("Failed to fetch profile icon", err);
        })
      }
      else{
        setProfileIcon("/static/images/avatar/2.jpg")
      }
    },[isAuthenticated])
    
  // const theme = useTheme();
  // const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const handleNavMenuItems=(textLink, text)=>{
      setSelectedItem(text)
    
      navigate(textLink);

     
     
    }

  const handleSettingMenuItems=(name)=>{
    if(name.toUpperCase()==="LOGOUT")
      {
        logout();
        navigate("/")
      }
      if(name.toUpperCase()==="LOGIN")
      {
        setAnchorElUser(null);
        navigate("/login")
      }
      if(name.toUpperCase()==="PROFILE")
        {
          navigate("/profile")
          setAnchorElUser(null);
        
        }
        if(name.toUpperCase()==="HELPLINE")
          {
            if(userRole=="ADMIN")
            {
            navigate("/adminHelpline")
            }
            else{
              navigate("/helpline")
            }
            setAnchorElUser(null);
          
          }
          if(name.toUpperCase()==="MANAGE PRICE"){
            setModalState(true)
          }
}

  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: "center" }}>
      <Typography variant="h6" sx={{ my: 2 }}>
        PARKIT
      </Typography>
      <Divider />
      <List>
        {navItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton onClick={()=>{handleNavMenuItems(item.textLink, item.text)}} 
            sx={{ 
              textAlign: "center",
              backgroundColor: selectedItem === item.text ? '#66FCF1' : "transparent",
              "&:hover": {
                backgroundColor: "#45A29E"
              }
            }}>
              <ListItemText>{item.text}</ListItemText>
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  // const container = window !== undefined ? () => window().document.body : undefined;

  return (
    <Box sx={{ display: "flex", pb:"50px", bgcolor: '#1F2833'}}>
      <CssBaseline />
      <AppBar component="nav" sx={{bgcolor:"#0B0C10", color: "#66FCF1"}}>
        <Toolbar >
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 1, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1}}>
            PARKIT
          </Typography>
          <Box sx={{ mr:4, display: { xs: "none", sm: "block" }, flexGrow: 0}}>
          {navItems.map((item) => (
            <Button key={item.text} onClick={()=>{handleNavMenuItems(item.textLink, item.text)}} 
            sx={{ 
              color: "#66FCF1",
              fontWeight: selectedItem === item.text ? 'bold' : 'normal',
              "&:hover": {
                textDecoration:'underline',
                color: "#0B0C10"
              }
              }}>
              {item.text}
            </Button>
          ))}
          </Box>

          {/* Login details of user */}
          <Box sx={{ flexGrow: 0 }}>
            <Tooltip title="Open settings">
              <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                <Avatar alt="Remy Sharp" src={profileIcon} />
              </IconButton>
            </Tooltip>
            <Menu
              sx={{ mt: '45px' }}
              id="menu-appbar"
              anchorEl={anchorElUser}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={Boolean(anchorElUser)}
              onClose={handleCloseUserMenu}
            >
              {settings.map((setting) => (
                <MenuItem key={setting}  onClick={()=>{handleSettingMenuItems(setting)}}>
                  <Typography textAlign="center">{setting}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>
        <Toolbar />
      <nav>
        <Drawer
          // container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true // Better open performance on mobile.
          }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth
            }
          }}
        >
          {drawer}
        </Drawer>
      </nav>
      
      <ManagePriceModal  modalState={modalState} setModalState={setModalState}/>
    </Box>
  );
}


export default NavbarComponent;
