import {
  Alert,
  Box,
  Button,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  TextField,
  Typography,
  createTheme,
} from "@mui/material";

import React, { useEffect, useState } from "react";
import CloseIcon from "@mui/icons-material/Close";
import { toast } from "react-toastify";
import axios from "axios";
import { json } from "react-router-dom";


export default function AddVehicleModal({ setVehicleData,Vehicledata,setModalState, ModalState, method, defaultValue }) {
  
  const theme = createTheme();

  //style
  const modalStyle = { 
    box: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "60%",
      bgcolor: "background.paper",
      backgroundColor: "white",
      boxShadow: 24,
      borderRadius: 5,
      alignItems: "center",
      display: "flex",
      justifyContent: "center",
      maxWidth: "600px",
      flexWrap: "wrap",
      padding: 0,
    },
    closeBtn: {
      left: "calc(100% - 60px)",
      width: "30px",
      height: "30px",
      borderRadius: "12px",
      color: "#66FCF1",
    },
    Field: {
      size: "small",
      marginBottom: "10px",
      "& .MuiInputBase-root": {
        backgroundColor: "#c5c6c75e",
      },
      "& .MuiFormLabel-root": {
        color: "black",
        top: "50%", 
        paddingLeft: "10px",
        transform: "translateY(-50%)",
      },
      "& .MuiInputLabel-shrink": {
        top: 0,
        transform: "translateY(-100%) scale(0.75)", 
      },
    },
    fieldContainer: {
      textAlign: "center"
    },
    SelectField: {
      size: "small",
      width: "100%",
      maxWidth: "220px",
      marginBottom: "10px",
      height: "40px",
      "& .MuiInputBase-root": {
        backgroundColor: "#c5c6c75e",
        textAlign: "start"
      },
      "& .MuiFormLabel-root": {
        color: "black",
        top: "50%", 
        paddingLeft: "10px",
        transform: "translateY(-50%)",
      },
      "& .MuiInputLabel-shrink": {
        top: 0,
        transform: "translateY(-100%) scale(0.75)", 
      },
    },
  };


  const [formData, setFormData] = useState(defaultValue);

  const [formEmptyMessage, setEmptyMessage] = useState({
    licenceNo: " enter licence no",
    manufacturer: " enter manufacturere name",
    model: " enter model of vehicle",
    color: " enter color of vehicle",
    vehicleType: "2",
  });

  //set modal data
  useEffect(() => {
    setFormData(defaultValue);
  }, [defaultValue]);

  //to check if field empty except additional info
  function isFieldEmpty() {
    for (var key of Object.keys(formData)) {
      if (formData[key] == '') {
        if (key != "additionalInfo") {
          toast.error(formEmptyMessage[key]);
          return true;
        }
      }
    }
    return false;
  }

  //to hadle field data change
  function handleChange(e) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }


  //on submit if method is AADD  add new record else edit

  function onsubmit() {
    if (!isFieldEmpty()) {
      if (method == "ADD") {

        axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL + "/addVehicle", formData, {
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .then((response) => {
          if (response) {
           
            setVehicleData([...Vehicledata,response.data])
            toast.success("added vehicle sucessfully");
          }
          setModalState(false);

        }).catch((err) => {
          
          if (err.response.data) 
          {
            toast.error(err.response.data.result);
           }
        });

      } else  
      {

        if(formData.licenceNo!=defaultValue.licenceNo||formData.manufacturer!=defaultValue.manufacturer ||
          formData.model!=defaultValue.model||formData.color!=defaultValue.color||
          formData.additionalInfo!=defaultValue.additionalInfo ||formData.vehicleType!=defaultValue.vehicleType)
        {
            
            axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL + "/editVehicle", formData, {
            headers: {
              'Content-Type': 'application/json'
            }
          })
          .then((response) => {
            if (response) {
            
              Vehicledata.forEach((item, index, arr) => {
                if (item.id === response.data.id) {
                    arr[index] = response.data;
                    
                }})

              setVehicleData(Vehicledata)
              toast.success("vehicle edited sucessfully");
            }
            setModalState(false);

          }).catch((err) => {
            if (err.response.data) {
              toast.error(err.response.data);
            }
          });

         }
      }
    }
  }

  //close modal
  async function handleClose() {
    setModalState(false);
  }
 

  //return design
  return (
    <Modal
      open={ModalState}
      onClose={handleClose}
      aria-labelledby="modal-title"
      aria-describedby="modal-description"
    >
      <Box sx={modalStyle.box}>
        <div style={{width:"100%", left:"0%", backgroundColor: "#182c44b5", borderRadius: "20px 20px 0px 0px", height: "60px"}}>
          <Button sx={modalStyle.closeBtn} onClick={() => {setModalState(false)}}>
            <CloseIcon></CloseIcon>
          </Button>
        </div>

        <Grid container spacing={2} sx={{width:"100%", margin:"10%"}} >
          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer} >
            <Typography variant="body2">
              <TextField 
                onChange={handleChange}
                value={formData.licenceNo || ""}
                name="licenceNo"
                label={"Licence Number"}
                sx={modalStyle.Field} 
                size="small"
                autoComplete="off"
              />
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer}>
            <Typography variant="body2">
              <TextField 
                onChange={handleChange}
                value={formData.manufacturer || ""}
                name="manufacturer"
                label={"Manufacturer"}
                sx={modalStyle.Field} 
                size="small"
                autoComplete="off"
              />
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer}>
            <Typography variant="body2">
              <TextField 
                onChange={handleChange}
                value={formData.model || ""}
                name="model" 
                label={"Model"} 
                sx={modalStyle.Field} 
                size="small" 
                autoComplete="off"
              />
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer}>
            <Typography variant="body2">
              <TextField 
                value={formData.color || ""}
                onChange={handleChange} 
                name="color" 
                label={"Color"} 
                sx={modalStyle.Field}  
                size="small"  
                autoComplete="off"
              />
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer}>
            <Typography variant="body2">
              <FormControl
                item
                xs={12}
                sm={6}
                sx={{ ...modalStyle.SelectField }}
                size="small"
              >
                <InputLabel id="vehicle-type-label">Vehicle Type</InputLabel>
                <Select 
                  onChange={handleChange}
                  labelId="vehicle-type-label"
                  id="vehicle-type"
                  label="Vehicle Type"
                  name="vehicleType"
                  value={formData.vehicleType || "2"}
                >
                  <MenuItem value="2">2 wheeler</MenuItem>
                  <MenuItem value="4">4 wheeler</MenuItem>
                </Select>
              </FormControl>
            </Typography>
          </Grid>

          <Grid item xs={12} sm={6} sx={modalStyle.fieldContainer}>
            <Typography variant="body2">
              <TextField
                value={formData.additionalInfo || ""}
                onChange={handleChange}
                name="additionalInfo"
                label={"Additional Information"}
                sx={modalStyle.Field}
                size="small"
                autoComplete="off"
              />
            </Typography>
          </Grid>
          
          <Button 
            onClick={onsubmit} 
            variant="contained" 
            color="primary"  
            sx={{borderRadius: 5, margin: "5%", marginRight: "0%", marginTop: "20px", width: "100%"}}
          >
            Submit
          </Button>
        </Grid>
      </Box>
    </Modal>
  );
}
