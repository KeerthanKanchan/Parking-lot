import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';

export default function HomePageCardComponent(props) {
  return (
    <Card sx={{ width: 250, textAlign:'center', border:1, borderRadius:4, boxShadow: 20, m: 2 }}>
      <CardMedia
        component="img"
        alt="green iguana"
        height="50"
        width="50"
        image={props.image}
        sx={{objectFit: 'contain', pt:2}}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {props.step}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {props.stepName}
        </Typography>
      </CardContent>
    </Card>
  );
}
