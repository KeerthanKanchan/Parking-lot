import { Button, Grid, Modal, TextField, Typography } from "@mui/material";
import { Box } from "@mui/system";
import axios from "axios";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";


export default function ManagePriceModal({ modalState, setModalState }) {

    const [data, setData] = useState([{ id: "1", type: "2", price: "50" }, { id: "2", type: "4", price: "50" }]);
    const [twoprice, settwoPrice] = useState("50");
    const [fourprice, setFourPrice] = useState("50");

    useEffect(() => {
        if(modalState==true){
        axios.get(process.env.REACT_APP_ADMIN_BACKEND_URL+"/getPrices").then((response)=>{
          
            setData(response.data)
            for(var d of response.data)
            {
                if(d.type==2)
                {
                    settwoPrice(d.price.toString())
                }
                else{
                    setFourPrice(d.price.toString())
                }
            }
        
            
          }).catch((err)=>{
          })
        }

    }, [modalState]);

    async function onSave(type, id) {

        async function updatePrice(type,id,price)
        {
            await axios.post(process.env.REACT_APP_ADMIN_BACKEND_URL+"/updatePrice",{id:id,type:type,price:price},{
                headers: {
                  'Content-Type': 'application/json',
                }
              }).then((response)=>{
                toast.success("sucessfully increased price")
                setModalState(false)
              
              }).catch((err)=>{
        
                  toast.error("something went wrong")
        
              })
        }

        if(type==2)
        {
            if(twoprice!="")
            {
            await updatePrice(type,id,twoprice)
            }
        }
        else{
            if(fourprice!="")
            {
                await updatePrice(type,id,fourprice)
            }
        }
    }

    return (
        <>
            <Modal
                open={modalState}
                onClose={() => { setModalState(false) }}
                aria-labelledby="modal-title"
                aria-describedby="modal-description"
            >
                <Box sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: "40%",
                    height: "40%",
                    bgcolor: "background.paper",
                    backgroundColor: "white",
                    boxShadow: 24,
                    borderRadius: 5,
                    alignItems: "center",
                    display: "flex",
                    justifyContent: "center",
                    maxWidth: "600px",
                    minWidth:"300px",
                    flexWrap: "wrap",
                    padding: 0,
                }}>
                    <Grid container spacing={2}>
                        {data.map((d) => {
                             return (<Grid  sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                alignItems: 'center',
                            }} item xs={12} >
                              
                                <TextField label={d.type+ "wheeler price"} type="number"
                                    value={d.type === "2" ? twoprice : fourprice}
                                    onChange={(e) => {
                                        if (d.type === "2") {
                                            settwoPrice(e.target.value);
                                        } else {
                                            setFourPrice(e.target.value);
                                        }
                                    }}
                                />
                                <Button onClick={() => { onSave(d.type, d.id) }} variant='contained' sx={{marginLeft:"30px", color:'white!important'}}>
                                    Save
                                </Button>
                            </Grid>)
                        })
                        }
                    </Grid>
                </Box>
            </Modal>
        </>
    );
}
