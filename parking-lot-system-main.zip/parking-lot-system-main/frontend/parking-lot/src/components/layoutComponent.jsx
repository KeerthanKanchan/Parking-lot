import React from 'react';
import NavbarComponent from './headerComponent';
import FooterComponent from './footerComponent';
import HomePage from '../pages/customer pages/homePage';
// TODO: import header, navbar and footer

const MainLayoutComponent = ({Children,loginStatus,setLoginStatus}) => {
    return (
        <>
        <NavbarComponent loginStatus={loginStatus} setLoginStatus={setLoginStatus}/>
         {Children}
         <FooterComponent />
        </>
    )
} 

export default MainLayoutComponent;