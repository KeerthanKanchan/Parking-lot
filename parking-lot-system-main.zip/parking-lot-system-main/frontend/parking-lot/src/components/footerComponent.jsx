import React from 'react';
import '../css/footer.css';
import { Link } from 'react-router-dom';
import { colors } from '@mui/material';

function FooterComponent () {

    return (
        <footer>
            <div id='main-footer'>
                    <div id="links-section">
                        <h4>Links:</h4> 
                        <div>
                            <Link href="/terms" color="inherit" sx={{ mx: 1 }} style={{textDecoration:'none', color:'white'}}>
                                Terms of Service
                            </Link>
                        </div>
                        <div>
                            <Link href="/privacy" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                                Privacy Policy
                            </Link>
                        </div>
                        <div>
                            <Link href="/contact" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                                Contact Us
                            </Link>
                        </div>
                    </div>
                    <div className='vl'></div>
                    <div id='socials-section'>
                    <h4>Follow us on:</h4>
                    <div>
                        <Link href="https://facebook.com/parkit" target="_blank" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                            Facebook
                        </Link>
                    </div>
                    <div>
                        <Link href="https://twitter.com/parkit" target="_blank" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                            Twitter
                        </Link>
                    </div>
                    <div>
                        <Link href="https://instagram.com/parkit" target="_blank" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                            Instagram
                        </Link>
                    </div>
                    <div>
                        <Link href="https://linkedin.com/company/parkit" target="_blank" color="inherit" underline="hover" sx={{ mx: 1 }}  style={{textDecoration:'none', color:'white'}}>
                            LinkedIn
                        </Link>
                    </div>
                </div>
                <div className='vl'></div>
                <div id='about-footer-section'>
                    <h2>PARKIT</h2>
                    <p>Designed with <span className='heartIcon'> &#10084;</span> by PARKIT Team</p>
                </div>
            </div>
            <p>Copyright &#169;2024 PARKIT. All rights reserved.</p>
        </footer>
    )
}

export default FooterComponent;