
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './services/auth/authContext';
import Signup from './pages/customer pages/signup';
import LoginPage from './pages/login';
import NavbarComponent from './components/headerComponent';

import './App.css';
import MainLayoutComponent from './components/layoutComponent';
import HeaderComponent from './components/headerComponent';
import ProfilePage from './pages/customer pages/profile';
import HomePage from './pages/customer pages/homePage';
import BookingPage from './pages/customer pages/bookingPage';
import MyBookings from './pages/customer pages/myBookingPage';
import ProtectedRoute from './services/auth/protectedRoute';
import FooterComponent from './components/footerComponent';
import { LoadingPage } from './pages/loadingPage';
import Dashboard from './pages/Dashboard';
import Report from "./pages/Report";
import Space from "./pages/AddRemoveSpace";
import About from "./pages/About";
import ContactUs from './pages/ContactUs';
import EntryExit from './pages/EntryExit';
import MyBookingsPage from './pages/BookingDetails';

import Helpline from './pages/customer pages/helpline';
import RowRadioButtonsGroup from './pages/AddRemoveSpace'
import EnhancedTable from './pages/admin/manageSpacePage'
import Dashborad from './pages/Dashboard';
import AdminHelpline from './pages/admin/adminHelpline';

import NewDash from './pages/NewDash';
import Reservation from "./pages/Reservation";
import Invoice from "./pages/Invoice";
import EntryExitV from './pages/admin/entryExit2';

function App() {

  return (
    <AuthProvider>
      <Router>
        <MainContent />
      </Router>
    </AuthProvider>
  );
}

const MainContent = () => {
  const location = useLocation();
  const hideNavBar = location.pathname === '/login' || location.pathname === '/signup';

  
  return (
    <>
    {!hideNavBar && <NavbarComponent />}
        <Routes>
          <Route path='/login' element={<LoginPage />}/>
          <Route path='/signup' element={<Signup />}/>

          <Route path='/' exact element={<HomePage />} />
          <Route path='/about-us' element={<About/>}/>
          <Route path='/contact-us' element={<ContactUs/>}/>
          

          

{/* user routes */}
          <Route element={<ProtectedRoute allowedRoles={['CUSTOMER']} />}>
            <Route path="/booking" element={<BookingPage />} />
            <Route path="/my-bookings" element={<MyBookings />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/helpline" element={<Helpline />} />
            <Route path='/invoice' element={<Invoice />}/>
           
          </Route>

{/* Admin routes */}
          <Route element={<ProtectedRoute allowedRoles={['ADMIN']} />}>
            <Route path="/dashboard" element={<NewDash />} />
            <Route path='/manageSpace' element={<EnhancedTable />}/>
            <Route path='/adminHelpline' element={<AdminHelpline/>}/>
            <Route path='/entryExit' element={<EntryExit/>}/>
            <Route path='/report' element={<Report/>}/>
            <Route path='/reservation' element={<Reservation />}/>
          </Route>



          <Route path='*' element={<Navigate to='/' />} />
        </Routes>
        {!hideNavBar && <FooterComponent />}
    </>
  )
}

export default App;
