import React from 'react'
import "../css/Entryexit.css"
import { Button } from '@mui/material'
import { Link } from 'react-router-dom'
import Popup from "./Popup"
import PopupExit from './PopupExit'

function EntryExit() {
  return (
    <div id="entrydiv" >
        <img id="parkingimg" src="https://media.istockphoto.com/id/1307047135/photo/parking.jpg?s=612x612&w=0&k=20&c=lOS7VPJFCNBhFFhkCW-v-xjWaQRMj7zUq0SwVI2MS-c=" alt="entrypic" />
            <Popup name="entry"/>
            <PopupExit name="exit"/>
            <div id="end-div">

            </div>
    </div>
  )
}

export default EntryExit
