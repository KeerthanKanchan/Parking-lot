// import * as React from 'react';
// import Button from '@mui/material/Button';
// import Dialog from '@mui/material/Dialog';
// import DialogActions from '@mui/material/DialogActions';
// import DialogContent from '@mui/material/DialogContent';
// import DialogContentText from '@mui/material/DialogContentText';
// import DialogTitle from '@mui/material/DialogTitle';
// import Slide from '@mui/material/Slide';
// import { Grid, TextField } from '@mui/material';
// import "../css/ContactUs.css";


// const Transition = React.forwardRef(function Transition(props, ref) {
//   return <Slide direction="up" ref={ref} {...props} />;
// });

// export default function AlertDialogSlide() {
//   const [open, setOpen] = React.useState(false);

//   const handleClickOpen = () => {
//     setOpen(true);
//   };

//   const handleClose = () => {
//     setOpen(false);
//   };

//   return (
//     <>
//       <Button id='button-pop' variant="contained" onClick={handleClickOpen}>
//         Contact Us
//       </Button>
//       <Dialog
//         open={open}
//         TransitionComponent={Transition}
//         keepMounted
//         onClose={handleClose}
//         aria-describedby="alert-dialog-slide-description"
//       >
//         <DialogContent className='pop-up1'>
//         <DialogTitle>Contact Us</DialogTitle>
//             <Grid container sx={{width:"40vw", height:'50vh', display:'flex',margin:'10px'}}>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={3}>
//                     <label>Email</label>
//                 </Grid>
//                 <Grid xs={2}>
//                    <br />
//                 </Grid>
//                 <Grid xs={5} sx={{marginBottom:"10px"}}>
//                 <TextField variant="outlined" size='small'/>
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={3}>
//                     <label>Name</label>
//                 </Grid>
//                 <Grid xs={2 }>
//                    <br />
//                 </Grid>
//                 <Grid xs={5} sx={{marginBottom:"10px"}}>
//                 <TextField variant="outlined" size='small' />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={3}>
//                     <label>Mobile</label>
//                 </Grid>
//                 <Grid xs={2 }>
//                    <br />
//                 </Grid>
//                 <Grid xs={5}sx={{marginBottom:"10px"}}>
//                 <TextField variant="outlined" size='small' />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={3}>
//                     <label>Description</label>
//                 </Grid>
//                 <Grid xs={2 }>
//                    <br />
//                 </Grid>
//                 <Grid xs={5} sx={{marginBottom:"10px"}}>
//                 <TextField
//                     multiline
//                     rows={2}
//                     fullWidth
//                 />
//                 </Grid>
//                 <Grid xs={1}>
//                    <br />
//                 </Grid>
//                 <Grid xs={6}>
                    
//                 </Grid>
               
//                 <Grid xs={5.2}>
//                 <DialogActions>
//           <Button id='button-pop2' onClick={handleClose}>Submit</Button>
//         </DialogActions>
//                 </Grid>

//             </Grid>
       
          
//         </DialogContent>
//       </Dialog>
//     </>
//   );
// }

import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import emailjs from 'emailjs-com';
import { toast } from "react-toastify"
const AlertDialogSlide = () => {
    const [open, setOpen] = useState(false);
    const [formData, setFormData] = useState({
        email: '',
        name: '',
        mobile: '',
        description: ''
    });

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
      e.preventDefault();
     const service_id="service_7a4xdoq"
     const template_id="template_uyr92d5"
     const user_id="t3ui9jL48mRDTgdfm"
      emailjs.send(service_id,template_id,{
         "from_name":formData.name,
         "from_email":formData.email,
         "message":formData.description
      },user_id)
            .then((response) => {
                console.log('Email sent:', response.status, response.text);
                toast.success("sucessfully sent mail")
                setFormData({
                    email: '',
                    name: '',
                    description: ''
                });
                handleClose(); // Close dialog after submission
            }, (error) => {
                console.error('Email error:', error);
                toast.error("failed to send email")
               
            });
      
        setFormData({
         email: '',
         name: '',
         mobile: '',
         description: ''
     });
     handleClose(); 
    };

    return (
        <>
            <Button id='button-pop' variant="contained" onClick={handleClickOpen}>
                Contact Us
            </Button>
            <Dialog
                open={open}
                onClose={handleClose}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogContent className='pop-up1'>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                variant="outlined"
                                label="Name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                variant="outlined"
                                label="Email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                            />
                        </Grid>
                        {/* <Grid item xs={12}>
                            <TextField
                                fullWidth
                                variant="outlined"
                                label="Mobile"
                                name="mobile"
                                value={formData.mobile}
                                onChange={handleInputChange}
                            />
                        </Grid> */}
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                variant="outlined"
                                label="Description"
                                name="description"
                                multiline
                                rows={4}
                                value={formData.description}
                                onChange={handleInputChange}
                            />
                        </Grid>
                    </Grid>
                    <DialogActions>
                        <Button id='button-pop2' onClick={handleSubmit}>Submit</Button>
                        <Button id='button-pop2' onClick={handleClose}>Cancel</Button>
                    </DialogActions>
                </DialogContent>
            </Dialog>
        </>
    );
}

export default AlertDialogSlide;

