import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Button, Grid, Input } from '@mui/material';
import { addParkingSpot } from '../services/ApiService';



export default function RowRadioButtonsGroup() {

  const [operationType, setOperationType] = React.useState(null);

  const handleSubmit = (event) => {
    if (operationType === null) {
      console.log(" Null data found")
    } else {
      console.log("User selected peration type")
      addParkingSpot({}, ()=>{}, ()=>{});
    }
  }

  const handleOperationTypeChange = (event) => {
    console.log(event.target.value);
    setOperationType(event.target.value);
  }


  return (
    <>
    <h1 style={{color:"#66fcf1", backgroundColor:'#0b0c10', padding:10}}>Add/Remove Space</h1>
      <div style={{backgroundColor:'#c5c6c7', height:"100vh",}}>

      <Grid container>
      <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={3}>
         
        </Grid>
        <Grid xs={3} sx={{paddingTop:1}}>
          <label>Slot</label>
        </Grid>
        <Grid xs={6}>
          <RadioGroup row label="operation-type" value={operationType} onChange={handleOperationTypeChange}>
            <FormControlLabel value="add" control={<Radio />} label="Add" />
            <label style={{marginRight: 60}}></label>
            <FormControlLabel value="remove" control={<Radio />} label="Remove" />
          </RadioGroup>
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={3}>
         
        </Grid>
        <Grid xs={3} sx={{paddingTop:1}}>
          <label>Type of vehicle</label>
        </Grid>
        <Grid xs={6}>
          <RadioGroup row>
            <FormControlLabel value="two-wheeler" control={<Radio />} label="two-wheeler" />
            <FormControlLabel value="four-wheeler" control={<Radio />} label="four-wheeler" />
          </RadioGroup>
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={3}>
         
        </Grid>
        <Grid xs={3} sx={{paddingTop:1}}>
          <label>No. of slots</label>
        </Grid>
        <Grid xs={6}>
        <Input type="number" style={{width: "250px", border:"1px solid"}}
        />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={12}>
          <br />
        </Grid>
        <Grid xs={7.7}></Grid>
        <Grid xs={3}>
          <Button variant='outlined' onClick={handleSubmit}>Submit</Button>
          </Grid>
        
    </Grid>
        </div>
  </>
  );
}
