import React from 'react';
import "../css/NewDash.css";
import MainDash from './MainDash';

function NewDash() {
  return (
    <div className='AppD' >
        <div className='AppGlass'>
            <div>
            </div>
            <MainDash />
        </div>
      
    </div>
  )
}

export default NewDash;