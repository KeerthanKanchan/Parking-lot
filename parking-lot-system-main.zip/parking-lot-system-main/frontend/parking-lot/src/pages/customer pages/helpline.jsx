import React, { useEffect, useRef, useState } from "react";
import { AppBar, Toolbar, IconButton, Drawer, List, ListItem, ListItemText, Grid, Box, useTheme, useMediaQuery, Typography, Button, Modal, TextField } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import AddIcon from '@mui/icons-material/Add';
import SendIcon from '@mui/icons-material/Send';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import { toast } from "react-toastify";
import { useAuth } from "../../services/auth/authContext";
import axios from "axios";
import io from 'socket.io-client';

const socket = io('http://localhost:8080')

export default function Helpline() {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [chat, setChat] = useState({});
    const [activeTicket, setActiveTicket] = useState(null);
    const [chatState, setChatState] = useState({});
    const [modalState, setModalState] = useState(false);
    const [form, setFormData] = useState({ title: "", description: "" });
    var { userId } = useAuth();
    var chatBox = useRef(null);
    var [data, setData] = useState([]);
    var[textFieldData,setTexFieldData]=useState(""); 
    const [activeChats, setActiveChats] = useState([]);
    const [inactiveChats, setInactiveChats] = useState([]);
    const [completeChats, setCompleteChats] = useState([]);

    useEffect(()=>{
      
        if(userId){
            socket.emit('subscribe_to_helpline', userId);
           
            socket.on('helpline_initial_data', (data) => {
                console.log('Initial Helpline Data:', data);
               
                 setData(data.tickets)
              
            });

            socket.on('helpline_update', (update) => {
            
                console.log('Helpline Update:', update);
               
                setData(update.tickets)
                
            });

      
            // return () => {
            //     socket.disconnect();
            // };
        }
    },[userId])


    useEffect(()=>{
        var compchat=[]
        var inActChat=[]
        var actChat=[]
  data.forEach((obj,index)=>
  {
    if (obj.status=="COMPLETE")
    {
        compchat.push(    <Grid
            sx={{ padding: "2%", borderBottom: "solid 1px #adf6ff", width: "100%" }}
            onClick={() => {
                ticketClick(obj.ticket);
            }}
            key={index}
        >
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.title}</Typography>
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.description}</Typography>
        </Grid>)
    }
    else if( obj.status=="ACTIVE"){
        actChat.push(    <Grid
            sx={{ padding: "2%", borderBottom: "solid 1px #adf6ff", width: "100%" }}
            onClick={() => {
                ticketClick(obj.ticket);
            }}
            key={index}
        >
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.title}</Typography>
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.description}</Typography>
        </Grid>)
    }
    else if( obj.status=="INACTIVE"){
        inActChat.push(    <Grid
            sx={{ padding: "2%", borderBottom: "solid 1px #adf6ff", width: "100%" }}
            onClick={() => {
                ticketClick(obj.ticket);
            }}
            key={index}
        >
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.title}</Typography>
        <Typography maxWidth={"100%"} sx={{wordWrap:"break-word"}}>{obj.description}</Typography>
        </Grid>)
    }
  })
  setActiveChats(actChat)
  setInactiveChats(inActChat)
  setCompleteChats(compchat)
      

    },[data])
    function onchange(e) {
        setFormData({ ...form, [e.target.name]: e.target.value });
    }

    function onsubmit() {
        if (form.title == '') {
            toast.error("Enter title");
        } else if (form.description == '') {
            toast.error("Enter description");
        } else {
            axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL + "/createTicket", { ...form, id: userId }, {
                headers: {
                    'Content-Type': 'application/json',
                }
            }).then((response) => {
                toast.success(response.data.result)
            }).catch((err) => {
                toast.error("Something went wrong");
            });
            setModalState(false);
        }
    }

    
 function sendChat()
 {
    if(textFieldData!=""){
        axios.post(process.env.REACT_APP_COMMON_BACKEND_URL+"/addMessage",{user:"customer",message:textFieldData,ticket:activeTicket},
            {headers:{"Content-Type":"application/json"}})
            .then((response)=>{
                if(response.data)
                {
                    setTexFieldData("")
                  
                }
            })
            .catch((err)=>{
              
            })

        
    }
 }

    useEffect(() => {
        generateChat(data);
    }, [data]);

   

   async  function generateChat(dt) {
        const chatData = {}; 
        const chatStatus = {};

        for (var d of dt) {
            chatStatus[d.ticket]=d.status;
            const messages = [];
            for (const time in d.chat.customer) {
                messages.push({ time: time, user: "customer", message: d.chat.customer[time] });
            }
            for (const time in d.chat.admin) {
                messages.push({ time: time, user: "admin", message: d.chat.admin[time] });
            }
            messages.sort((a, b) => new Date(a.time) - new Date(b.time));
            chatData[d.ticket] = messages.map(obj =>
                obj.user === "customer" ? (
                    <Grid
                        sx={{
                            display: "flex",
                            flexWrap: "nowrap",
                            width: "100%",
                            justifyContent: "flex-start",
                            padding: "7px",
                            paddingLeft: "20px"
                        }}
                        key={obj.time}
                    >
                        <div style={{ backgroundColor: "green", wordWrap: "break-word", maxWidth: "90%", borderRadius: "10px", padding: "3%", paddingTop: "0.5%", paddingBottom: "0.5%" }}>
                            {obj.message}
                        </div>
                    </Grid>
                ) : (
                    <Grid
                        sx={{
                            display: "flex",
                            flexWrap: "nowrap",
                            width: "100%",
                            justifyContent: "flex-end",
                            padding: "7px",
                            paddingRight: "20px"
                        }}
                        key={obj.time}
                    >
                        <div style={{ backgroundColor: "gray", maxWidth: "90%", wordWrap: "break-word", borderRadius: "10px", padding: "3%", paddingTop: "0.5%", paddingBottom: "0.5%" }}>
                            {obj.message}
                        </div>
                    </Grid>
                )
            );
        }
        await setChat(chatData);
        await setChatState(chatStatus)
        if (chatBox.current) {
            chatBox.current.scrollTop = chatBox.current.scrollHeight+1000;
        }
    }

    const ticketClick = async (ticket) => {
        await setActiveTicket(ticket);
        if (chatBox.current) {
            chatBox.current.scrollTop = chatBox.current.scrollHeight;
        }
    };

    const handleDrawerToggle = () => {
        setDrawerOpen(!drawerOpen);
    };

    return (
        <Box display="flex" height="calc( 100vh - 40px )" top={"-50px"} marginBottom={"-75px"} position="relative">
            {!isMobile && (
                <Box
                    width="30%"
                    bgcolor=""
                    display="flex"
                    flexDirection="column"
                    alignContent="flex-start"
                    justifyContent="flex-start"
                    height="calc(100% - 35px )"
                    overflowY="auto"
                    sx={{ backgroundColor: "#1f2833", overflowY: "auto" }}
                >
                        <Button onClick={() => { setModalState(true) }}><AddIcon /></Button>
                        {activeChats.length>0?<div style={{textAlign:"center",color:"green",borderBottom: "solid 1px #adf6ff",marginTop:"5px"}}>ACTIVE</div>
                        :<></> } 
                         <Box
                                width="100%"
                                height="fit-content"
                               
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{ backgroundColor: "inherit", color: "#c5caec" ,marginTop:"5px"}}
                            >

                                {activeChats}
                            </Box>

                            {inactiveChats.length>0?<div style={{textAlign:"center",color:"red",borderBottom: "solid 1px #adf6ff",marginTop:"5px"}}>INACTIVE</div>
                            :<></>}
                            <Box
                                width="100%"
                                height="fit-content"
                               
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{  color: "#c5caec",marginTop:"5px" }}
                            >

                                {inactiveChats}
                            </Box>
                            {completeChats.length>0?<div style={{textAlign:"center",color:"blue",borderBottom: "solid 1px #adf6ff",marginTop:"5px"}}>COMPLETE</div>
                             :<></>} 
                             <Box
                                width="100%"
                                height="fit-content"
                                bgcolor="lightblue"
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{ backgroundColor: "inherit", color: "#c5caec",marginTop:"5px" }}
                            >

                                {completeChats}
                            </Box>
                </Box>
            )}
            <Box
                width={isMobile ? '100%' : '70%'}
                bgcolor="lightgreen"
                display="flex"
                flexDirection="column"
                sx={{ background: "linear-gradient(106.37deg, #1f2833,#45a29e,#1f2833)" }}
                height="calc(100% - 35px )"
            >
                {isMobile && (
                    <>
                        <Button sx={{ width: "15px", height: "70px", borderRadius: "360%", padding: "0" }} onClick={handleDrawerToggle}>
                            <ConfirmationNumberIcon />
                        </Button>
                        <Drawer
                            anchor="left"
                            open={drawerOpen}
                            onClose={handleDrawerToggle}
                            sx={{
                                '& .MuiDrawer-paper': {
                                    width: '70%',
                                    height: '100%',
                                    position: 'absolute',
                                    top: "60px",
                                    backgroundColor: "#1f2833",
                                }
                            }}
                        >
                            <Button onClick={() => { setModalState(true) }}> <AddIcon /></Button>

                            {activeChats.length>0?<div style={{textAlign:"center",color:"green",borderBottom: "solid 1px #adf6ff",marginTop:"5px"}}>ACTIVE</div>
                            :<></>
                             } <Box
                                width="100%"
                                height="fit-content"
                               
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{  color: "#c5caec",marginTop:"5px" }}
                            >

                                {activeChats}
                            </Box>

                            {inactiveChats.length>0? <div style={{textAlign:"center",color:"red",borderBottom: "solid 1px #adf6ff",marginTop:"5px"}}>INACTIVE</div>
                            :<></>
                            }
                            <Box
                                width="100%"
                                height="fit-content"
                              
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{ color: "#c5caec",marginTop:"20px" }}
                            >

                                {inactiveChats}
                            </Box>
                            {completeChats.length>0? <div style={{textAlign:"center",color:"blue",borderBottom: "solid 1px #adf6ff",marginTop:"20px"}}>COMPLETE</div>
                            :<></>
                            }
                            <Box
                                width="100%"
                                height="fit-content"
                               
                                display="flex"
                                flexDirection="column"
                                alignContent="flex-start"
                                justifyContent="flex-start"
                                overflowY="auto"
                                sx={{  color: "#c5caec",marginTop:"20px" }}
                            >

                                {completeChats}
                            </Box>
                        </Drawer>
                    </>
                )}
                <Box
                    height="100%"
                    sx={{ overflowY: "auto" }}
                    ref={chatBox}
                >
                    {activeTicket ? chat[activeTicket] : <></>}
                </Box>
                {chatState[activeTicket] == "ACTIVE" ?
                    (
                        <Grid sx={{ display: "flex" }}>
                            <TextField value={textFieldData} onChange={(e)=>{
                                setTexFieldData(e.target.value)
                            }} fullWidth sx={{'& input': {color: 'white'}, border: "1px solid #adf6ff" }} />
                            <Button onClick={sendChat}sx={{ backgroundColor: "#ffffff1f" }}><SendIcon /></Button>
                        </Grid>
                    ) : (<></>)}
            </Box>
            <Modal
                open={modalState}
                onClose={() => { setModalState(false) }}
                aria-labelledby="simple-modal-title"
                aria-describedby="simple-modal-description"
                sx={{}}
            >
                <Box sx={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    width: isMobile ? "300px" : "400px",
                    height: isMobile ? "300px" : "400px",
                    bgcolor: 'white',
                    border: '2px solid #000',
                    boxShadow: 24,
                    p: 4,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <h1>New Query</h1>
                    <TextField value={form.title} name="title" label="Title" onChange={onchange} variant="outlined" fullWidth sx={{ mt: 2 }} />
                    <TextField value={form.description} name="description" onChange={onchange} label="Description" variant="outlined" fullWidth sx={{ mt: 2 }} />
                    <Button
                        variant="contained"
                        color="primary"
                        sx={{ mt: 2 }}
                        onClick={onsubmit}
                    >
                        Submit
                    </Button>
                </Box>
            </Modal>
        </Box>
    );
}
