import React from'react';
import '../../css/myBooking.css';
import MyBookingCardComponent from '../../components/myBookingCardComponent';
import { useEffect } from 'react';
import {myBookingsApi} from '../../services/ApiService';
import { useAuth } from '../../services/auth/authContext';
import { keys } from '@mui/system';


export default function MyBookings() {

    const [myBookings, setMyBookings] = React.useState([]);
    const [upcomingBookings, setUpcomingBookings] = React.useState([]);
    const [completedBookings, setCompletedBookings] = React.useState([]);
    // const [parked, setParked] = React.useState(["HI"]);
    const now = new Date();
    const {userId} = useAuth();
    let filterBooking;
    useEffect(()=> {
        console.log("getting user id in my bookings", userId);
        myBookingsApi({id:userId}, 
            (response)=> {
                console.log(response);
               
                setMyBookings(response);
                setUpcomingBookings(response.filter((booking, index) => new Date(booking.reservation.reservation_exit_time) > now));
                setCompletedBookings(response.filter((booking, index) => new Date(booking.reservation.reservation_exit_time) < now));
            },
            (error)=>{console.log(error)}
        );
    },[])

    return (
        <div className='mybooking'>
            <div className='upcoming'>
                <h3>Upcoming</h3>
                {upcomingBookings.length > 0 ?
                upcomingBookings.map(
                        (booking1, index) => {
                          
                            return <MyBookingCardComponent paymentId={booking1.payment.paymentDetail?booking1.payment.paymentDetail.razorpayPaymentId:null}entryDate={new Date(booking1.reservation.reservation_entry_time).toLocaleDateString()} entryTime={new Date(booking1.reservation.reservation_entry_time).toLocaleTimeString()} vehicleNumber={booking1.vehicle.licenceNo}  parkingId={booking1.reservation.id} parkingSpace={booking1.parkingSpace.space_no} exitTime={new Date(booking1.reservation.reservation_exit_time).toLocaleTimeString()} exitDate={new Date(booking1.reservation.reservation_exit_time).toLocaleDateString()} price={booking1.payment.amount} bookingDetails={booking1}/>
                            // return <MyBookingCardComponent entryDate={new Date(booking1.reservation.reservation_entry_time).toLocaleDateString()} entryTime={new Date(booking1.reservation.reservation_entry_time).toLocaleTimeString()} vehicleNumber={booking1.vehicle.licenceNo} parkingSpace={booking1.parkingSpace.space_no} exitTime={new Date(booking1.reservation.reservation_exit_time).toLocaleTimeString()} exitDate={new Date(booking1.reservation.reservation_exit_time).toLocaleDateString()} price={booking1.payment.amount}/>
                    }) : <h2 style={{textAlign: 'center', padding: '20px'}}>No upcoming reservation</h2>
                    // upcomingBookings.map((completed) => {
                    //     return <MyBookingCardComponent entryDate={now.toLocaleDateString()} entryTime={now.getHours()+" : "+now.getMinutes()} vehicleNumber={"KA20ED 8745"} parkingSpace={"A10"} exitTime={now.getHours()+" : "+now.getMinutes()} exitDate={now.toLocaleDateString()} price={400}/>
                    // })
                }
            </div>
            {/* <div className='completed'>
            <h3>Parked</h3>
                {
                    parked.map((completed) => {
                        return <MyBookingCardComponent entryDate={now.toLocaleDateString()} entryTime={now.getHours()+" : "+now.getMinutes()} vehicleNumber={"KA20ED 8745"} parkingSpace={"A10"} exitTime={now.getHours()+" : "+now.getMinutes()} exitDate={now.toLocaleDateString()} price={400}/>
                    })
                }
            </div> */}
            <div className='completed'>
            <h3>Completed</h3>
                {
                    completedBookings.length > 0 ?
                    completedBookings.map(
                        (booking1, index) => {
                            return <MyBookingCardComponent entryDate={new Date(booking1.reservation.reservation_entry_time).toLocaleDateString()} entryTime={new Date(booking1.reservation.reservation_entry_time).toLocaleTimeString()} vehicleNumber={booking1.vehicle.licenceNo} parkingId={booking1.reservation.id} parkingSpace={booking1.parkingSpace.space_no} exitTime={new Date(booking1.reservation.reservation_exit_time).toLocaleTimeString()} exitDate={new Date(booking1.reservation.reservation_exit_time).toLocaleDateString()} price={booking1.payment.amount} bookingDetails={booking1}/>
                            // return <MyBookingCardComponent entryDate={new Date(booking1.reservation.reservation_entry_time).toLocaleDateString()} entryTime={new Date(booking1.reservation.reservation_entry_time).toLocaleTimeString()} vehicleNumber={booking1.vehicle.licenceNo} parkingSpace={booking1.parkingSpace.space_no} exitTime={new Date(booking1.reservation.reservation_exit_time).toLocaleTimeString()} exitDate={new Date(booking1.reservation.reservation_exit_Date).toLocaleDateString()} price={booking1.payment.amount}/>
                    }) : <h2 style={{textAlign: 'center', padding: '20px'}}>No Bookings</h2>
                    // completedBookings.map((completed) => {
                    //     return <MyBookingCardComponent entryDate={now.toLocaleDateString()} entryTime={now.getHours()+" : "+now.getMinutes()} vehicleNumber={"KA20ED 8745"} parkingSpace={"A10"} exitTime={now.getHours()+" : "+now.getMinutes()} exitDate={now.toLocaleDateString()} price={400}/>
                    // })
                }
            </div>
        </div>
    );
}