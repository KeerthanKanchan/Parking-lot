import React from "react";
import calenderIcon from '../../assets/images/calender-icon.png'
import vechicleIcon from '../../assets/images/vechicle-icon.png'
import paymentIcon from '../../assets/images/payment-icon.png'
import realTimeImg from '../../assets/images/realtime-parking.jpg'
import reserveImg from '../../assets/images/reserve.png'
import securityImg from '../../assets/images/secured-parking.jpg'
import '../../css/userHome.css'
import Button from '@mui/material/Button';
import HomePageCardComponent from "../../components/homePageCardComponent";
import FeatureCardComponent from "../../components/featureCardComponent";
import { Link } from "react-router-dom";
import { useAuth } from "../../services/auth/authContext";

function HomePage() {
    const {isAuthenticated} = useAuth();
    return (
        <div className="home-page">
            <section className="home-section1">
                <div className="home-main-text">
                    <h1>THE SOLUTION TO YOUR PARKING PROBLEMS</h1>
                    <p>The PARKIT website, which makes it easier to reserve a parking space in advance.</p>
                    <Button variant="contained" sx={{borderRadius: 10, px:4}}>
                        <Link to={isAuthenticated ? '/booking' : '/login'} style={{textDecoration:'none', color:'white'}}>Book Now</Link>
                    </Button>
                </div>
                <div></div>
            </section>
            <section className="how-it-works">
                <h1>How it works</h1>
                <div className="how-it-works-card">
                    <HomePageCardComponent image={calenderIcon} step="Step 1" stepName="Select Date and Time"/>
                    <HomePageCardComponent image={vechicleIcon} step="Step 2" stepName="Select Vechicle"/>
                    <HomePageCardComponent image={paymentIcon} step="Step 3" stepName="Make Payment"/>
                </div>
            </section>
            <section className="upcoming-features">
                <h1>Why Us?</h1>
                <div>
                    <FeatureCardComponent reverse={false} image={realTimeImg} title="Real-Time Parking Availability " description="The website will display real-time data on available parking spots in different locations, allowing users to see which areas have open spaces before they arrive."/>
                    <FeatureCardComponent reverse={true} image={reserveImg} title="Reservation System" description=" Users will be able to reserve parking spots in advance through the website, ensuring they have a spot when they reach their destination."/>
                    <FeatureCardComponent reverse={false} image={securityImg} title="Safety and security" description="Information about security measures at parking location, such as surveillance cameras, security personnel, and well-lit areas, will be provided to ensure users feel safe while parking."/>
                </div>
            </section>
            {/* <FeatureCardComponent image="" title="Platform Scale" description=""/>
                    <FeatureCardComponent image="" title="Interactive Map integration" description=""/>
                    <FeatureCardComponent image="" title="Valet Parking" description=""/>
                    <FeatureCardComponent image="" title="Mobile App Integration" description=""/>
                    <FeatureCardComponent image="" title="Dynamic pricing and discounts" description=""/>
                    <FeatureCardComponent image="" title="Electric vechicle charging station" description=""/> */}
        </div>
    )
}

export default HomePage;