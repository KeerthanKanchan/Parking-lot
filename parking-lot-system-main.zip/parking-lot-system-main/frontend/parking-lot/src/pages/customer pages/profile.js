import React, { useEffect, useId, useRef, useState } from 'react';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';
import AddAPhotoIcon from '@mui/icons-material/AddAPhoto';
import { toast } from "react-toastify"
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Typography,
  Avatar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
  Button,
  TextField,
  IconButton,
  Tooltip,
} from '@mui/material';
// import { makeStyles } from '@mui/styles';
import { grey } from '@mui/material/colors';
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from 'axios';
import NavbarComponent from '../../components/headerComponent';
import { Navigate, json, useNavigate } from 'react-router-dom';
import AddIcon from '@mui/icons-material/Add';
import AddVehicleModal from '../../components/VehicleModal';
import DeleteIcon from '@mui/icons-material/Delete';
import DirectionsBikeIcon from '@mui/icons-material/DirectionsBike';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import { useAuth } from '../../services/auth/authContext';

 

export default function ProfilePage()
{
  
   const {userId} = useAuth();
// state initalization
  const [Vehicledata, setVehicleData] = useState([]);
  var [personalDetailFieldsDisabled, setPersonalDetailFieldsDisabled]= useState(true)
  var [personalDetailTitlesWidth, setPersonalDetailsTitleWidth]= useState("auto")
  var [editPersonalDeatail,setEditPersonalDetail]= useState(false)
  var [personalDetailsTextBorder, setPersonalDetailsTextBorder]= useState('none')
  var [isProfileHoevring, setProfileHovering]= useState(false)
  var [defaultData, setdefaultData]= useState()
  var [editAddressDeatail, setEditAddressDetail]= useState(false)
  var [addressDetailFieldsDisabled, setAddressDetailFieldsDisabled]= useState(true)
  var [addressDetailTitlesWidth, setAddressDetailsTitleWidth]= useState("70px")
  var [addressDetailsTextBorder, setAddressDetailsTextBorder]= useState('none')
  var imageuploaderRef=useRef(null);
  var[modalState, setModalState]= useState(false)
  var[modalMethod, setModalMethod]= useState("ADD")
  var [vehicleModalValue,setVehicleModalData]=useState( { 
    licenceNo: "",
    customerId: userId,
    manufacturer: "",
    model: "",
    color: "",
    vehicleType: "2",
    additionalInfo:"",
  })


  var [profileData,setprofileData]=useState(
    {"profile":"",
      email:"",
      name:"",
      phoneNo:"",
      address:"",
      landmark:"",
      city:"",
      state:"",
      country:"",
      pin:""
    });
  const [formEmptyMessage, setEmptyMessage] = useState({
    name: "enter first name",
    lastName: "enter last name",
    email: "enter email address",
    phoneNo: "enter phone number",
    address: "enter address",
    landmark:"enter landmark",
    city: " enter city name",
    state: "enter state name",
    country: "enter country name",
    pin:"enter pincode",
    password:"enter password",
    repassword:"enter re-password"
  });


  const theme = createTheme();

  //styles
   const profileStyles = {
     root: {
    flexGrow: 1,
    padding: theme.spacing(4),
     
    [theme.breakpoints.up('md')]: {
      height: 'calc(100vh - 40px)', 
      overflow: 'hidden',
    },
  },

   profileImage: {
     width: 150,
     height: 150,
     objectFit: 'cover',
     margin: '10px auto',
     border: '10px solid lightblue',
     borderRadius: '50%',
   },
   card: {
     borderRadius: 5,
     boxShadow: theme.shadows[3],
     backgroundColor:"white"
   },
   header: {
     backgroundColor: "#182c44b5",
     textAlign: 'center',
     padding: theme.spacing(2),
   },
   cardHeader: {
     fontSize: 20,
     fontWeight: 700,
     color:"#66FCF1",
   },
   cardContent: {
     fontSize: 16,
     color:"#000",
   },
   vehicleCard: {
    [theme.breakpoints.up('md')]: {
      height: 'calc( 50% - 15px)',
      overflow: 'hidden',
    },
    },
    AddressCard: {
      [theme.breakpoints.up('md')]: {
        minHeight: 'calc( 50% - 15px)',
        height: 'calc( 50% - 15px)'
      },
    },
    personalDetailCardContent:{
    
        marginTop: theme.spacing(3),
        display:"flex",
        alignItems: "center", 
        height:"auto",
        paddingBottom:"10px"
    },
    personaleditButton:{
      top: "-15px",
      position: "relative",
      right: "calc(-100% + 30px)",
      width:"30px",
      hight:"30px",
      borderRadius:"12px",
      
     
    },
    personalsubmitButton:{
      top: "-15px",
      position: "relative",
      right: "calc(-100% + 30px)",
      width:"30px",
      hight:"30px",
      borderRadius:"12px",  
    },
    personalDetailsField:{
      
      size:"small",
      color: "#000",
     
      '& fieldset': {
          border: personalDetailsTextBorder, 
        },
        "& .MuiOutlinedInput-input":{
          paddingTop:"3px",
          paddingBottom:"3px",
        },
      "& .MuiInputBase-input.Mui-disabled": {
        color: "#000",
        WebkitTextFillColor: "#000"
        
      },
    },
    personalDetailsTitle:{
      width:personalDetailTitlesWidth,
      
    
    },

    addressEditButton:{
      top: "-15px",
      position: "relative",
      right: "calc(-100% + 30px)",
      width:"30px",
      hight:"30px",
      borderRadius:"12px",
       
     
    },
   addressSubmitButton:{
      top: "-15px",
      position: "relative",
      right: "calc(-100% + 30px)",
      width:"30px",
      hight:"30px",
      borderRadius:"12px",

     
    },
    addressDetailsField:{
      
      size:"small",
  
      '& fieldset': {
          border: addressDetailsTextBorder, 
        },
        "& .MuiOutlinedInput-input":{
          paddingTop:"3px",
          paddingBottom:"3px", 
          color:"#000"
        },
        "& .MuiInputBase-input.Mui-disabled": {
        color: "#000",
        WebkitTextFillColor: "#000"
        
      },
    },
    addressDetailsTitle:{
      width:addressDetailTitlesWidth,
    
    },
    addressDetailCardContent:{
    
        paddingTop:"0.5%",
        display:"flex",
        alignItems: "center", 
        height:"auto"
    },
    viehicleAddButton:{
      top: "-15px",
      position: "relative",
      right: "calc(-100% + 30px)",
      width:"30px",
      hight:"30px",
      borderRadius:"12px",
      
     
    },

    TableCell:{
     
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      alignContent: "center",
      alignItems: "center",
      border:0,
      width:"18%",
      padding: "1%",
      
    },
    tableRow:{
      width:"100%", 
      display: 'flex',
      flexDirection: 'row ',
     justifyContent: "space-between",
     border: "1px solid rgba(224, 224, 224, 1)"
    }
   }

  
   //use efffect  and get personal detailand address detail and vehicle data
   useEffect(()=>{
    
   
        axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/profileData",{id:userId},{
          headers: {
            'Content-Type': 'application/json',
          }
        }).then((response)=>{
          
          setprofileData(response.data);
          setdefaultData(response.data)
          
        }).catch((err)=>{
  
            toast.error("something went wrong")
  
        })
        axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/getVehicle",{customerId:userId},{
          headers: {
            'Content-Type': 'application/json',
          }
        }).then((response)=>{
          
          setVehicleData(response.data)
         
          
        }).catch((err)=>{
  
            toast.error("something went wrong")
  
        })

   },[])

  

   //handle all data changes
   function handleDataChange(e){
    
    setprofileData({ ...profileData, [e.target.name]: e.target.value });

   }

 // validate if any field is empty
  function isFieldEmpty()
  {
      for(var key of Object.keys(profileData))
          {
              if(profileData[key]==''&&key!="profile")
                  {
                   
                      toast.error(formEmptyMessage[key])
                      return true
                  }
          }
          return false;
  }

  //personal detail edit button handler change readonly mode to  edit mode

  function handlePersonalDetailsEdit()
  {
    setPersonalDetailFieldsDisabled(false)
    setPersonalDetailsTitleWidth("100px")
    setEditPersonalDetail(true)
    setPersonalDetailsTextBorder("solid gray")
  }

  // save personal data changes to database and change to read only mode

  function handlePersonalDetailsSubmit()
  {

    var emailRegex=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    var phoneNoRegex=/^\d{10}$/;
   
    
    if(isFieldEmpty())
    {           
        
    }
    else if(!emailRegex.test(profileData.email))
    {
        toast.error("enter valid email address")
    }
    else if(!phoneNoRegex.test(profileData.phoneNo))
     {
        toast.error("enter valid phone number")
    }
    else{
     

      if(defaultData.email!=profileData.email||defaultData.phoneNo!=profileData.phoneNo||defaultData.name!=profileData.name)
      {
        var formData={email:profileData.email,phoneNo:profileData.phoneNo,name:profileData.name,id:userId}
      
        axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/updateProfile", formData,{
          headers: {
            'Content-Type': 'multipart/form-data',
          }
        }).then((response)=>{
          toast.success(response.data)
          setdefaultData({...defaultData,...profileData});
        })
        .catch((err)=>{
          if(err.response){
            toast.success(err.response.data.result)
          }
          else{
            toast.success("couldnt able to connect to server")
          }
          setprofileData({...profileData,...defaultData})
        })
      }
      setPersonalDetailFieldsDisabled(true)
      setPersonalDetailsTitleWidth("auto")
      setEditPersonalDetail(false)
      setAddressDetailsTextBorder("none")
      setPersonalDetailsTextBorder("none")
    }
   
  }

  // enable editing of adress fields 
  function handleAddressDetailsEdit()
  {
    setAddressDetailFieldsDisabled(false)
    setAddressDetailsTitleWidth("100px")
    setEditAddressDetail(true)
    setAddressDetailsTextBorder("solid gray")
  }

  // save address data changes to database and change to read only mode

  function handleAddressDetailsSubmit()
  {
    if(!isFieldEmpty())
    {
    if(defaultData.address!=profileData.address||defaultData.landmark!=profileData.landmark||
      defaultData.city!=profileData.city||defaultData.state!=profileData.state||defaultData.country!=profileData.country||defaultData.pin!=profileData.pin)
      {
        var formData={address:profileData.address,landmark:profileData.landmark,city:profileData.city,state:profileData.state, country:profileData.country, pin:profileData.pin,id:userId}
      
        axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/updateProfile", formData,{
          headers: {
            'Content-Type': 'multipart/form-data',
          }
        }).then(async (response)=>{

          toast.success(response.data)
          await setdefaultData({...defaultData,...profileData});
         

        })
        .catch((err)=>{
          if(err.response){

            toast.success(err.response.data.result)

          }
          else{

            toast.success("couldnt able to connect to server")
            
          }
         
        })
      }
   
      setAddressDetailFieldsDisabled(true)
      setAddressDetailsTitleWidth("70px")
      setEditAddressDetail(false)
      setAddressDetailsTextBorder("none")

    }
  }
  //on add vehicle click set modal state to true
  function onAddVehicleClick()
  {
    setVehicleModalData( { 
      licenceNo: "",
      customerId: userId,
      manufacturer: "",
      model: "",
      color: "",
      vehicleType: "2",
      additionalInfo:"",
    })
    setModalMethod("ADD")
    setModalState(true)
  }
// on edit vehicle data
function onEditVehice(data)
{

  setVehicleModalData({ 
    id:data.id,
    licenceNo: data.licenceNo,
    customerId: data.customerId,
    manufacturer:data.manufacturer,
    model: data.model,
    color: data.color,
    vehicleType: data.vehicleType,
    additionalInfo:data.additionalInfo, 
  })
  setModalMethod("EDIT")
  setModalState(true)

}

// on delete veichle delete vehicle and update behicle data
function onVehicleDelete(id)
{
 
  var form={id:id}
  axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/deleteVehicle",form,{
    headers: {
       'Content-Type': 'application/json'
    }
  }).then((response)=>{

    toast.success(response.data)
    const updatedVehicleData = Vehicledata.filter(item => item.id !== id);
    setVehicleData(updatedVehicleData)

  })
  .catch((err)=>{
    if(err.response){

      toast.success(err.response.data)

    }
    else{
      toast.success("couldnt able to connect to server")
    }
    
  })
}

//on upload click call hidden image file input 
function onUploadProfile(){

  if(imageuploaderRef!=null)
    {
        imageuploaderRef.current.click()
    }

}


  //on image change get image and save it 
  async function onImageChange(e)
  {
    const file = e.target.files[0];
    if (file) {
      var formData={profile:file,id:userId}
      axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/updateProfile", formData,{
        headers: {
          'Content-Type': 'multipart/form-data',
        }
      }).then((response)=>{
        toast.success("profile Updated sucessfully")
        profileData.profile=response.data
        setprofileData(profileData)
        
      })
      .catch((err)=>{
        toast.success(err.response.data.result)
      })
    
    
    }
  }
  

  return (
    <ThemeProvider theme={theme}>
     
     <Container maxWidth="lg" sx={profileStyles.root}>
      <Grid container spacing={4} sx={{[theme.breakpoints.up('md')]: {
      height: '100%', 
      overflow: 'auto',
    }}}>
      <Grid item xs={12} md={4}>
            <Card sx={profileStyles.card}>
              <CardHeader 
             
               sx={{...profileStyles.header,...profileStyles.cardHeader}}
               
                subheader={
                  isProfileHoevring?

                        <Avatar onMouseEnter={()=>{setProfileHovering(true)}} onMouseLeave={()=>{setProfileHovering(false)}}
                        onClick={onUploadProfile}
                        alt=""
                        sx={profileStyles.profileImage} >
                          
                          <AddAPhotoIcon sx={{fontSize:"large",width:"50%",height:"50%"}}/>
                          <input   onChange={onImageChange} ref={imageuploaderRef} style={{visibility:"hidden",position:"absolute"}} type="file" accept="image/*"></input>
                        
                        </Avatar>
                        :
                        <Avatar onMouseEnter={()=>{setProfileHovering(true)}} onMouseLeave={()=>{setProfileHovering(false)}}
                        alt=""
                        src={`data:image/jpeg;base64,${profileData.profile}`}
                        sx={profileStyles.profileImage} />
                }
              />
              <CardContent sx={{...profileStyles.cardContent,...profileStyles.personalDetailCard}}>
                {editPersonalDeatail? 
                <Button sx={profileStyles.personalsubmitButton} onClick={handlePersonalDetailsSubmit}>  
                 <CheckIcon></CheckIcon> 
                 </Button>
              
                 :
                <Button sx={profileStyles.personaleditButton} onClick={handlePersonalDetailsEdit} > 
                    <EditIcon ></EditIcon>
                </Button>}

                  <Typography variant="body1" sx={profileStyles.personalDetailCardContent}>
                    <strong style={profileStyles.personalDetailsTitle}>Name</strong>: 
                    <TextField name='name' autoComplete="off" onChange={handleDataChange} sx={profileStyles.personalDetailsField} value={profileData.name} disabled={personalDetailFieldsDisabled}/>
                  </Typography>

                  <Typography variant="body1" sx={profileStyles.personalDetailCardContent}>
                    <strong style={profileStyles.personalDetailsTitle}>Email</strong>: 
                    <TextField name='email' autoComplete="off"  onChange={handleDataChange} sx={profileStyles.personalDetailsField}   value={profileData.email} disabled={personalDetailFieldsDisabled}/>

                  </Typography>

                  <Typography variant="body1" sx={{marginBottom:"60px",...profileStyles.personalDetailCardContent}}>
                    <strong style={profileStyles.personalDetailsTitle}  >Phone</strong>: 
                    <TextField name='phoneNo' autoComplete="off" onChange={handleDataChange} sx={profileStyles.personalDetailsField}  value={profileData.phoneNo} disabled={personalDetailFieldsDisabled}/>
                  </Typography>
              </CardContent>
            </Card>
          </Grid>



          <Grid item xs={12} md={8}  sx={{[theme.breakpoints.up('md')]: {
      height: '100%', 
      overflow: 'auto',
      paddingRight:"10px"
    }}} >
            <Card sx={{ ...profileStyles.card, ...profileStyles.vehicleCard }}>
              <CardHeader
                 sx={{...profileStyles.header,...profileStyles.cardHeader}}
                title={
                  <>
                    <i className="far fa-clone pr-1" />
                   VEHICLE DETAILS
                  </>
                }
              />

               
              <CardContent sx={{[theme.breakpoints.up('md')]: {height:"calc(100% - 100px)"}}}>
                <Button sx={profileStyles.viehicleAddButton} onClick={onAddVehicleClick} > 
                      <AddIcon ></AddIcon>
                </Button>

          <TableContainer  sx={{width:"100%", display: 'flex',flexDirection: 'column',height:"100%"}}>
          <TableBody sx={{ flex: '1 1 auto',overflowY: 'auto',display: 'block'}}>

          {Vehicledata.length>0? 
             Vehicledata.map((item) => (
            <TableRow  sx={profileStyles.tableRow}key={item.id}>

            <Tooltip title={"vehicle"} arrow>
              <TableCell  sx={profileStyles.TableCell}>{item.manufacturer} {item.model}</TableCell>
              </Tooltip>

              <Tooltip title={"licence no"} arrow>
              <TableCell  sx={profileStyles.TableCell}>{item.licenceNo}</TableCell>
          </Tooltip>

            <Tooltip title={"type"} arrow>
              <TableCell sx={profileStyles.TableCell}>
                {item.vehicleType == "2" ? <DirectionsBikeIcon  sx={{color:item.color}}/> : <DirectionsCarIcon  sx={{color:item.color}} />}
              </TableCell>
              </Tooltip>

              <TableCell  sx={profileStyles.TableCell}>
                <IconButton onClick={()=>{ 
                onEditVehice(item,item.vehicleType)}} >
                  <EditIcon />
                </IconButton>
              </TableCell>

              <TableCell sx={profileStyles.TableCell}>
                <IconButton  onClick={()=>{onVehicleDelete(item.id)}}>
                  <DeleteIcon />
                </IconButton>
              </TableCell>

            </TableRow>
          ))
          :
          <h4 style={{width:"100%", textAlign:"center"}}> click plus symbol to add new vehicle.....</h4>}
        </TableBody>
     </TableContainer>

              </CardContent>
              </Card>


            <div style={{ height: 26 }} />


            <Card sx={{ ...profileStyles.card, ...profileStyles.AddressCard}}>
              <CardHeader
                sx={{...profileStyles.header,...profileStyles.cardHeader}}
                title={
                  <>
                    <i className="far fa-clone pr-1" />
                    ADDRESS DETAILS
                  </>
                }
              />
              <CardContent sx={profileStyles.cardContent}>
              {editAddressDeatail? 
                <Button sx={profileStyles.addressSubmitButton} onClick={handleAddressDetailsSubmit}>  
                 <CheckIcon></CheckIcon> 
                 </Button>
              
                 :
                <Button sx={profileStyles.addressEditButton} onClick={handleAddressDetailsEdit} > 
                    <EditIcon ></EditIcon>
                </Button>}
               

                <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>Address</strong>: 
                    <TextField name='address'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.address} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>Landmark</strong>: 
                    <TextField name='landmark'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.landmark} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>City</strong>: 
                    <TextField name='city'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.city} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                  </Grid>
                  
                  <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>State</strong>: 
                    <TextField name='state'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.state} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                  </Grid>

                  <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>Country</strong>: 
                    <TextField name='country'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.country} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                  </Grid>

                  <Grid item xs={12} sm={6}>
                  <Typography variant="body2" sx={profileStyles.addressDetailCardContent}>
                    <strong style={profileStyles.addressDetailsTitle}>Pin</strong>: 
                    <TextField name='pin'  autoComplete="off" onChange={handleDataChange} sx={profileStyles.addressDetailsField} value={profileData.pin} disabled={addressDetailFieldsDisabled}/>
                  </Typography>
                </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

            

        </Grid>
      </Container>
      <AddVehicleModal setVehicleData={setVehicleData} Vehicledata={Vehicledata}setModalState={setModalState} ModalState={modalState}  method={modalMethod} defaultValue={vehicleModalValue}/>
               
    </ThemeProvider>
  );
}