import React from 'react';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import { blue, red } from '@mui/material/colors';
import { useState } from 'react';
import { act } from 'react';
import dayjs from 'dayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateTimeRangePicker } from '@mui/x-date-pickers-pro/DateTimeRangePicker';
import { renderTimeViewClock} from '@mui/x-date-pickers/timeViewRenderers';
import { Button } from '@mui/material';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Grid from '@mui/material/Grid';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import '../../css/booking.css'
import AddIcon from '@mui/icons-material/Add';
import {Typography} from '@mui/material';
import { useEffect } from 'react';
import { getSlot, generateOrder, getVehicle } from '../../services/ApiService';
import { useAuth } from '../../services/auth/authContext';
import axios from 'axios';
import logo from '../../assets/images/entry.png';
import { useNavigate } from 'react-router-dom';
import AddVehicleModal from '../../components/VehicleModal';
import { toast } from 'react-toastify';




const steps = [
    'Select Date and Time',
    'Choose vechicle', 
    'Confirm Booking',
];

const parkingType = ['2', '4'];

const Item = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(1),
    color: 'black',
    }));

    function loadScript(src) {
        return new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = () => {
                resolve(true);
            }
            script.onerror = () => {
                resolve(false)
            };
            document.body.appendChild(script);
        });
    }


export default function BookingPage() {
    const [activeStep, setActiveStep] = useState(0);
    const [completed, setCompleted] = useState({});

    const [vechicleList, setVechicleList] = useState([]);
    const [selectedVechicle, setSelectedVechicle] = useState();
    const [selectedModel, setSelectedModel] = useState();
    const [selectedVechicleId, setSelectedVechicleId] = useState();
    const [selectedInputVechicle, setSelectedInputVechicle] = useState();

    const [typeValue, setTypeValue] = useState();
    const [typeInputValue, setTypeInputValue] = useState();
    const [orderResponse, setOrderResponse] = useState(null);

    const [price, setPrice] = useState(0);
    const [bookingDate, setBookingDate] = useState([]);
    const now = new Date();
    const [error, setError] = useState(null);
    const [availableSpace, setAvailableSpace] = useState();

    const [displayRazorPay, setDisplayRazorPay] = useState(false);

    const {userId} = useAuth();
    var navigate = useNavigate();
    const isButtonDisabled = !bookingDate[0] || !bookingDate[1] || !!error;
    const isButtonDisabledSecondScreen = !typeValue || !selectedVechicle;
    var[modalState, setModalState]= useState(false)
  
  var [vehicleModalValue,setVehicleModalData]=useState( { 
    licenceNo: "",
    customerId: userId,
    manufacturer: "",
    model: "",
    color: "",
    vehicleType: "2",
    additionalInfo:"",
  })
    console.log("7th Day: ", dayjs().add(7, 'days'));
    useEffect(()=>{
        // Hit Get vechicle list API and setthe data in callback
        getVehicle({customerId: userId},
            (response) => {
                console.log(response)
                setVechicleList(response)
            },
            (error) => {
                console.log(error)
                toast.error("Something went wrong, please try again.")
            }
        )
    },[]);

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    };

    const checkAvailabilityHandleNext = async() => {

        console.log(typeValue, " : ", typeInputValue);
        console.log(selectedVechicle, " : ", selectedInputVechicle);
        console.log("Full: ",bookingDate);
        console.log("Part 1: ", bookingDate[0]);
        console.log("Part 2: ", bookingDate[1]);
        setOrderResponse(null)
        await getSlot(
            {
                entryTime: bookingDate[0],
                exitTime: bookingDate[1],
                vehicleType: typeInputValue,
                vechicleId: "50",
                userId: userId
            },
            (response) => {
                console.log(response);
                setAvailableSpace(response)
                setActiveStep((prevActiveStep) => prevActiveStep + 1);
                
            },
            (error,message) => {
                console.log(Error)
                toast.error(message)
            }
        );
    };

    const handleback = () => {
        setActiveStep((prevActiveStep)=>prevActiveStep-1);
    };

    const handleDateChange = (dates) => {
        console.log(dates)
        setBookingDate(dates);
        dateRangeValidators(dates);
    }

    const dateRangeValidators = (dates) => {
        const [start, end] = dates;
        if (start && end ) {
            const diff = end - start;
            console.log(diff);
            const timeDifference = diff / (1000 * 60 * 60);

            if (timeDifference < 1) {
                setError("There should be a minimum 1-hour gap between the selected dates.");
            } else {
                setError(null);
            }
            console.log("Fun: ",bookingDate)
            console.log("Fun1: ",bookingDate[0])
            console.log("Fun2: ",bookingDate[1])
        } else {
            setError(null);
        }
    }


    async function paymentGateway(result)
    {
        
        const {amount, id: order_id, currency} =orderResponse==null ?result:orderResponse      
        console.log("test1 before option");
        const options = {
            key: "rzp_test_QnZqng7pQVvf4L",
            amount: amount.toString(),
            currency: currency,
            name: "PARKIT Corp.",
            description: "Test Trans",
            image: {logo},
            order_id: order_id,
            handler: async function (response) {
                const vehicleId = vechicleList.filter(vehicle => vehicle.licenceNo === selectedVechicle);
                console.log("Id: ",vehicleId);
                console.log(vehicleId[0].id)

                const data = {
                    orderCreationId: order_id,
                    razorpayPaymentId: response.razorpay_payment_id,
                    razorpayOrderId: response.razorpay_order_id,
                    razorpaySignature: response.razorpay_signature,
                    bookingSlotFile: availableSpace.bookingSlotFile,
                    paymentDetail: {orderId:order_id,test:"1"},
                };
                console.log("test1 before result", bookingDate);
                
                const result = await axios.post("http://localhost:8080/customer/reserve", {bookingSlotFile:availableSpace.bookingSlotFile,vehicle_id:vehicleId[0].id, paymentDetail:data})
                .then((res)=>{
                    navigate('/my-bookings');
                    toast.success("Booking confirmed.")
                })
                .catch((err) => {
                    if(err.response)
                    {
                    toast.error(err.response.data.message)
                    }
                });
                
             
            },
            notes: {
                address: "PARKIT Corporate Office",
            },
            theme: {
                color: "#61dafb",
            },
        };

        const paymentObject = new window.Razorpay(options);
        paymentObject.open();

    }
    const handleBooking = async () => {
        // confirm the booking
        // console.log(availableSpace)
        const res = await loadScript(
            "https://checkout.razorpay.com/v1/checkout.js"
        );

        if(!res) {
            alert("RazorPay SDK failed to load, try again after some time");
            return;
        }
    
        // api to create new orde"r
        if(await orderResponse==null)
        {

        const result = await axios.post(
            "http://localhost:8080/customer/generateOrder",
            {
                amount: availableSpace.price,
                bookingSlotFile:availableSpace.bookingSlotFile,
            }
        ).catch((err)=>{
            if(err.response)
                {
                toast.error(err.response.data.message)
                }
        })
        
        
     await setOrderResponse(result.data);
     paymentGateway(result.data)
    }
    else
    {
        paymentGateway();
    }
        

     }

    return (
        <div className='booking-page'>
            <div className='booking-stepper'>
                <Box sx={{width:'100%', color: red}}>
                    <Stepper activeStep={activeStep} alternativeLabel>
                        {steps.map((label, index) => (
                            <Step key={label} completed={completed[index]} sx={{
                                '& .MuiStepLabel-root .Mui-completed': {
                                    color: '#66FCF1', // circle color (COMPLETED)
                                },
                                '& .MuiStepLabel-label.Mui-completed.MuiStepLabel-alternativeLabel': {
                                    color: '#66FCF1', // Just text label (COMPLETED)
                                    },
                                '& .MuiStepLabel-root .Mui-active': {
                                    color: '#C5C6C7' // circle color (ACTIVE)
                                },
                                '& .MuiStepLabel-label.Mui-active.MuiStepLabel-alternativeLabel': {
                                    color: '#C5C6C7', // Just text label (ACTIVE)
                                    },
                                '& .MuiStepLabel-root .Mui-active .MuiStepIcon-text': {
                                    fill: 'black', // circle's number (ACTIVE)
                                },
                                '& .MuiStepLabel-label': {
                                    color: '#C5C6C7',
                                },
                            }} >
                                <StepLabel >{label}</StepLabel>
                            </Step>
                        ))}
                    </Stepper>
                </Box>
            </div>
            {
                activeStep === steps.length - 1 ? (
                    <div className='confirmation' >
                            <Box sx={{ width: '100%', mb: 6, mt:6,  }}>
                                <Grid container >
                                <Grid item xs={12}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'#C5C6C7',borderRadius:'10px 10px 0 0'}}> <strong>Booking Details: </strong></Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>Entry</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>{new Date(availableSpace.entryTime).toLocaleDateString()+" "+new Date(availableSpace.entryTime).toLocaleTimeString()}</Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>Exit</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>{new Date(availableSpace.exitTime).toLocaleDateString()+" "+new Date(availableSpace.exitTime).toLocaleTimeString()}</Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>Parking Space No</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>{availableSpace.space_id}</Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>Type</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>{typeValue}</Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>Model</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0}}>{selectedModel}</Item>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderRadius:0, borderEndStartRadius: '10px'}}>Vehicle Number</Item>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Item sx={{textAlign:'start', pl:4, bgcolor:'white',borderEndEndRadius: '10PX'}}>{selectedVechicle}</Item>
                                    </Grid>
                                </Grid>
                            </Box>
                        <div style={{display:'flex', justifyContent: 'space-between'}}>

                        <Button variant='outlined' onClick={handleback}>Back</Button>
        
                        <Button variant='contained'sx={{ml: 2, color:'white!important'}} onClick={handleBooking}>Pay</Button>
                        </div>
                    </div>  
                ) : activeStep === 0 ?
                (
                    <div className='dateTime'>
                        <div className='entryExitDateTime'>
                            <LocalizationProvider dateAdapter={AdapterDayjs} >
                                <DateTimeRangePicker viewRenderers={{
                                    hours: renderTimeViewClock,
                                    minutes: renderTimeViewClock
                                }}
                                disablePast = {true}
                                maxDate={dayjs().add(7, 'days')}
                                value={bookingDate}
                                sx={{m:4, 
                                    '& .MuiInputBase-input': {
                                        backgroundColor: '#C5C6C7' ,
                                        borderRadius: 1
                                    }}}
                                onChange={handleDateChange}
                                />
                            </LocalizationProvider>
                            {error && (
                        <Typography color="error" variant="body2">
                        {error}
                    </Typography>
                )}
                        <Button variant='contained' sx={{m:2, color:'white!important'}}  onClick={handleNext} disabled={isButtonDisabled}>Next</Button>
                        </div>
                    </div>

                ) : (
                    <div className='selectvechicle'>
                        <Autocomplete value={typeValue}
                            onChange={(event, newValue) => {
                                console.log("On Change: ",newValue);
                                setTypeValue('')
                                setSelectedVechicle('');
                                setSelectedInputVechicle('');
                                setTypeValue(newValue);
                            }}
                            inputValue={typeInputValue}
                            onInputChange={(event, newValue) => {
                                console.log("On Input change: ",newValue);
                                setTypeInputValue(newValue);
                            }}
                            
                            options={parkingType}
                            renderInput={(params) => <TextField {...params} label="Select Type" sx={{ bgcolor:"#C5C6C7", borderRadius:1 }}/>}
                            sx={{mb:4}}
                        />
                        <div style={{display:'flex'}}>
                      
                        <Autocomplete
                            value={selectedVechicle}
                            onChange={(event, newValue) => {
                                console.log("On Change: ", newValue);
                                setSelectedVechicle(newValue);
                                setSelectedModel(vechicleList.filter(vehicle => vehicle.licenceNo === newValue)
                                .map(vehicle =>{
                                    return vehicle.model
                                })
                            )}}

                            inputValue={selectedInputVechicle}
                            onInputChange={(event, newValue) => {
                                console.log("On Input change: ", newValue);
                                setSelectedInputVechicle(newValue);

                            }}
                            options={vechicleList
                                .filter(vehicle => vehicle.vehicleType === typeValue)
                                .map(vehicle => {
                                    
                                    return vehicle.licenceNo
                                })
                            }
                            disabled={!typeValue}
                            renderInput={(params) => <TextField {...params} label="Select Vehicle" sx={{ bgcolor: "#C5C6C7", borderRadius: 1 }} />}
                            sx={{ mb: 2, width: '90%' }}
                        />
                        <Button variant='contained' sx={{display:'inline', height:'56px', ml: 2, alignItems: 'center'}} 
                        onClick={
                            ()=>{ setVehicleModalData({  licenceNo: "",
                                customerId: userId,
                                manufacturer: "",
                                model: "",
                                color: "",
                                vehicleType: "2",
                                additionalInfo:"",
                            })
                            setModalState(true)}}>
                            <AddIcon sx={{display: 'flex', ml:0.5, color:'white!important'}}/>
                                
                            </Button>
                        </div>
                        <Button variant='outlined' sx={{mt:4}}  onClick={handleback}>Back</Button>
                        <Button variant='contained' sx={{mt:4, ml:2,color:'white!important'}}  onClick={checkAvailabilityHandleNext} disabled={isButtonDisabledSecondScreen}>Next</Button>
                    </div>
                )
            }
            { displayRazorPay && (
                <div>

                </div>
            )}

            <AddVehicleModal setVehicleData={setVechicleList} Vehicledata={vechicleList} setModalState={setModalState} ModalState={modalState}  method={"ADD"} defaultValue={vehicleModalValue}/>

        </div>
    )
}
