import React, { useState } from "react"
import { toast } from "react-toastify"
import axios, { Axios } from "axios";
import { Avatar, Box, Button, Checkbox, FormControlLabel, Grid, TextField, Typography } from "@mui/material";
import { Link, Navigate, useNavigate } from "react-router-dom";
import CssBaseline from "@mui/material/CssBaseline";
import Paper from "@mui/material/Paper";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { Container } from "@mui/material";
import useMediaQuery from '@mui/material/useMediaQuery';
export default function SignUp()
{
   var navigate=useNavigate()
    const defaultTheme = createTheme();
    const isMobile = useMediaQuery(defaultTheme.breakpoints.down('sm'))
    const [formData, setFormData] = useState({
      
        name: "",
        email: "",
        phoneNo: "",
        address: "",
        city: "",
        state: "",
        country: "",
        pin:"",
        password:"",
        repassword:""
      });
 
      const [formEmptyMessage, setEmptyMessage] = useState({
        name: "enter first name",
        lastName: "enter last name",
        email: "enter email address",
        phoneNo: "enter phone number",
        address: "enter address",
        city: " enter city name",
        state: "enter state name",
        country: "enter country name",
        pin:"enter pincode",
        password:"enter password",
        repassword:"enter re-password"
      });
    const [isLoading,setIsLoading]=useState(false);

    function isFieldEmpty()
    {
        for(var key of Object.keys(formData))
            {
                if(formData[key]=='')
                    {
                        toast.error(formEmptyMessage[key])
                        return true
                    }
            }
            return false;
    }

    function handleChange(e)
      {
        setFormData({ ...formData, [e.target.name]: e.target.value });

      }

   
      function handleSubmit(e)
      { 
       
        var emailRegex=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        var passwordRegex=/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{7,}$/;
        var phoneNoRegex=/^\d{10}$/;
        if(isFieldEmpty())
        {           
                
        }
        else if(!emailRegex.test(formData.email))
        {
            toast.error("enter valid email address")
        }
        else if(!phoneNoRegex.test(formData.phoneNo))
         {
            toast.error("enter valid phone number")
        }
        else if (!passwordRegex.test(formData.password))
        {
            toast.error("password should have at least one uppercase and lowercase letter ")
            toast.error("password should have atleast one special character")
            toast.error("paswword should have atleast one number")
            toast.error("password should have atleast 7 characters")
        }
        else if (formData.password!==formData.repassword)
        { 
            toast.error("repassword doesnt match password")
        }
        else{
          setIsLoading(true)
          axios.post(process.env.REACT_APP_CUSTOMER_BACKEND_URL+"/signup", formData,{
            headers: {
              'Content-Type': 'application/json'
            }
          })
          .then((response)=>{
              toast.success(response.data.result);
              setIsLoading(false)
              navigate("/login")
              
          }).catch((err)=>{
           
              toast.error(err.response.data.result)
              setIsLoading(false)
          })
        }
        
      }
    return(<> 
    <ThemeProvider theme={defaultTheme}  sx={{
        }}>
    <Box
        sx={{
          backgroundImage: `url(${process.env.REACT_APP_LOGIN_BG})` ,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box 
            sx={{
              backgroundColor: "rgba(245, 245, 245, 0.9)",
              borderRadius: "5%",
              padding: "5%",
              width: "35vw",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              minWidth:"340px",
              margin: 'auto'
            }}
          >
          <Avatar sx={{ m: -1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5" sx={{mt:2}}>
            Sign up
          </Typography>
          <Box  onSubmit={handleSubmit} sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={6} sm={6}>
                <TextField
                  autoComplete="name"
                  name="name"
                  required
                  id="name"
                  label="Name"
                  autoFocus
                   size="small"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="phoneNo"
                  label="Phone number"
                  name="phoneNo"
                   type="number"
                  autoComplete="phoneNo"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="email"
                  label="Email Address"
                  name="email"
                  type="email"
                  autoComplete="email"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="city"
                  label="city"
                  name="city"
                  type="text"
                  autoComplete="city"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="state"
                  label="state"
                  name="state"
                  type="text"
                  autoComplete="state"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="country"
                  label="country"
                  name="country"
                  type="text"
                  autoComplete="country"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  id="pin"
                  label="pin"
                  name="pin"
                  type="text"
                  autoComplete="pin"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                 size="small"
                  id="landmark"
                  label="land mark"
                  name="landmark"
                  type="text"
                  autoComplete="land mark"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                 size="small"
                  id="address"
                  label="address"
                  name="address"
                  type="text"
                  autoComplete="pin"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                  size="small"
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="password"
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={6} sm={6}>
                <TextField
                  required
                 size="small"
                  name="repassword"
                  label="re enter the password"
                  type="password"
                  id="repassword"
                  autoComplete="repassword"
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
            <Grid container justifyContent='center'>
            <Grid item>
            <Button
              type="submit"
              size="small"
              variant="contained"
              sx={{ mt: 3, mb: 2, color:"white!important"}}
              onClick={handleSubmit}
              >
              Sign Up
            </Button>
              </Grid>
              </Grid>
            <Grid container justifyContent="center">
              <Grid item>
              <Link to="/login" variant="body2">
                 {" Already have an account? Sign in"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
      </Box>
    </ThemeProvider>

        {/* <div style={{width:"100vw",height:"100vh",backgroundColor:"red"}} >

        
            <input onChange={handleChange} name="name" placeholder="full name"  />
            
            <input  onChange={handleChange}  type="email" name="email" placeholder="email" />
            <input  onChange={handleChange} name="phoneNo" placeholder="phone no" type="number" />
            
            <input onChange={handleChange}  name="address" placeholder="address" />
            <input  onChange={handleChange} name="city" placeholder="city" requircityed/>
            <input  onChange={handleChange} name="state" placeholder="state" />
            <input  onChange={handleChange} name="country" placeholder="country" />
            <input  onChange={handleChange} name="pin" placeholder="pin" />
            <input  onChange={handleChange} name="password" placeholder="password"  type="password"/>
            <input  onChange={handleChange} name="repassword" placeholder="re-password"  type="password"/>
            
            
            {
             isLoading?
            <button>...loading</button>
            :
            <button onClick={handleSubmit}> signup</button>
            }
        
    </div> */}
    </>)
}