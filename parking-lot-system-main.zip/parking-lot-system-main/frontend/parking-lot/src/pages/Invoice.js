import {React, useRef} from 'react';
import '../css/Invoice.css';
import ParkLogo from "../assets/images/Parking-Sign.png"; 
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Button } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
// import {myBookingsApi} from '../../services/ApiService';



const InvoicePage = () => {
    const details = JSON.parse(localStorage.getItem('invoiceDetails'));
    console.log("siuuuuuuuuuuuuuuuu",details);
    var dt = new Date(details.payment.date).toLocaleDateString();
    console.log("siuuuuuuuuuuuuuuuu2",dt);

    const pdfRef = useRef();
    const downloadPDF = () => {
      const input = pdfRef.current;
      html2canvas(input).then((canvas)=>{
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p','mm','a4', true);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
        const imgX = (pdfWidth - imgWidth * ratio)/2;
        const imgY = 30;
        pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
        pdf.save('paymentID.pdf')
    
      })
    }

  const invoiceData = {
    customerName: 'John Doe',
    contact: '0234567890',
    email: 'user@gmail.com',
    vehicleType:'Four Wheeler',
    orderId : "1234567",
    payId : "1234567",
    invoiceId : "1234567",
    bankId : "12345678",
    orderDate: '2024-07-15',
    invoiceDate: '2024-07-15',
    items: [
      { description: 'Four Wheeler Parking', quantity:2, price: 100 },
    ],
    price:'100.00'
  };
  const companyData = {
    customerName: 'PARKIT',
    contact: '1234567890',
    email: 'Parkit@gmail.com',
    status:'Success',
    address:'19th floor DLF Building phase cybercity Bangalore, 500001'
  };

  const calculateTotal = () => {
    return invoiceData.items.reduce((total, item) => total + item.quantity * item.price, 0);
  };

  return (

        <div className="invoice-page" >
    <div ref={pdfRef}>

      <div className="invoice-head">
        <div><h1>Invoice</h1></div>
        <div></div>
        <div><img src={ParkLogo} width="50vw" height="50vh"/></div>
        <div></div>
        <div style={{width:"10vw"}}><strong></strong> {companyData.address}</div>
       </div>
      <div className="invoice-header">
        <div style={{width:"12vw"}}><strong>Company Name:<br/></strong> {companyData.customerName}</div>
        <div><strong>Contact:</strong> {companyData.contact}</div>
        </div>
        <div className="invoice-header">
        <div><strong>Email:<br/></strong> {companyData.email}</div>
        <div><strong>Status:<br/></strong> {companyData.status}</div>
       </div>
      <div className="invoice-header">
        <div style={{width:"12vw"}}><strong>Customer Name:<br/></strong> {details.personalDetails.name}</div>
        <div><strong>Contact:<br/></strong> {details.personalDetails.phoneNo}</div>
        </div>
        <div className="invoice-header">
            
        <div><strong>Email:<br/></strong> {details.personalDetails.email}</div>
        <div><strong>Vehicle type:<br/></strong> {details.vehicle.vehicleType}</div>
      </div>
      <div className="invoice-header">
        <div><strong>Order Id:<br/></strong> {details.payment.paymentDetail.orderCreationId}</div>
        <div><strong>Invoice Id:<br/></strong> {details.payment.paymentDetail.razorpaySignature.slice(0,15)}</div>
        </div>
        <div className="invoice-header">
            
        <div><strong>Payment Id:<br/></strong> {details.payment.paymentDetail.razorpayPaymentId}</div>
        <div><strong><br/></strong></div> 
      </div>
      <div className="invoice-header">
        <div><strong>Order Date:<br/></strong> {dt}</div>
        <div><strong>Invoice Date:<br/></strong> {dt}</div>
      </div>
      <table className="invoice-table"> 
        <thead>
          <tr>
            <th>Description</th>
            {/* <th>Quantity</th> */}
            {/* <th>Price</th> */}
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {invoiceData.items.map((item, index) => (
            <tr key={index}>
              <td>{details.vehicle.vehicleType} wheeler parking</td>
              {/* <td>{item.quantity}</td> */}
              {/* <td>₹{item.price}</td> */}
              <td>₹{details.payment.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <h2 id="inv-h2">Total: ₹{details.payment.amount}</h2>
      <p id="inv-h2">All values are available in INR</p>
      </div>
      <Button variant='outlined' onClick={downloadPDF}><DownloadIcon sx={{padding:"2px", margin:'2px'}} /> Invoice</Button>
    </div>   
  );
};

export default InvoicePage;

