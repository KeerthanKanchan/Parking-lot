import * as React from 'react';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import '../../css/report.css';
import Header from "../../components/headerComponent";
import { Box, Button, ButtonGroup } from '@mui/material';
import axios from 'axios';
import { toast } from 'react-toastify';
import {vehicleExitReservation, reservationExitOrderGeneration, generateOrderAdmin, vehicleExitOffline} from '../../services/ApiService' 

function loadScript(src) {
    return new Promise((resolve) => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => {
            resolve(true);
        }
        script.onerror = () => {
            resolve(false)
        };
        document.body.appendChild(script);
    });
}




const transformData = (data) => {
  return data
    .filter((item) => item.exit_datetime === null) // Filter to include only entries where exit_datetime is null
    .map((item) => {
      const entryTime = new Date(item.entry_datetime);

      return {
        id: item.id,
        parkingDate: entryTime.toLocaleDateString(),
        entryTime: entryTime.toLocaleTimeString(),

        method: item.method,
        spa_no: item.space_id,
        vehicleType: item.vehicleType,
        vehicleNo: item.licence_no,
        subTableId:item.subTableId
      };
    });
};

export default function EntryExitV() {
  const [rows, setRows] = React.useState([]);
  const [data, setData] = React.useState([]);
  const [orderResponse, setOrderResponse] = React.useState();

  const handlePayment = async(parkingId,vehicleNo,vehicleType) => {

    const res = await loadScript(
        "https://checkout.razorpay.com/v1/checkout.js"
    );

    if(!res) {
        alert("RazorPay SDK failed to load, try again after some time");
        return;
    }

    // ---------------------
    const formdata = await {
        id: parkingId,
        license_no: vehicleNo,
        type: vehicleType

    }
    console.log(formdata)

    await generateOrderAdmin(formdata,
      async (response) => {
        console.log("re 123: ",response)
        console.log(response.order.amount)
        await setOrderResponse(response)
        console.log("test1 before option");
        const options = await {
            key: "rzp_test_QnZqng7pQVvf4L",
            amount: response.order.amount,
            currency: "INR",
            name: "PARKIT Corp.",
            description: "Test Trans",
            order_id: response.order.id,
            
            handler: async function (response) {
                console.log(typeof(orderResponse))
                const reserveData = {
                    order: orderResponse,
                    res: response,
                    data: data
                }
                console.log("reser: ", reserveData)
                await vehicleExitOffline(reserveData,
                    (response) => {
                        console.log(response)
                    },
                    (error) => {
                        console.log(error)
                    },
                )
            
            },
            notes: {
                address: "PARKIT Corporate Office",
            },
            theme: {
                color: "#61dafb",
            },
        };

        const paymentObject = new window.Razorpay(options);
        paymentObject.open();

    
      },
      (error) => {
        console.log(error)
      }
    )

}

  async function handleExit(method,vehicleType, parkingId,vehicleNo,reservationId){
    alert(method+""+vehicleType+""+ parkingId+""+reservationId)
    if(method=="reservation")
        {           
            const formdata = {
                reservationId: reservationId,
                vehicleType: vehicleType,
                parkingId: parkingId,
              }
              console.log(formdata)
              
              await reservationExitOrderGeneration(formdata,
                async (response)=>{
                  console.log(response);
                  setOrderResponse(response)
          
                  if(response.payment) {
                    const res = await loadScript(
                      "https://checkout.razorpay.com/v1/checkout.js"
                  );
              
                  if(!res) {
                      alert("RazorPay SDK failed to load, try again after some time");
                      return;
                  }
          
                  // ---------------------
                  const options = {
                    key: "rzp_test_QnZqng7pQVvf4L",
                    amount: response.order.amount,
                    currency: "INR",
                    name: "PARKIT Corp.",
                    description: "Test Trans",
                    order_id: response.order.id,
                    
                    handler: async function (response) {
                      console.log("payment resp: ", response)
                      vehicleExitReservation({data: orderResponse, payment: response},
                        (response)=>{
                          console.log(response)
                         
                        }, 
                        (error)=>{
                          console.log(error)
                        })
                    },
                    notes: {
                        address: "PARKIT Corporate Office",
                    },
                    theme: {
                        color: "#61dafb",
                    },
                };
          
                const paymentObject = new window.Razorpay(options);
                paymentObject.open();
                  // ---------------------
                  } else {
          
                  }
                },
                (error)=>{
                  console.log(error)
                }
              )
              
        }
        else{


            const formdata = {
                id: parkingId,
                license_no: vehicleNo,
                type: vehicleType
        
            }
            console.log(formdata)
        
            await generateOrderAdmin(formdata,
              (response) => {
                console.log(response)
                    handlePayment(parkingId,vehicleNo,vehicleType)
               
              },
              (error) => {
                console.log(error)
              }
            )
        

        }
    
    
}


const columns = [
    { field: 'id', headerName: 'ID', width: 90 },
    {
      field: 'parkingDate',
      headerName: 'Parking Date',
      width: 150,
      editable: true,
    },
    {
      field: 'entryTime',
      headerName: 'Entry Time',
      width: 140,
      editable: true,
    },
    {
        field: 'method',
        headerName: 'Method',
       
        
      },
    
    {
      field: 'spa_no',
      headerName: 'Space No',
      type: 'number',
      width: 150,
      editable: true,
    },
    {
      field: 'vehicleType',
      headerName: 'Vehicle Type',
      width: 150,
      editable: true,
    },
    {
      field: 'vehicleNo',
      headerName: 'Vehicle No',
      width: 140,
      editable: true,
    },
    {
      field: 'subTableId',
      headerName: 'subTabeleId',
      hide:true,
      visible:false
      
    },
    {
      field: 'action',
      headerName: 'Action',
      width: 150,
      renderCell: (params) => (
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleExit(params.row.method, params.row.vehicleType, params.row.id,params.row.vehicleNo,params.row.subTableId)}
        >
          Exit
        </Button>
      ),
    },
  ];
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(process.env.REACT_APP_ADMIN_BACKEND_URL + "/getParking");
        setData(response.data);
      } catch (error) {
        toast.error("Something went wrong");
      }
    };

    fetchData();
  }, []);

  React.useEffect(() => {
    setRows(transformData(data));
  }, [data]);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "0px", marginBottom: "60px" }}>
      <Box sx={{ height: 500, width: '70%', backgroundColor: '#c5c6c7' }}>
        <div style={{ width: "100%", textAlign: "right" }}>
        <Button>
       OFFLINE ENTRY
        </Button>
        <Button>
      RESERVATION
        </Button>
        </div>
        <DataGrid
          sx={{ border: "solid 3px white", backgroundColor: "#c5c6c7" }}
          slots={{ toolbar: GridToolbar }}
          rows={rows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 8,
              },
            },
          }}
          pageSizeOptions={[8]}
          disableRowSelectionOnClick
        />
      </Box>
    </Box>
  );
}
