import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Close';
import {
  GridRowModes,
  DataGrid,
  GridToolbarContainer,
  GridActionsCellItem,
  GridRowEditStopReasons,
  GridEditInputCellProps,
} from '@mui/x-data-grid';
import {
  randomCreatedDate,
  randomTraderName,
  randomId,
  randomArrayItem,
} from '@mui/x-data-grid-generator';
import { Toolbar } from '@mui/material';
import {addParkingSpot, editParkingSpot, getAllParkingSpace, toggleParkingSpot} from '../../services/ApiService';
import Switch from '@mui/material/Switch';
import { useEffect } from 'react';

const roles = [2, 4];


function EditToolbar(props) {
  const { rows, setRows, setRowModesModel, addButtonDisabled,setAddButtonDisabled } = props;

  const handleClick = () => {

    const id = rows.length + 1;
    setRows((oldRows) => [...oldRows, { id, isNew: true }]);
    setRowModesModel((oldModel) => ({
      ...oldModel,
      [id]: { mode: GridRowModes.Edit, fieldToFocus: 'space_no' },
    }));
    setAddButtonDisabled(true);
    setTimeout(
        console.log(rows), 6000
    )
  };

  return (
    <GridToolbarContainer>
      <Button color="primary" startIcon={<AddIcon />} onClick={handleClick} disabled={addButtonDisabled}>
        Add record
      </Button>
    </GridToolbarContainer>
  );
}

export default function FullFeaturedCrudGrid() {
  const [rows, setRows] = React.useState([]);
  const [rowModesModel, setRowModesModel] = React.useState({});
  const [addButtonDisabled, setAddButtonDisabled] = React.useState(false);


  useEffect(()=>{
    console.log("use effect start")
    getAllParkingSpace(
      (response)=>{
        console.log("PASS",response);
        setRows(response)
      },
      (error)=>{
        console.log("Error", error);
        // Show error notification
      }
    )
  }, [])

  const handleRowEditStop = (params, event) => {
    if (params.reason === GridRowEditStopReasons.rowFocusOut) {
      event.defaultMuiPrevented = true;
    }
  };

  const handleEditClick = (id) => () => {
    console.log(rows)
    setRowModesModel({ ...rowModesModel, [id]: { mode: GridRowModes.Edit } });
  };

  const handleSaveClick = (id) => () => {
    try {
      // Hit the api
      console.log("Handle Save",rows.find((row)=> row.id === id));
      setRowModesModel({ ...rowModesModel, [id]: { mode: GridRowModes.View } });
      setAddButtonDisabled(false);
    } catch (error) {
      console.log(error);
    }
  };


  const handleCancelClick = (id) => () => {
    setRowModesModel({
      ...rowModesModel,
      [id]: { mode: GridRowModes.View, ignoreModifications: true },
    }); 

    const editedRow = rows.find((row) => row.id === id);
    if (editedRow.isNew) {
      setRows(rows.filter((row) => row.id !== id));
    }
    setAddButtonDisabled(false);
  };

  const processRowUpdate = (newRow, oldRow) => {

    if(!newRow.space_no || !newRow.type) {
      console.log("isNew:"+newRow.isNew)
      alert(!newRow.space_no + " : " +!newRow.type)
      handleCancelClick(newRow.id)
      return newRow
  }

    console.log(newRow, oldRow)
    if (newRow.isNew) {
      const updatedRow = { ...newRow, isNew: false };
      setRows(rows.map((row) => (row.id === newRow.id ? updatedRow : row)));
      console.log("Update",updatedRow)
      console.log(newRow.space_no, newRow.type)
        addParkingSpot({space_no:newRow.space_no, type:newRow.type},
          (response) => {
            console.log("Add PASS",response)
          }, 
          (error) => {
            console.log("Add errror", error)
          }
        )
      return updatedRow;
    } else {
      if (newRow.type !== oldRow.type) {
        console.log("parking type diff");
        editParkingSpot({id: newRow.id, space_no: newRow.space_no, type: newRow.type},
          (response) => {
            console.log("edit",response);
          },
          (error) => {
            console.log("edit",error)
          }
        )
        return newRow
      } else {
        return newRow
      }
    }
  };

  const handleRowModesModelChange = (newRowModesModel) => {
    setRowModesModel(newRowModesModel);
  };

  const handleStatusToggle = (id, event) => {
    //TODO API and UseEffect
    console.log("newValue",event.target.checked)
    toggleParkingSpot({id: id, status: event.target.checked},
      (response) => {
        console.log("pass1",response);
      },
      (error) => {
        console.log("error",error)
      }
    )
    setRows(prevRows => 
      prevRows.map((row)=> 
        {console.log("set state",{...row}, id);
        return row.id === id ? {...row, enabled: event.target.checked} : row}));
    console.log(id, event.target.checked);
    
  }

  const columns = [
    {
      field: 'id', headerName: "ID", width: 110
    },
    { field: 'space_no', headerName: 'Parking Space Number', width: 200, 
      editable: true,

      // renderEditCell: (params) => {<GridEditInputCellProps {...params} disabled={params.row.isNew} />
    // }
    },
    {
      field: 'type',
      headerName: 'Parking Type',
      width: 150,
      editable: true,
      type: 'singleSelect',
      valueOptions: roles,
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      width: 150,
      cellClassName: 'actions',
      getActions: ({ id }) => {
        const isInEditMode = rowModesModel[id]?.mode === GridRowModes.Edit;

        if (isInEditMode) {
          return [
            <GridActionsCellItem
              icon={<SaveIcon />}
              label="Save"
              sx={{
                color: 'primary.main',
              }}
              onClick={handleSaveClick(id)}
            />,
            <GridActionsCellItem
              icon={<CancelIcon />}
              label="Cancel"
              className="textPrimary"
              onClick={handleCancelClick(id)}
              color="inherit"
            />,
          ];
        }

        return [
          <GridActionsCellItem
            icon={<EditIcon />}
            label="Edit"
            className="textPrimary"
            onClick={handleEditClick(id)}
            color="inherit"
          />,
          // <GridActionsCellItem
          //   icon={<DeleteIcon />}
          //   label="Delete"
          //   onClick={handleDeleteClick(id)}
          //   color="inherit"
          // />,
        ];
      },
    },
    {
      field: 'slotStatus',
      type: 'actions',
      headerName: 'Status',
      width: 170,
      cellClassName: 'actions',
      getActions: ({id, row}) => {
        // console.log("check: ",row)
        return [
                <Switch
                    checked={row.enabled}
                    onChange={(newValue) => { console.log(id,newValue);handleStatusToggle(id, newValue)}}
                    inputProps={{ 'aria-label': 'controlled' }}
                />
        ];
      },
    },
  ];

  return (
    <Box
      sx={{
        height: 500,
        width: '60%',
        m: 'auto',
        mb: '60px',
        '& .actions': {
          color: 'text.secondary',
        },
        '& .textPrimary': {
          color: 'text.primary',
        },
        backgroundColor:'#c5c6c7'
      }}
    >
      <DataGrid
        rows={rows}
        columns={columns}
        isCellEditable={(props) => {if (props.row.isNew) {
          return true;
        } else {
           return props.field === 'type'
        }
      }}
        editMode="row"
        rowModesModel={rowModesModel}
        onRowModesModelChange={handleRowModesModelChange}
        onRowEditStop={handleRowEditStop}
        processRowUpdate={processRowUpdate}
        slots={{
          toolbar: EditToolbar,
        }}
        slotProps={{
          toolbar: { rows, setRows, setRowModesModel, addButtonDisabled, setAddButtonDisabled },
        }}
      />
    </Box>
  );
}