import * as React from 'react';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'id', headerName: 'ID', width: 90 },
  { field: 'res_id', headerName: 'Res_ID', width: 100 },
  {
    field: 'entryDate',
    headerName: 'Entry Date',
    width: 180,
    editable: true,
  },
  {
    field: 'entryTime',
    headerName: 'Entry Time',
    width: 180,
    editable: true,
  },
  {
    field: 'exitDate',
    headerName: 'Exit Date',
    width: 180,
    editable: true,
  },
  {
    field: 'exitTime',
    headerName: 'Exit Time',
    width: 140,
    editable: true,
  },
  {
    field: 'spa_no',
    headerName: 'Space No',
    type: 'number',
    width: 150,
    editable: true,
  },
  // {
  //   field: 'fullName',
  //   headerName: 'Full name',
  //   description: 'This column has a value getter and is not sortable.',
  //   sortable: false,
  //   width: 160,
  //   valueGetter: (value, row) => `${row.firstName || ''} ${row.lastName || ''}`,
  // },
];

const rows = [
  { id: 1,res_id:111, entryTime: '12:50',entryDate:'12/11/2023',  exitTime: '15:00', exitDate:'12/11/2023', spa_no: 14 },
  { id: 2,res_id:112, entryTime: '15:00',entryDate:'13/11/2023',  exitTime: '17:00', exitDate:'14/11/2023', spa_no: 31 },
  { id: 3,res_id:113, entryTime: '17:00',entryDate:'11/11/2023',  exitTime: '19:00', exitDate:'12/11/2023', spa_no: 31 },
  { id: 4,res_id:114, entryTime: '19:00',entryDate:'10/11/2023',  exitTime: '21:00', exitDate:'11/11/2023', spa_no: 11 },
  { id: 5,res_id:115, entryTime: '18:00',entryDate:'12/11/2023',  exitTime: '21:00', exitDate:'12/11/2023', spa_no: 12 },
  { id: 6,res_id:116, entryTime: '18:00',entryDate:'13/11/2023',  exitTime: '20:00', exitDate:'14/11/2023', spa_no: 150 },
  { id: 7,res_id:117, entryTime: '19:00',entryDate:'12/11/2023',  exitTime: '21:00', exitDate:'12/11/2023', spa_no: 44 },
  { id: 8,res_id:118, entryTime: '11:00',entryDate:'14/11/2023',  exitTime: '14:00', exitDate:'18/11/2023', spa_no: 36 },
  { id: 9,res_id:119, entryTime: '14:00',entryDate:'17/11/2023',  exitTime: '17:00', exitDate:'16/11/2023', spa_no: 65 },
];

export default function DataGridDemo() {
  return (
    <Box sx={{ display:"flex",height: 350, width: '100%', marginTop:"100px", marginBottom:"30px",marginLeft:"auto", marginRight:'auto', backgroundColor:'#c5c6c7',borderRadius:"10px",border:"solid 3px white"  }}>
      <DataGrid sx={{borderRadius:"10px",border:"solid 3px white", backgroundColor:"#c5c6c7"}}
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5]}
        // checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}
