import React from 'react'
import "../css/MainDash.css";
import Cards from "./Cards";
import Table from "./Table";
import io from 'socket.io-client';

const socket = io('http://localhost:8080')

function MainDash() {

  const [data,setData]=React.useState({parking: [], payment: [], reservation: [], slot:{2:{lockedSlot: 0, availableSlot: 0}, 4:{lockedSlot: 0, availableSlot: 0}, date: '2024-07-17', time: '10PM'}});
  React.useEffect(()=>{

    socket.emit('subscribe_to_dashboard_updates');

    // Handle initial data when client first connects
    socket.on('dashboard_initial_data', (data) => {
      
      // alert(JSON.stringify(data.data))
        console.log(data.data)
      
        setData(data.data)
      
    });

    // Handle updates when helpline data changes
    socket.on('dashboard_update', (update) => {
       
        console.log('dashboard_update:', update);
    
        // alert(JSON.stringify(update.data))
        setData(update.data)
        
    });

    // // Clean up socket on component unmount
    // return () => {
    //     socket.disconnect();
    // };

},[])

  return (
    <div className="MainDash">
      {}
      
      <Cards cardsData={data.slot}/>
      <Table tableData={data.parking}/>
    </div>
  )
}

export default MainDash
