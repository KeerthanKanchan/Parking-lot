import * as React from 'react';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import '../css/report.css';
import Header from "../components/headerComponent";
import { Box, Button, ButtonGroup } from '@mui/material';
import axios from 'axios';
import { toast } from 'react-toastify';

const columns = [
  { field: 'id', headerName: 'ID', width: 90 },
  { field: 'res_id', headerName: 'Res_ID', width: 100 },
  {
    field: 'ReservationDate',
    headerName: 'Reservation Date',
    width: 150,
    editable: true,
  },
  {
    field: 'entryTime',
    headerName: 'Entry Time',
    width: 150,
    editable: true,
  },
  {
    field: 'exitDate',
    headerName: 'Exit Date',
    width: 150,
    editable: true,
  },
  {
    field: 'exitTime',
    headerName: 'Exit Time',
    width: 100,
    editable: true,
  },
  {
    field: 'spa_no',
    headerName: 'Space No',
   
    width: 100,
    editable: true,
  },
  {
    field: 'licence',
    headerName: 'Licence',
    type: 'number',
    width: 140,
    editable: true,
  },
];

const transformData = (data) => {

  return data.map((item, index) => {
    const reservationEntryTime = new Date(item.reservation_entry_time);
    const reservationExitTime = new Date(item.reservation_exit_time);

    return {
      id: index + 1,
      res_id: "RESRV-" + item.id,
      ReservationDate: reservationEntryTime.toLocaleDateString(),
      entryTime: reservationEntryTime.toLocaleTimeString(),
      exitDate: reservationExitTime.toLocaleDateString(),
      exitTime: reservationExitTime.toLocaleTimeString(),
      spa_no: item.space_id,
      licence: item.vehicle_id
    };
  });
};

export default function DataGridDemo() {
  const [rows, setRows] = React.useState([]);
  const [data, setData] = React.useState([]);
  const [filter, setFilter] = React.useState('all');
  var [allColor,setAllColor]=React.useState("#000000")
  var [upcomingColor,setupcomingColor]=React.useState("")
  var [pastColor,setpastColor]=React.useState("")

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(process.env.REACT_APP_ADMIN_BACKEND_URL + "/getReservation");
        setData(response.data);
      } catch (error) {
        toast.error("Something went wrong");
      }
    };

    fetchData();
  }, []);

  React.useEffect(() => {
    const now = new Date();
    const filteredData = data.filter(item => {
      const exitDateTime = new Date(item.reservation_exit_time);
      if (filter === 'upcoming') {
      setupcomingColor("#000000")
      setpastColor("")
      setAllColor("")
        return exitDateTime > now;
      } else if (filter === 'past') {
        setupcomingColor("")
        setpastColor("#000000")
        setAllColor("")
        return exitDateTime <= now;
      }
      setupcomingColor("")
      setpastColor("")
      setAllColor("#000000")
      return true; 
    });
    setRows(transformData(filteredData));
  }, [data, filter]);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "0px" ,marginBottom: "60px"}}>
      <ButtonGroup sx={{ mb: 2 }}>
        <Button sx={{backgroundColor:allColor}} onClick={() => setFilter('all')}>All</Button>
        <Button sx={{backgroundColor:upcomingColor}} onClick={() => setFilter('upcoming')}>Upcoming</Button>
        <Button sx={{backgroundColor:pastColor}} onClick={() => setFilter('past')}>Past</Button>
      </ButtonGroup>
      <Box sx={{ height: 500, width: '70%', backgroundColor: '#c5c6c7' }}>
      <div style={{width:"100%",textAlign:"center"}}>{filter.toUpperCase()} RESERVATIONS</div>
        <DataGrid
       
          sx={{ border: "solid 3px white", backgroundColor: "#c5c6c7" }}
          slots={{ toolbar: GridToolbar }}
          rows={rows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 8,
              },
            },
          }}
          pageSizeOptions={[8]}
          disableRowSelectionOnClick
        />
      </Box>
    </Box>
  );
}
