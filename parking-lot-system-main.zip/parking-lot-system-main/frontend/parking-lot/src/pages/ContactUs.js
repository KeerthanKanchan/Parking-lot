import { Button,  Grid, Input } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';
import "../css/ContactUs.css";
import ContactPop from "./ContactPopup";
import pic1 from "../assets/images/Parking-Sign.png";
import pic2 from "../assets/images/realtime-parking.jpg";

function ContactUs() {
  return (
    <div className='Contacts'>
      <>
      <h1>Want to know more?</h1>
      <h1>Reach out to us!</h1>
      <ContactPop />
   </>
      <img src={pic1} id="pic1" />
      <img src={pic2} id="pic2" />
    </div>
  )
}

export default ContactUs;   