import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import "../css/Table.css";

function createData(index, vehicleType, vehicleNo, parkingNo, spaceNo, entry, exit, status) {
  return { index, vehicleType, vehicleNo, parkingNo, spaceNo, entry, exit, status };
}

// const rows1 = [
//   createData(1, 18908424, "12:00", "Parked"),
//   createData(2, 18908424, "13:00", "Left"),
//   createData(3, 18908424, "16:00", "Parked"),
//   createData(4, 18908421, "20:00", "Reserved"),
//   createData(1, 18908424, "12:00", "Parked"),
//   createData(2, 18908424, "13:00", "Left"),
//   createData(3, 18908424, "16:00", "Parked"),
//   createData(4, 18908421, "20:00", "Reserved"),
//   createData(1, 18908424, "12:00", "Parked"),
//   createData(2, 18908424, "13:00", "Left"),
//   createData(3, 18908424, "16:00", "Parked"),
//   createData(4, 18908421, "20:00", "Reserved"),
// ];


const makeStyle=(status)=>{
  if(status === 'Parked')
  {
    return {
      background: 'rgb(145 254 159 / 47%)',
      color: 'green',
    }
  }
  else if(status === 'Left')
  {
    return{
      background: '#ffadad8f',
      color: 'red',
    }
  }
  else{
    return{
      background: '#ffa500',
      color: '#e04c16',
    }
  }
}

export default function BasicTable(props) {
  const [rows, setRows] = React.useState([]);
  console.log("Table out",props.tableData)
  React.useEffect(()=>{
    // createData(props.);
    const tableData = props.tableData;
    
    console.log("Table: ", tableData);
    setRows(tableData.map((data, i)=>createData(i+1, data.vehicleType, data.licence_no, data.id, data.space_no,new Date(data.entry_datetime).toLocaleString(), (data.exit_datetime != null ?new Date(data.exit_datetime).toLocaleString():""), (data.exit_datetime === null ? "Parked" : "Left"))));
    
  },[props.tableData]);
  console.log("after: ",rows)
  return (
      <div className="Table">
      <h3 style={{textAlign:'start'}}>Parked Vehicles Details</h3>
        <TableContainer
          component={Paper}
          style={{ boxShadow: "0px 13px 20px 0px #80808029", height:"300px" }}

        >
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead sx={{backgroundColor:'#7d7d7d'}}>
              <TableRow>
                <TableCell>S.No</TableCell>
                <TableCell align="left">Vehicle Type</TableCell>
                <TableCell align="left">Vehicle No</TableCell>
                <TableCell align="left">Parking No</TableCell>
                <TableCell align="left">Space No</TableCell>
                <TableCell align="left">Entry</TableCell>
                <TableCell align="left">Exit</TableCell>
                <TableCell align="left">Status</TableCell>
                
              </TableRow>
            </TableHead>
            <TableBody style={{ color: "white",}}>
              {rows.map((row) => (
                // index, vehicleType, vehicleNo, parkingNo, spaceNo, entry, exit, status
                <TableRow
                  key={row.index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                   <TableCell align="left">{row.index}</TableCell>
                   <TableCell align="left">{row.vehicleType}</TableCell>
                   <TableCell align="left">{row.vehicleNo}</TableCell>
                  <TableCell align="left">{row.parkingNo}</TableCell>
                  <TableCell align="left">{row.spaceNo}</TableCell>
                  <TableCell align="left">{row.entry}</TableCell>
                  <TableCell align="left">{row.exit}</TableCell>
                  <TableCell align="left">
                    <span className="status" style={makeStyle(row.status)}>{row.status}</span>
                  </TableCell>
                  {/* <TableCell align="left" className="Details">Details</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
  );
}