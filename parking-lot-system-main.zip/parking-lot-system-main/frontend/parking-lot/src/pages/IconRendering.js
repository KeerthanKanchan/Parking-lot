import React from 'react';
import LocalParkingIcon from '@mui/icons-material/LocalParking';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';

const parked = false; 
const reserve = false; 
const complete = true; 

const getText = () => {
  if (parked) return "Your vehicle is safe with us.";
  if (reserve) return "Your upcoming reservations.";
  if (complete) return "Hope you had a good time.";
  return "No condition is true.";
};

const getColor = () => {
  if (parked) return "white";
  if (reserve) return "yellow";
  if (complete) return "green";
  return "black";
};

const getIcon = () => {
  if (parked) return <LocalParkingIcon sx={{ display: "flex", marginLeft: 'auto', marginRight: "auto", color:getColor() }} />;
  if (reserve) return <AccessTimeIcon sx={{ display: "flex", marginLeft: 'auto', marginRight: "auto", color:getColor() }} />;
  if (complete) return <ThumbUpIcon sx={{ display: "flex", marginLeft: 'auto', marginRight: "auto", color:getColor() }} />;
  return null;
};

const ConditionalRenderingComponent = () => (
  <div>
    {getIcon()}
    <span style={{ display: 'block', color: getColor(), fontSize:"20px" }}>{getText()}</span>
    {/* <span style={{ display: 'block', color: getColor(),fontSize:"20px" }}>{getText()}</span> */}
  </div>
);

export default ConditionalRenderingComponent;