import * as React from 'react';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import '../css/report.css';
import Header from "../components/headerComponent";
import { Box, Button, ButtonGroup } from '@mui/material';
import axios from 'axios';
import { toast } from 'react-toastify';

const columns = [
  { field: 'id', headerName: 'ID', width: 90 },

  {
    field: 'parkingDate',
    headerName: 'Parking Date',
    width: 150,
    editable: true,
  },
  {
    field: 'entryTime',
    headerName: 'Entry Time',
    width: 150,
    editable: true,
  },
  {
    field: 'exitDate',
    headerName: 'Exit Date',
    width: 150,
    editable: true,
  },
  {
    field: 'exitTime',
    headerName: 'Exit Time',
    width: 140,
    editable: true,
  },
  {
    field: 'method',
    headerName: 'Method',
    width: 100,
    editable: true,
  },
  {
    field: 'spa_no',
    headerName: 'Space No',
    type: 'number',
    width: 150,
    editable: true,
  },
  {
    field: 'licence',
    headerName: 'Licence',
    type: 'number',
    width: 140,
    editable: true,
  },
];

const transformData = (data) => {

  return data.map((item, index) => {
    const EntryTime = new Date(item.entry_datetime);
    const ExitTime = new Date(item.exit_datetime);

    return {
      id: index + 1,
      parkingDate: EntryTime.toLocaleDateString(),
      entryTime: EntryTime.toLocaleTimeString(),
      exitDate:item.exit_datetime==null?"still parked":ExitTime.toLocaleDateString(),
      exitTime: item.exit_datetime==null?"still parked":ExitTime.toLocaleTimeString(),
      spa_no: item.space_id,
      licence: item.licence_no,
      method:item.method
    };
  });
};

export default function DataGridDemo() {
  const [rows, setRows] = React.useState([]);
  const [data, setData] = React.useState([]);
  const [filter, setFilter] = React.useState('all');
  var [allColor,setAllColor]=React.useState("#000000")
  var [currentColor,setcurrentlyColor]=React.useState("")
  var [pastColor,setpastColor]=React.useState("")

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(process.env.REACT_APP_ADMIN_BACKEND_URL + "/getParking");
        setData(response.data);
      } catch (error) {
        toast.error("Something went wrong");
      }
    };

    fetchData();
  }, []);

  React.useEffect(() => {
    const now = new Date();
    const filteredData = data.filter(item => {
      const exitDateTime = item.exit_datetime;
     
      if (filter === 'current') {
      setcurrentlyColor("#000000")
      setpastColor("")
      setAllColor("")
        return exitDateTime==null
      } else if (filter === 'past') {
        setcurrentlyColor("")
        setpastColor("#000000")
        setAllColor("")
        return exitDateTime!=null;
      }
      setcurrentlyColor("")
      setpastColor("")
      setAllColor("#000000")
      return true; 
    });
    setRows(transformData(filteredData));
  }, [data, filter]);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "0px" ,marginBottom: "60px"}}>
      <ButtonGroup sx={{ mb: 2 }}>
        <Button sx={{backgroundColor:allColor}} onClick={() => setFilter('all')}>All</Button>
        <Button sx={{backgroundColor:currentColor}} onClick={() => setFilter('current')}>Current</Button>
        <Button sx={{backgroundColor:pastColor}} onClick={() => setFilter('past')}>Past</Button>
      </ButtonGroup>
      <Box sx={{ height: 500, width: '70%', backgroundColor: '#c5c6c7' }}>
      <div style={{width:"100%",textAlign:"center"}}>{filter.toUpperCase()} PARKINGS</div>
        <DataGrid
       
          sx={{ border: "solid 3px white", backgroundColor: "#c5c6c7" }}
          slots={{ toolbar: GridToolbar }}
          rows={rows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 8,
              },
            },
          }}
          pageSizeOptions={[8]}
          disableRowSelectionOnClick
        />
      </Box>

    </Box>
  );
}