import * as React from 'react';
import Cards from "./DashCards";
import Barchart from "./DashBarChart";
import Piechart from "./DashPieChart";
import Header from "../components/headerComponent";
import DataGrid from "./DashboardGrid";
// import "../css/Dashboard.css";
// import Dashboard from './Dashboard/Dashbord2';

import io from 'socket.io-client';


const socket = io('http://localhost:8080')


function Dashborad() {
  var [data,setData]=React.useState({})
  React.useEffect(()=>{
      
    
    socket.emit('subscribe_to_dashboard_updates');
   
    // Handle initial data when client first connects
    socket.on('dashboard_initial_data', (data) => {
      
      alert(JSON.stringify(data.data))
         setData(data.data)
      
    });

    // Handle updates when helpline data changes
    socket.on('dashboard_update', (update) => {
       
        console.log('dashboard_update:', update);
    
        alert(JSON.stringify(update.data))
        setData(update.data)
        
    });

    // // Clean up socket on component unmount
    // return () => {
    //     socket.disconnect();
    // };

},[])
  return (
    // <div id="cards">
    //   <Cards name="Total Available Parking Space" number1='49' number2='56'/>
    //   <Cards name="Filled Parking Space" number1='51' number2='44'/>
    //   <Cards name="Total Parking Space" number1='100' number2='100'/> 
    //   <DataGrid />    
    // </div>
    // <Dashboard />
    <p>dashboard</p>
  )
}
export default Dashborad;


