import * as React from 'react';
import { BarChart } from '@mui/x-charts/BarChart';
import { red } from '@mui/material/colors';

export default function BasicBars() {
  return (
    <div style={{display:"inline-flex", marginTop:4, marginLeft:70}}>
    <BarChart
      xAxis={[{ scaleType: 'band', data: ['Two Wheeler', 'Four Wheeler']  }]}
      series={[{ data: [4, 3] }, { data: [1,3] }]}
      width={500}
      height={300}
      />
      </div>
  );
}