import React, { useState } from 'react'
import "./Dashboard2.css";
import ManagePriceModal from '../../components/managePriceModal';

function Dashbord2() {
  
  return (
    <div className='App'>
        <div className='AppGlass'>
       
        </div>
    </div>
  )
}

export default Dashbord2
