import React from 'react';
import "../css/About.css";
import image from "../assets/images/homeImg.png"
import { getFormControlUtilityClasses } from '@mui/material';
import { color, width } from '@mui/system';

// function About() {
//   return (
//     <div>
//       <div id="main-div">
//         <img 
//           src="https://img.freepik.com/free-vector/gradient-cyber-futuristic-background_23-2149117429.jpg" 
//           alt="background" 
//           width="100%" 
//           height="600px"
//         />
//         <div className="text-on-image">
//           <p>ParkiTeam</p>
//           <p id="para">
//             There are many variations of passages of Lorem Ipsum available, but the majority 
//             have suffered alteration in some form, by injected humour, or randomised words 
//             which don't look even slightly believable. If you are going to use a passage of 
//             Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the 
//             middle of text. All the Lorem Ipsum generators on the Internet tend to repeat 
//             predefined chunks as necessary, making this the first true generator on the 
//             Internet. It uses a dictionary of over 200 Latin words, combined with a handful 
//             of model sentence structures, to generate Lorem Ipsum which looks reasonable. 
//             The generated Lorem Ipsum is therefore always free from repetition, injected 
//             humour, or non-characteristic words etc.
//           </p>
//         </div>
//         <div className="layer-image">
//           <img 
//             src="https://lh7-us.googleusercontent.com/Ck2hbbDOUn3GL5ccBi24qeXg6hJk8C7hRAJBBM1Pm-zVmLMoUIydH-2I5pLUhCOSAgYDEeC801s9cTlEGfdfiQgEolBvIahfJMUwnQjg2BRXfkaVQ5_nU7eLzVtQhzMmZAS7qXW_oBVf" 
//             alt="car" 
//             width="600px"
//           />
//         </div>
//       </div>
//     </div>
//   );
// }

// export default About;

function About() {
    return (
      <div className='About'>
        <div className='Second-div'>
          <img className='picture' src={image} />
        </div>
        <div className='containers'>
        <p className='paragraphs'><h2 id="heading-h2">About PARKIT</h2><br />
        A parking management system automates a car parking system. 
        It optimizes parking space and make processes efficient. 
        It gives real-time car parking information such as vehicle & slot counts, 
        available slots display, reserved parking, pay-and-park options, 
        easy payments, reports, and a host of other features.A car parking management system can help to improve the efficiency of parking operations, reduce congestion in the parking lot, and increase revenue for parking lot owners. It can also provide a better customer experience by reducing the time it takes to find a parking space and by simplifying the payment process.
        </p>
        </div>
        </div>
        
    );
  }
  
  export default About;
