import React from "react";
import "../css/Cards.css";
import { cardsData } from "../Data/Data";

import Card from "./Card";


const Cards = (props) => {
  // console.log("card props: ", typeof(props))
  const contents = props.cardsData;
  console.log(contents);
  console.log(((contents["2"].lockedSlot + contents["4"].lockedSlot) / (contents["2"].availableSlot + contents["4"].availableSlot)) * 100)
  console.log(( (contents["2"].availableSlot + contents["4"].availableSlot)) )
  console.log((contents["2"].lockedSlot + contents["4"].lockedSlot))
  cardsData[0].barValue = Math.floor(((contents["2"].lockedSlot + contents["4"].lockedSlot) / (contents["2"].availableSlot + contents["4"].availableSlot + contents["2"].lockedSlot + contents["4"].lockedSlot)) * 100);
  cardsData[0].filled = (contents["2"].lockedSlot + contents["4"].lockedSlot);
  cardsData[0].value = (contents["2"].availableSlot + contents["4"].availableSlot + contents["2"].lockedSlot + contents["4"].lockedSlot)


  cardsData[1].barValue = Math.floor((contents["2"].lockedSlot / (contents["2"].availableSlot + contents["2"].lockedSlot)) * 100);
  cardsData[1].filled = (contents["2"].lockedSlot);
  cardsData[1].value = (contents["2"].availableSlot + contents["2"].lockedSlot);

  cardsData[2].barValue = Math.floor((contents["4"].lockedSlot / (contents["4"].availableSlot + contents["4"].lockedSlot)) * 100);
  cardsData[2].filled = (contents["4"].lockedSlot);
  cardsData[2].value = (contents["4"].availableSlot + contents["4"].lockedSlot)


  console.log(cardsData)

  // console.log(contents["2"]);


  return (
    <div className="Cards">

      {cardsData.map((card, id) => {
        return (
          <div className="parentContainer" key={id}>
            <Card
              title={card.title}
              color={card.color}
              barValue={card.barValue}
              value={card.value}
              filled = {card.filled}
              png={card.png}
              series={card.series}
            />
          </div>
        );
      })}
    </div>
  );
};

export default Cards;