import * as React from 'react';
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import PersonIcon from '@mui/icons-material/Person';
import AddIcon from '@mui/icons-material/Add';
import Typography from '@mui/material/Typography';
import { blue } from '@mui/material/colors';
import { Grid } from '@mui/material';
import {TextField} from '@mui/material';
import {Box} from '@mui/material';
import Switch from '@mui/material/Switch';
import { toast } from 'react-toastify';
import {vehicleEntryOffline, vechicleEntryOnline} from '../services/ApiService' 


const emails = ['username@gmail.com', 'user02@gmail.com'];

function SimpleDialog(props) {
  const { onClose, selectedValue, open } = props;
  const [checked, setChecked] = React.useState(false);
  const [vehicleNo, setVehicleNo] = React.useState();
  const [vehicleType, setVehicleType] = React.useState();
  const [contactNo, setContactNo] = React.useState();
  const [reservationId, setReservationId] = React.useState();
  

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const handleClose = () => {
    setContactNo('');
    setVehicleNo('');
    setVehicleType('');
    setReservationId('');
    onClose(selectedValue);
  };

  const handleOffliceEntry = () => {
    const data = {
      license_no: vehicleNo,
      type: vehicleType,
      contact_no: contactNo
    }
    console.log(data)

    vehicleEntryOffline(data,
      (response) => {
        console.log(response)
        toast.success(`Vehicle entry recorded. Parking Id: ${response.id}, Space id: ${response.space_id}`)
        //show messafe and close the model
        handleClose();
      },
      (error,message) => {
        console.log(error)
        toast.error(message)
      }
    )


  }

  const handleReservationEntry = () => {
    const data = {
      reservationId: reservationId
    }

    console.log(data)

    vechicleEntryOnline(data,
      (response) => {
        console.log(response)
        toast.success(`Vehicle entry recorded. Parking Id: ${response.response.id}, Space id: ${response.reservationDetails.space_id}`)
        //Notify user
        handleClose()
      },
      (error, message) => {
        console.log(error, message)
        toast.error(message)
        //Notify user
      }
    )
  }


  return (
    <Dialog onClose={handleClose} open={open}>
      <DialogTitle sx={{border:"3px solid white",backgroundColor:"black", color:'#66fcf1'}}>{!checked ? 'Vehicle Info' : 'Reservation Info'}</DialogTitle>
      <List sx={{ p: 2, backgroundColor:'#c5c6c7' }}>
      <Box >  
                <label>Reserved: </label>
                <Switch checked={checked} onChange={handleChange} inputProps={{ 'aria-label': 'controlled' }} />
                { !checked ?
                  <>
                    <TextField id="outlined-basic" label="Vehicle No" variant="outlined" fullWidth sx={{mb:2}} value={vehicleNo} onChange={(event)=>{setVehicleNo(event.target.value)}}/>
                    <TextField id="outlined-basic" label="Vehicle Type" variant="outlined" fullWidth sx={{mb:2}} value={vehicleType} onChange={(event)=>{setVehicleType(event.target.value)}}/>
                    <TextField id="outlined-basic" label="Contact No" variant="outlined" fullWidth sx={{mb:2}} value={contactNo} onChange={(event)=>{setContactNo(event.target.value)}}/>
                    <Box sx={{display:'flex', justifyContent: 'center'}}>
                      <Button variant='outlined' onClick={handleOffliceEntry}>Submit</Button>
                    </Box>
                  </>
                  :
                  <>
                    <TextField id="outlined-basic" label="Reservation No" variant="outlined" fullWidth sx={{mb:2}} value={reservationId} onChange={(event)=>{setReservationId(event.target.value)}} />
                    <Box sx={{display:'flex', justifyContent: 'center'}}>
                      <Button variant='outlined' onClick={handleReservationEntry}>Submit</Button>
                    </Box>
                  </>
                }
                

      </Box>
      </List>
    </Dialog>
  );
}

SimpleDialog.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.string.isRequired,
};

export default function SimpleDialogDemo(props) {
  const [open, setOpen] = React.useState(false);
  const [selectedValue, setSelectedValue] = React.useState(emails[1]);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = (value) => {
    setOpen(false);
    setSelectedValue(value);
  };

  return (
    <div style={{display:'inline-flex', marginLeft:"360px"}}>
      <Typography variant="subtitle1" component="div">
        {/* Selected: {selectedValue} */}
      </Typography>
      <br />
      <Button variant="outlined" onClick={handleClickOpen}>
        {props.name}
      </Button>
      <SimpleDialog
        selectedValue={selectedValue}
        open={open}
        onClose={handleClose}
      />
    </div>
  );
}