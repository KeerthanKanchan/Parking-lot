import * as React from 'react';
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import PersonIcon from '@mui/icons-material/Person';
import AddIcon from '@mui/icons-material/Add';
import Typography from '@mui/material/Typography';
import { blue } from '@mui/material/colors';
import { Grid } from '@mui/material';
import {TextField} from '@mui/material';
import {Box} from '@mui/material';
import Switch from '@mui/material/Switch';
import axios from 'axios';
import { toast } from "react-toastify"
import {vehicleExitReservation, reservationExitOrderGeneration, generateOrderAdmin, vehicleExitOffline} from '../services/ApiService' 


const emails = ['username@gmail.com', 'user02@gmail.com'];

function SimpleDialog(props) {
  const { onClose, selectedValue, open } = props;
  const [checked, setChecked] = React.useState(false);
  const [vehicleNo, setVehicleNo] = React.useState();
  const [vehicleType, setVehicleType] = React.useState();
  const [parkingId, setParkingId] = React.useState();
  const [reservationId, setReservationId] = React.useState();
  const [orderResponse, setOrderResponse] = React.useState();
  
  // toast.error("Something went wrong. please try again!");
  // toast.success("Success");;

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const handleClose = () => {
    setParkingId('');
    setOrderResponse('');
    setVehicleNo('');
    setVehicleType('');
    setReservationId('');
    onClose(selectedValue);
  };


  function loadScript(src) {
    return new Promise((resolve) => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => {
            resolve(true);
        }
        script.onerror = () => {
            resolve(false)
        };
        document.body.appendChild(script);
    });
}

  const handlePayment = async() => {

    const res = await loadScript(
        "https://checkout.razorpay.com/v1/checkout.js"
    );

    if(!res) {
        alert("RazorPay SDK failed to load, try again after some time");
        return;
    }

    // ---------------------
    const data = {
        id: parkingId,
        license_no: vehicleNo,
        type: vehicleType

    }
    console.log(data)

    generateOrderAdmin(data,
      async (response) => {
        setOrderResponse(response);
        console.log("re 123: ",response)
        console.log(response.order.amount)
        console.log("test1 before option");
        console.log(response.order.amount * 100);
        
        const options = {
            key: "rzp_test_QnZqng7pQVvf4L",
            amount: response.order.amount * 100,
            currency: "INR",
            name: "PARKIT Corp.",
            description: "Test Trans",
            order_id: response.order.id,
            
            handler: async function (paymentresponse) {
                console.log(typeof(orderResponse))
                const reserveData = {
                    order: response,
                    res: paymentresponse,
                    data: data
                }
                console.log("reser: ", reserveData)
                vehicleExitOffline(reserveData,
                    (response) => {
                        console.log(response)
                        toast.success("Vehicle Exit Recorded.")
                    },
                    (error) => {
                        console.log(error)
                        console.log(error.message)
                        toast.error(error.message)
                    },
                )
            
            },
            notes: {
                address: "PARKIT Corporate Office",
            },
            theme: {
                color: "#61dafb",
            },
        };

        const paymentObject = new window.Razorpay(options);
        paymentObject.open();

        //show messafe and close the model
        handleClose()
      },
      (error, message) => {
        console.log(error)
        toast.error(message);
      }
    )

    // ---------------------


    // api to create new orde"r
//     const result = await axios.post(
//         "http://localhost:8080/customer/generateOrder",
//         {
//             amount: 100,
//             bookingSlotFile:availableSpace.bookingSlotFile,
//         }
//     );
//    var bookingSlotFile=await result.bookingSlotFile;
//     if (!result) {
//         alert("Server error");
//         return
//     }
    // const {amount, id: order_id, currency} = result.data
    //     console.log("test1 before option");
    //     const options = {
    //         key: "rzp_test_QnZqng7pQVvf4L",
    //         amount: amount.toString(),
    //         currency: currency,
    //         name: "PARKIT Corp.",
    //         description: "Test Trans",
    //         image: {logo},
    //         order_id: order_id,
    //         handler: async function (response) {
    //             const vehicleId = vechicleList.filter(vehicle => vehicle.licenceNo === selectedVechicle);
    //             console.log("Id: ",vehicleId);
    //             console.log(vehicleId[0].id)

    //             const data = {
    //                 orderCreationId: order_id,
    //                 razorpayPaymentId: response.razorpay_payment_id,
    //                 razorpayOrderId: response.razorpay_order_id,
    //                 razorpaySignature: response.razorpay_signature,
    //                 bookingSlotFile: availableSpace.bookingSlotFile,
    //                 paymentDetail: {orderId:order_id,test:"1"},
    //             };
    //             console.log("test1 before result", bookingDate);
                
    //             const result = await axios.post("http://localhost:8080/customer/reserve", {bookingSlotFile:availableSpace.bookingSlotFile,vehicle_id:vehicleId[0].id, paymentDetail:data})
    //             .then((res)=>{
    //                 navigate('/my-bookings');
    //             });
                
             
    //         },
    //         notes: {
    //             address: "PARKIT Corporate Office",
    //         },
    //         theme: {
    //             color: "#61dafb",
    //         },
    //     };

    //     const paymentObject = new window.Razorpay(options);
    //     paymentObject.open();

  }

  const handleOffliceExit = () => {
    const data = {
        id: parkingId,
        license_no: vehicleNo,
        type: vehicleType

    }
    console.log(data)
    handlePayment()
    // generateOrderAdmin(data,
    //   (response) => {
    //     console.log(response)
    //         handlePayment()
    //     //show messafe and close the model
    //     onClose(true);
    //   },
    //   (error) => {
    //     console.log(error)
    //     toast.error("Something went wrong, please try again.")
    //   }
    // )


  }

  const handleReservationExit = () => {
    const data = {
      reservationId: reservationId,
      vehicleType: vehicleType,
      parkingId: parkingId,
    }
    console.log(data)
    
    reservationExitOrderGeneration(data,
      async (response)=>{
        console.log(response);
        setOrderResponse(response)

        if(response.payment) {
          const res = await loadScript(
            "https://checkout.razorpay.com/v1/checkout.js"
        );
    
          if(!res) {
              alert("RazorPay SDK failed to load, try again after some time");
              return;
          }
          console.log(orderResponse.order.amount)
          // ---------------------
          const options = {
            key: "rzp_test_QnZqng7pQVvf4L",
            amount: response.order.amount,
            currency: "INR",
            name: "PARKIT Corp.",
            description: "Test Trans",
            order_id: response.order.id,
          
            handler: async function (response) {
              console.log("payment resp: ", response)
              vehicleExitReservation({data: orderResponse, payment: response},
                (response)=>{
                  console.log(response)
                  handleClose()
                  toast.success("Vehicle exit recorded.")
                }, 
                (error)=>{
                  console.log(error)
                  toast.error("Something went wrong, please try again.")
                })
            },
            notes: {
                address: "PARKIT Corporate Office",
            },
            theme: {
                color: "#61dafb",
            },
        };

        const paymentObject = new window.Razorpay(options);
        paymentObject.open();
        // ---------------------
        } else {
          toast.success("Vehicle exit recorded.")
          handleClose();
        }
      },
      (error,message)=>{
        console.log(error)
        toast.error("Something went wrong, please try again.")
      }
    )
    // vechicleEntryOnline(data,
    //   (response) => {
    //     console.log(response)
    //     //Notify user
    //     onClose(true)
    //   },
    //   (error) => {
    //     console.log(error)
    //     //Notify user
    //   }
    // )
  }


  return (
    <Dialog onClose={handleClose} open={open}>
      <DialogTitle sx={{border:"3px solid white",backgroundColor:"black", color:'#66fcf1'}}>{!checked ? 'Vehicle Info' : 'Reservation Info'}</DialogTitle>
      <List sx={{ p: 2, backgroundColor:'#c5c6c7' }}>
      <Box >  
                <label>Reserved: </label>
                <Switch checked={checked} onChange={handleChange} inputProps={{ 'aria-label': 'controlled' }} />
                { !checked ?
                  <>
                    <TextField id="outlined-basic" label="Vehicle No" variant="outlined" fullWidth sx={{mb:2}} value={vehicleNo} onChange={(event)=>{setVehicleNo(event.target.value)}}/>
                    <TextField id="outlined-basic" label="Parking Type" variant="outlined" fullWidth sx={{mb:2}} value={vehicleType} onChange={(event)=>{setVehicleType(event.target.value)}}/>
                    <TextField id="outlined-basic" label="Parking Id" variant="outlined" fullWidth sx={{mb:2}} value={parkingId} onChange={(event)=>{setParkingId(event.target.value)}}/>
                    <Box sx={{display:'flex', justifyContent: 'center'}}>
                      <Button variant='outlined' onClick={handleOffliceExit}>Submit</Button>
                    </Box>
                  </>
                  :
                  <>
                    <TextField id="outlined-basic" label="Reservation No" variant="outlined" fullWidth sx={{mb:2}} value={reservationId} onChange={(event)=>{setReservationId(event.target.value)}} />
                    <TextField id="outlined-basic" label="Parking Type" variant="outlined" fullWidth sx={{mb:2}} value={vehicleType} onChange={(event)=>{setVehicleType(event.target.value)}}/>
                    <TextField id="outlined-basic" label="Parking Id" variant="outlined" fullWidth sx={{mb:2}} value={parkingId} onChange={(event)=>{setParkingId(event.target.value)}}/>
                    <Box sx={{display:'flex', justifyContent: 'center'}}>
                      <Button variant='outlined' onClick={handleReservationExit}>Submit</Button>
                    </Box>
                  </>
                }
                

      </Box>
      </List>
    </Dialog>
  );
}

SimpleDialog.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.string.isRequired,
};

export default function SimpleDialogDemo(props) {
  const [open, setOpen] = React.useState(false);
  const [selectedValue, setSelectedValue] = React.useState(emails[1]);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = (value) => {
    setOpen(false);
    setSelectedValue(value);
  };

  return (
    <div style={{display:'inline-flex', marginLeft:"360px"}}>
      <Typography variant="subtitle1" component="div">
        {/* Selected: {selectedValue} */}
      </Typography>
      <br />
      <Button variant="outlined" onClick={handleClickOpen}>
        {props.name}
      </Button>
      <SimpleDialog
        selectedValue={selectedValue}
        open={open}
        onClose={handleClose}
      />
    </div>
  );
}