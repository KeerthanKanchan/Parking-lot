import axios from "axios";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { Container } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../services/auth/authContext";

export default function LoginPage({setLoginStatus})
{
  
  const {isAuthenticated,login} = useAuth();
  
    const defaultTheme = createTheme();
    
    const [formData,setFormData]=useState({
        userName:"",
        password:""
    });
    const [isLoading,setIsLoading]=useState(false)
    var navigate=useNavigate()

    function handleSubmit(e)
    {  
         setIsLoading(true)
        axios.post(process.env.REACT_APP_COMMON_BACKEND_URL+"/login",formData,
            {headers:{"Content-Type":"application/json"}})
            .then((response)=>{
                if(response.data)
                {
                  
                   login(response.data.userRole,response.data.id)
                    // alert(response.data.userRole)
                    toast.success("logged in sucessfully")
                    setIsLoading(false)
                    response.data.userRole === "ADMIN" ? navigate("/dashboard") : navigate("/")
                }
            })
            .catch((err)=>{
                toast.error("failed to login")
                setIsLoading(false)
            })
    }

    function handleChange(e)
    {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    }


    return(<>

    <ThemeProvider theme={defaultTheme}>
      <Box
        sx={{
          backgroundImage: `url(${process.env.REACT_APP_LOGIN_BG})` ,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Container component="main" maxWidth="xs" sx={{display: "flex",
        justifyContent: "center"}}>
          <CssBaseline />
          <Box
            sx={{
              backgroundColor: "rgba(245, 245, 245, 0.9)",
              borderRadius: "5%",
              padding: "5%",
              width: "35vw",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              minWidth:"320px",
             maxWidth:"400px",

            
           
            }}
          >
            <Avatar sx={{ m: 2, bgcolor: "secondary.main" }}>
              <LockOutlinedIcon />
            </Avatar>
            <Typography component="h1" variant="h5">
              Sign in
            </Typography>
            <Box
              
              onSubmit={handleSubmit}
              noValidate
              sx={{ mt: 1, width: "100%" }}
            >
              <TextField
                margin="normal"
                required
                fullWidth
                id="userName"
                label="Email Address or Phone No "
                name="userName"
                autoComplete="email"
                autoFocus
                onChange={handleChange}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                onChange={handleChange}
              />
              <Button onClick={handleSubmit}
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 , color:"white!important"}}
              >
                Sign In
              </Button>
              <Grid container spacing={2}>
                <Grid item xs>
                  {/* <Link href="#" variant="body2" >
                    Forgot password?
                  </Link> */}
                </Grid>
                <Grid item>
                  <Link href="/signup" variant="body2">
                    {"Don't have an account? Sign Up"}
                  </Link>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Container>
      </Box>
    </ThemeProvider>

    </>)
}