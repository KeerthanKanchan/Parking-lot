
import * as React from 'react'; 
import Box from '@mui/material/Box'; 
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import { Grid } from '@mui/material';




export default function App(props) { 
	return ( 	
        <Card sx={{display:"inline-flex",width:"300px", height:"200px",borderRadius:"20px",backgroundColor:"white", mx:7,mt:"1px",  border:"solid 5px white"}}>
        <Grid container sx ={{display:"flex"}}xs={12}> 
                <Grid item xs={12}  height={65} 
                 display={'flex'}
                 color={{ color:'#66fcf1', background:"#0b0c10"}}
                 justifyContent={'center'}
                 alignItems={'center'}> 
                 <strong>
                        {props.name}
                </strong>
                </Grid> 
                <Grid item xs={6}  height={65} 
                 display={'flex'}
                 justifyContent={'center'}
                 alignItems={'center'}
                 color={{ background: '#c5c6c7' }}> 
                  Two Wheeler
                </Grid> 
                <hr />
                <Grid item xs={5.9} height={65} 
                 display={'flex'}
                 justifyContent={'center'}
                 alignItems={'center'}
                 color={{ background: '#c5c6c7' }}> 
                 Four Wheeler
                </Grid> 
                <Grid item xs={6} height={60} 
                margin={0}
                display={'flex'}
                 justifyContent={'center'}
                 alignItems={'center'}
                 color={{ background: '#c5c6c7' }}> 
                 {props.number1}
                </Grid> 
                <hr />
                <Grid item xs={5.9} height={60}  
                  display={'flex'}
                  justifyContent={'center'}
                  alignItems={'center'}
                  color={{ background: '#c5c6c7' }}> 
                  {props.number2}
                </Grid> 
            </Grid> 
        </Card> 
			
	); 
}

