import React from 'react'
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { Button, Card, Grid } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import ClearIcon from '@mui/icons-material/Clear';
import HeaderComponent from "./IconRendering.js";


const shouldDisplayButton = false;

function MyBookings() {
  return (
    <div style={{width:"60%",marginLeft:"auto", marginRight:"auto"}}>

    <div style={{display:'flex', justifyContent:'center', alignitems:'center'}}>
      {/* <div>
      <AccessTimeIcon sx={{display:"flex",marginLeft:'auto', marginRight:"auto"}} />
      <span style={{display:'block'}}>This is the second sentence.</span>
      <span style={{display:'block'}}>This is the second sentence.</span>
      
      </div> */}
      <HeaderComponent />
      
    </div>
    <Card sx={{display:"flex",backgroundColor:'#c5c6c7', justifyContent:'center', border:'1px solid white', marginTop:"30px", mx:"20px", p:"10px", borderRadius:"10px"}}>
       <Grid container sx={{display:"flex", justifyContent:'center'}}>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Entry time</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>10:00</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Exit time</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>11:00</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Parking spot</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>E34</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        </Grid> 
        </Card> 
    <Card sx={{display:"flex",backgroundColor:'#c5c6c7', justifyContent:'center', border:'1px solid white', marginTop:"10px", mx:"20px", p:"10px", borderRadius:"10px"}}>
       <Grid container sx={{display:"flex", justifyContent:'center'}}>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Vehicle type</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>Four wheeler</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Vehicle color</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>Snow White</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Vehicle No</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>KA 01 EE 1234</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        </Grid> 
        </Card> 
    <Card sx={{display:"flex",backgroundColor:'#c5c6c7', justifyContent:'center', border:'1px solid white', marginTop:"10px", mx:"20px", p:"10px", borderRadius:"10px"}}>
       <Grid container sx={{display:"flex", justifyContent:'center'}}>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Payment id</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>pay132663</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Paymen gateway</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>GPay</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        <Grid item xs={2}>
        
        </Grid>
        <Grid item xs={6}>
        <strong>Amount Paid</strong>
        </Grid>
        <Grid item xs={3}>
        <strong>$69</strong>
        </Grid>
        <Grid item xs={1}>
        
        </Grid>
        </Grid> 
        </Card> 
        <div style={{display:"flex", marginTop:"20px",justifyContent:'center', marginBottom:"20px"}}>

       {shouldDisplayButton && ( <Button variant='contained' sx={{marginLeft:"20px",marginRight:"25px"}}><ClearIcon />Cancel</Button>)}
        <Button variant='outlined'sx={{marginLeft:"25px",marginRight:"20px"}}><DownloadIcon />Invoice</Button>
        </div>
      
    </div>
  )
}

export default MyBookings;