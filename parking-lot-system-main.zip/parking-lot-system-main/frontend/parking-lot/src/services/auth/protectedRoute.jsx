import React from 'react';
import { Navigate, Outlet, Route, useLocation, } from 'react-router-dom';
import { useAuth } from './authContext';
import { LoadingPage } from '../../pages/loadingPage';

const ProtectedRoute = ({allowedRoles}) => {
    const {isAuthenticated, userRole, isLoading} = useAuth();
    const location = useLocation();
    
    if(isLoading) {
        return <LoadingPage />
    }

    if (!isAuthenticated || !allowedRoles.includes(userRole))  {
        console.log("User not autheticated");
        return <Navigate to='/login' state={{from: location}} />;
    }

    return <Outlet />;
};

export default ProtectedRoute;