import React, {createContext, useState, useContext, useEffect} from 'react';
import Cookies from 'js-cookie';
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [userRole, setUserRole] = useState('visitor');
    const [userId, setUserId] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(()=>{
        var CookieIsAuthenticated=Cookies.get("isAuthenticated");
        var CookieUserId=Cookies.get("userId")
        var CookieUserRole=Cookies.get("userRole")

        if(CookieIsAuthenticated)
        {
            setIsAuthenticated(CookieIsAuthenticated)
            setUserId( CookieUserId)
            setUserRole( CookieUserRole)
        }
        console.log(isLoading)
        setIsLoading(false);
        console.log(isLoading)
    },[])

    const login = (role,id) => {
       Cookies.set("isAuthenticated",true,{secure: true, sameSite: 'Strict' ,expires: 365})
       Cookies.set("userRole",role,{secure: true, sameSite: 'Strict' ,expires: 365})
       Cookies.set("userId",id,{secure: true, sameSite: 'Strict' ,expires: 365})
        setIsAuthenticated(true);
        setUserRole(role);
        setUserId(id)
    };
    
    const logout = () => {
        setIsAuthenticated(false);
        setUserRole('visitor');
        setUserId(null)
        Cookies.remove("userRole")
        Cookies.remove("userId")
        Cookies.remove("isAuthenticated")
    };

    const toggleLoading = (value) => {
        //value = true then start loading else stop loading
        if (value) {
            setIsLoading(value);
        } else {
            setIsLoading(value);
        }
    } 

    return (
        <AuthContext.Provider value={{isAuthenticated, userRole, login, logout, userId, isLoading}}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);