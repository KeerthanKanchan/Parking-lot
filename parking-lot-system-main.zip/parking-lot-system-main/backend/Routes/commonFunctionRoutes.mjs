import express from 'express';
import commonFuncions from '../controller/commonFuntions.mjs';


const commonFunctionObj=new commonFuncions()

const commonFunctionRoutes = express.Router();

commonFunctionRoutes.post('/login', commonFunctionObj.login);
commonFunctionRoutes.post('/profile', commonFunctionObj.getProfile);
commonFunctionRoutes.post('/addMessage', commonFunctionObj.addMessage);
commonFunctionRoutes.post('/updateTicketstatus', commonFunctionObj.updateTicketStatus);
commonFunctionRoutes.post('/getReciepts', commonFunctionObj.getReciept);
export default commonFunctionRoutes ;