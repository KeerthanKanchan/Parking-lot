import express from 'express';

import adminFuncions from '../controller/adminController.mjs';


const adminFunctionObj=new adminFuncions()

const adminFunctionRoutes = express.Router();
adminFunctionRoutes.get('/getAllParkingSpace', adminFunctionObj.getAllParkingSpace);

adminFunctionRoutes.post('/updateParkingSpaceStatus', adminFunctionObj.ChangeParkingSpaceStatus);

adminFunctionRoutes.post('/addParkingSpace', adminFunctionObj.addParkingSpace);
adminFunctionRoutes.post('/editParkingSpace', adminFunctionObj.editParkingSpace);

adminFunctionRoutes.post('/vehicleEntryOffline', adminFunctionObj.vehicleEntryOffline);
// adminFunctionRoutes.post('/getReservationDetails', adminFunctionObj.getReservationDetails);
adminFunctionRoutes.post('/vechicleEntryOnline', adminFunctionObj.vehicleEntryReservation);
adminFunctionRoutes.post('/generateOrder', adminFunctionObj.generateOrder);
adminFunctionRoutes.post('/vehicleExitOffline', adminFunctionObj.vehicleExitOffline);

adminFunctionRoutes.post('/reservationExitOrderGeneration', adminFunctionObj.reservationExitOrderGeneration);
adminFunctionRoutes.post('/vehicleExitReservation', adminFunctionObj.vehicleExitReservation);
adminFunctionRoutes.get('/getPrices', adminFunctionObj.getPrices);
adminFunctionRoutes.post('/updatePrice', adminFunctionObj.updatePrices);

adminFunctionRoutes.get('/getReservation', adminFunctionObj.getReservationData);
adminFunctionRoutes.get('/getParking', adminFunctionObj.getparking);
export default adminFunctionRoutes ;