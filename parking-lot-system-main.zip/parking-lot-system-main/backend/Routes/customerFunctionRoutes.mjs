import express from 'express';
import customerFuncions from '../controller/customerFunctions.mjs';
import multer from 'multer';


const storage = multer.memoryStorage(); 
const upload = multer({ storage: storage });
multer
const customerFunctionObj=new customerFuncions()

const customerFunctionRoutes = express.Router();

customerFunctionRoutes.post('/signup', customerFunctionObj.signup);
customerFunctionRoutes.post('/updateProfile',  upload.single('profile'),customerFunctionObj.updateProfile);
customerFunctionRoutes.post('/profileData', customerFunctionObj.profileData);
customerFunctionRoutes.post('/addVehicle', customerFunctionObj.addVehicle);
customerFunctionRoutes.post('/getVehicle', customerFunctionObj.getVehicle);
customerFunctionRoutes.post('/editVehicle', customerFunctionObj.editVehicle);
customerFunctionRoutes.post('/deleteVehicle', customerFunctionObj.deleteVehicle);
customerFunctionRoutes.post('/mybookings', customerFunctionObj.getmyBooking);
customerFunctionRoutes.post('/getSlot', customerFunctionObj.getSlot);
customerFunctionRoutes.post('/generateOrder', customerFunctionObj.genearateOrder);
customerFunctionRoutes.post('/reserve', customerFunctionObj.reserve);
customerFunctionRoutes.post('/createTicket', customerFunctionObj.createTicket);
customerFunctionRoutes.post('/myTicket', customerFunctionObj.getMyTicket);

export default customerFunctionRoutes ;