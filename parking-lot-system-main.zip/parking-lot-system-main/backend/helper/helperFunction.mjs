import  db  from "../models/index.cjs"
export default class helperFunctions
 {
     async calculatePrice(entryTime,exitTime,type)
     {

        try {
           
            const parkingPrice = await db.parkingPrice.findOne({ where: { type: type+"" } });
            console.log(parkingPrice)
            
            if (!parkingPrice) {
                throw new Error(`No price found for type: ${type}`);
            }
    
           
            const entry = new Date(entryTime);
            const exit = new Date(exitTime);
            const timeDifferenceInHours = (exit - entry) / (1000 * 60 * 60); 
    
          
            const totalPrice = Math.round(timeDifferenceInHours * parkingPrice.price);
     
            return totalPrice;
        } catch (error) {
            console.error('error calculating price:', error);
           
        }
     }


 }