const { Sequelize, DataTypes } = require("sequelize");
module.exports=(sequelize,DataTypes)=>{
    const customerDetails=sequelize.define("customerDetails",{
        id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,        
            autoIncrement: true 

        },
        loginTableId:{
            type:DataTypes.INTEGER,
            allowNull:false,
            refernce:{
                model: 'login_details',
                key:"id"
            }
        },
        profile: {
            type: DataTypes.BLOB("long"),
            allowNull: true,
        },
        name:{
            type:DataTypes.STRING(50),
            allowNull:false,
        },
        address:{
            type:DataTypes.STRING(100),
            allowNull:false,
        },
        landmark:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },
        city:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },

        state:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },
        country:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },
        pin:{
            type:DataTypes.STRING(15),
            allowNull:false,
        },
        deleted:{
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
        ,
        createdAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        },
        vehicleCount: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0
        }
    }
    ,{
        tableName: 'customer_details', 
        timestamps: false
    })
    
    customerDetails.associate = function(models) {
        customerDetails.hasMany(models.vehicleDetails, {
            foreignKey: 'customerId',
            as: 'vehicles'
        });
        customerDetails.hasMany(models.reservations, {
            foreignKey: 'customer_id',
            as: 'registeredCustomer'
        });
    };
   
        


    return customerDetails;

}
