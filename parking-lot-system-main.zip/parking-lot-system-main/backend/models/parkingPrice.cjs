const { Sequelize, DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const parkingPrice = sequelize.define("parkingPrice", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
      
       price: {
            type: DataTypes.INTEGER,
            allowNull: true,
            default:40
        },
        type: {
            type: DataTypes.ENUM('2', '4'),
            allowNull: false,
            defaultValue:"2"
        },
      
    }, {
        tableName: 'parking_price',
        timestamps: false,
    });

    return parkingPrice;
};
