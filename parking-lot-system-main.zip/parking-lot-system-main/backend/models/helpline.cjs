const { Sequelize, DataTypes, Model } = require('sequelize');


module.exports = (sequelize, DataTypes) => {
    const helpline = sequelize.define('helpline', {
        ticket: {
            type: DataTypes.STRING,
            allowNull: false,
            primaryKey: true,
          
        },
        customerid:{
            type: DataTypes.INTEGER,
            allowNull: false,
            referce:{
                model:"customer_details",
                key:"id"
            }
        },
       
       title:{
            type:DataTypes.STRING(150),
            allowNull:false,

        },
       description:{
            type:DataTypes.STRING(1000),
            allowNull:false,

        },
        chat:{
            type: DataTypes.JSON,
            allowNull:true,
        },
        status:{
            type:DataTypes.STRING(1000),
            allowNull:false,
            defaultValue:"INACTIVE"
        }
      
    }, {
        tableName: 'helpline',
        timestamps: true

        
    });

   
    return helpline;
};