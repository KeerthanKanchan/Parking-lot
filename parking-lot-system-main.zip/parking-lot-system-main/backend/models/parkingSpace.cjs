const { Sequelize, DataTypes, Model } = require('sequelize');


module.exports = (sequelize, DataTypes) => {
    const parkingSpace = sequelize.define('parkingSpace', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        space_no: {
            type: DataTypes.STRING(10),
            allowNull: false,
            unique: true
        },
        type: {
            type: DataTypes.INTEGER,
            allowNull: false,
            default:"2",
           
        },
        enabled: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        }
    }, {
        tableName: 'parking_space',
        timestamps: false
    });

    parkingSpace.associate = function(models) {
        parkingSpace.hasMany(models.spaceAvailability, {
            foreignKey: 'space_id',
            as: 'availability'
        });

        parkingSpace.hasMany(models.reservations, {
            foreignKey: 'space_id',
            as: 'reservationSpace'
        });
    };
    return parkingSpace;
};