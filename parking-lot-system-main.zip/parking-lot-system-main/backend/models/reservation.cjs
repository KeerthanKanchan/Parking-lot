const { Sequelize, DataTypes, Model } = require('sequelize');


module.exports = (sequelize, DataTypes) => {
    const reservations = sequelize.define('reservations', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        space_id:{
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                        model: 'parking_space',
                        key: 'id'
                    }
            },
       
       customer_id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            
            refernce:{
                model: 'customer_details',
                key:"id"
            }
        },
       vehicle_id:{
            type: DataTypes.INTEGER,
            allowNull: false,
            refernce:{
                model: 'vehicle_details',
                key:"id"
            }
        },
        reservation_entry_time : {
            type: DataTypes.DATE,
            allowNull: false,
           
           
        },
        reservation_exit_time: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        payment_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
              model: 'payments', 
              key: 'id',
            },
          },
        
    }, {
        tableName: 'reservation',
        timestamps: true
    });

      reservations.associate = function(models) {
        reservations.hasMany(models.parking, {
            foreignKey: 'reservation_id',
            as: 'reservationId'
        });

      
    };
    return reservations;
};