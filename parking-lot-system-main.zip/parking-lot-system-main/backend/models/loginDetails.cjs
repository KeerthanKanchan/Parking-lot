const { Sequelize, DataTypes } = require("sequelize");

module.exports=(sequelize,DataTypes)=>{
    const loginDetails=sequelize.define("loginDetails",{
        id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,        
            autoIncrement: true 

        },
        email:{
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate:{
                isEmail:true
            }
        },
        phoneNo:{
            type: DataTypes.STRING(10),
            allowNull: false,
            unique: true ,
            validate:{
                isNumeric:true,
                len:[10,10]
            }
        },
        password:{
            type: DataTypes.STRING,
            allowNull: false,
            unique: false ,
         
        },
        userRole:{
            type: DataTypes.STRING,
            allowNull: false,
            defaultValue:"CUSTOMER",
         
        },
        deleted:{
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
        ,
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: Sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: Sequelize.NOW
        }
    }
    ,{
        tableName: 'login_details', 
        timestamps: false
    }
);

loginDetails.associate = function(models) {
    loginDetails.hasOne(models.customerDetails, {
        foreignKey: 'loginTableId',
        as: 'customer'
    });
};
return loginDetails;
}