const { Sequelize, DataTypes, Model } = require('sequelize');


module.exports = (sequelize, DataTypes) => {
    const payments = sequelize.define('payments', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        amount:{
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        
        date:{
            type:DataTypes.DATE,
            allowNull:false,

        },
        paymentDetail:{
            type: DataTypes.JSON,
            allowNull:true,
        }

    }, {
        tableName: 'payments',
        timestamps: true

        
    });

    payments.associate = function(models) {
        payments.hasMany(models.reservations, {
            foreignKey: 'payment_id',
            as: 'reservepaymentId'
        });

       payments.hasMany(models.offlineEntry, {
            foreignKey: 'payment_id',
            as: 'offlinePaymentId'
        });
    };
    return payments;
};