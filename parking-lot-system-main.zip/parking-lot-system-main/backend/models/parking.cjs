const { Sequelize, DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const parking = sequelize.define("parking", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        entry_time: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        exit_time: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        method: {
            type: DataTypes.ENUM('reservation', 'offline'),
            allowNull: false,
        },
        reservation_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
                model: 'reservation',
                key: 'id',
            },
        },
        offline_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
                model: 'offline_entry',
                key: 'id',
            },
        },
    }, {
        tableName: 'parking',
        timestamps: false,
    });

    return parking;
};
