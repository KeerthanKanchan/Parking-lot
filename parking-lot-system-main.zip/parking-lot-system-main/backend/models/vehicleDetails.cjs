const { Sequelize, DataTypes } = require("sequelize");
module.exports=(sequelize,DataTypes)=>{
    const vehicleDetails=sequelize.define("vehicleDetails",{
        id:{
            type:DataTypes.INTEGER,
            allowNull:false,
            primaryKey: true,        
            autoIncrement: true 

        },
        customerId:{
            type:DataTypes.INTEGER,
            allowNull:false,
            
            refernce:{
                model: 'customer_details',
                key:"id"
            }
        },
        licenceNo: {
            type:DataTypes.STRING(50),
            allowNull: true,
        },
        manufacturer:{
            type:DataTypes.STRING(50),
            allowNull:false,
        },
        model:{
            type:DataTypes.STRING(50),
            allowNull:false,
        },
        color:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },
        vehicleType:{
            type:DataTypes.STRING(2),
            allowNull:false,
        },

        additionalInfo:{
            type:DataTypes.STRING(40),
            allowNull:false,
        },
        deleted:{
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
        ,
        createdAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        },
       
    }
    ,{
        tableName: 'vehicle_details', 
        timestamps: false
    }
)

vehicleDetails.associate= function(models) {
    vehicleDetails.hasMany(models.reservations, {
        foreignKey: 'vehicle_id',
        as: 'registeredVehicle'
    });
    
};
    return vehicleDetails;

}