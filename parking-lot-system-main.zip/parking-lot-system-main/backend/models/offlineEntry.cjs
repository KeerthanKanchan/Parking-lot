const { Sequelize, DataTypes } = require("sequelize");

module.exports=(sequelize,DataTypes)=>{
    const offlineEntry=sequelize.define("offlineEntry",{
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
          },
          license_no: {
            type: DataTypes.STRING,
            allowNull: false,
          },
          space_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
              model: 'parking_space',
              key: 'id',
            },
          },
          payment_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
              model: 'payments', 
              key: 'id',
            },
          },
        },
{
    tableName: 'offline_entry', 
    timestamps: false
}
);
offlineEntry.associate = function(models) {
    offlineEntry.hasMany(models.parking, {
        foreignKey: 'offline_id',
        as: 'offlineId'
    });

  
};
return offlineEntry;
}