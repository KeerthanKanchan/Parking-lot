const { Sequelize, DataTypes, Model } = require('sequelize');


module.exports = (sequelize, DataTypes) => {
    const spaceAvailability = sequelize.define('spaceAvailability', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
       space_id:{
        type: DataTypes.INTEGER,
        allowNull: false,
     references: {
                model: 'parking_space',
                key: 'id'
            }
        },
        date: {
            type: DataTypes.DATEONLY,
            allowNull: false
        },
       
        "1AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "2AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "3AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "4AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "5AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "6AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "7AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "8AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "9AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "10AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "11AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "12AM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
       
        "1PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "2PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "3PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "4PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "5PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "6PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "7PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "8PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "9PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "10PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "11PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        "12PM": {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
    },
     {
        tableName: 'space_availability',
        timestamps: true
    });

    return spaceAvailability;
};