import express from 'express';
import db from './models/index.cjs';
import cors from 'cors';
import commonFunctionRoutes from './Routes/commonFunctionRoutes.mjs';
import customerFunctionRoutes from './Routes/customerFunctionRoutes.mjs';
import multer from 'multer';
import adminFunctionRoutes from './Routes/adminRoutes.mjs';
import { Server } from 'socket.io';
import http from 'http';
import listenToHelplineChanges from './service/helper.mjs';
import adminlistenToHelplineChanges from './service/adminHelper.mjs';
import dashbordChanges from './service/dashbordServicce.mjs';
import crons from 'node-cron'
import slotGeneration from './service/slotGeneration.mjs';
import updateSpotStatus from './service/updateSpotStatus.mjs';
const app = express();
const server = http.createServer(app); 

const io = new Server(server, {
    cors: {
        origin: 'http://localhost:3000',
        methods: ['GET', 'POST']
    }
});

const PORT = process.env.PORT || 8080;

// Add CORS middleware
app.use(cors({
    origin: 'http://localhost:3000'
}));

// Add body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use("/common", commonFunctionRoutes);
app.use("/customer", customerFunctionRoutes);
app.use("/admin", adminFunctionRoutes);



crons.schedule('0 0 * * *', slotGeneration);
crons.schedule('0 * * * *', updateSpotStatus);


io.on('connection', (socket) => {
    console.log('New client connected');

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});
app.set('io', io);

server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


db.sequelize.sync().then( async () => {
    console.log('Database synchronized');
    try {
        const newParkingPrices = [
            { id: "1", type: "2", price: "50" },
            { id: "2", type: "4", price: "50" }
        ];
    
        // Fetch existing records to filter out duplicates
        const existingParkingPrices = await db.parkingPrice.findAll({
            where: {
                id: newParkingPrices.map(price => price.id)
            }
        });
    
        // Filter out duplicates
        const existingIds = existingParkingPrices.map(price => price.id);
        const parkingPricesToInsert = newParkingPrices.filter(price => !existingIds.includes(price.id));
    
        if (parkingPricesToInsert.length > 0) {
            await db.parkingPrice.bulkCreate(parkingPricesToInsert);
            console.log("Prices inserted successfully");
        } else {
            console.log("No new prices to insert");
        }

    } catch (e) {
        // console.error("Error inserting prices");
    }
});

listenToHelplineChanges(io);
adminlistenToHelplineChanges(io)
dashbordChanges(io);
