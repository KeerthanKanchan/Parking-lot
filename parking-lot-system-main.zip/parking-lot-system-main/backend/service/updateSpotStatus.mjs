import { where } from "sequelize";
import db from "../models/index.cjs";

export default async function updateSpotStatus() {

    try {
        const now  = new Date();
        const todaysDate = Date(now.toISOString().split('T')[0]);
        // const todaysDate = now;
        const time = now.getHours() > 12 ? (now.getHours() - 12)+ "PM": (now.getHours()+1)+"AM";

        // console.log();
        const parked = await db.parking.findAll({where:{exit_time: null}});

        const reserve = parked.filter((reserved) => reserved.reservation_id !== null).map((r)=>r.reservation_id);
        const offline = parked.filter((reserved) => reserved.offline_id !== null).map((r)=>r.offline_id);

        var offlineEntry = await db.offlineEntry.findAll({attributes:['space_id'],where:{id: offline}});

        offlineEntry.map(async(entry)=>{
            await db.spaceAvailability.update({[time]: 0}, {where:{date: todaysDate, space_id: entry.space_id}}).then((res)=>console.log(res));

        })

        const reservationEntry = await db.reservations.findAll({attributes:['space_id'],where:{id: reserve}});

        reservationEntry.map(async (entry)=>{
            await db.spaceAvailability.update({[time]: 0}, {where:{date: todaysDate, space_id: entry.space_id}}).then((res)=>console.log(res));
        })


        // const spaceAvail = await db.spaceAvailability.bulkUpdate({where:{exit_time: null}});
        // console.log("parkedone: ",parkedone);
} catch (error) {
        console.log("Something went wrong,", e)
    }
}
