

import db from '../models/index.cjs';
import { Op } from 'sequelize';

const HELPLINE_CHANNEL_PREFIX = 'helpline_changes_'; 

export default function listenToHelplineChanges(io) {
    
    io.on('connection', (socket) => {
        console.log(`Client connected: ${socket.id}`);

       
        socket.on('subscribe_to_helpline', async (id) => {
            try {
                console.log(id)
              
                const customerDetail = await db.customerDetails.findOne({
                    where: { loginTableId: id }
                });

                console.log(customerDetail.id)

                if (customerDetail) {
                    const customerId = customerDetail.id;
                    const channelName = `${HELPLINE_CHANNEL_PREFIX}${customerId}`;

                   
                    socket.join(channelName);
                    console.log(`Client ${socket.id} subscribed to channel ${channelName}`);

                   
                    const tickets = await db.helpline.findAll({
                        where: { customerid: customerId }
                    });

                    
                    socket.emit('helpline_initial_data', { tickets });

                } else {
                    console.log(`Customer not found for id ${id}`);
                    socket.emit('subscription_failed', { error: 'Customer not found' });
                }
            } catch (error) {
                console.error('Error subscribing to helpline changes:', error);
                socket.emit('subscription_failed', { error: 'Internal server error' });
            }
        });

        socket.on('disconnect', () => {
            console.log(`Client disconnected: ${socket.id}`);
        });
    });

    
    db.helpline.afterCreate(async (ticket) => {
        try {
            const tickets = await db.helpline.findAll({
                where: { customerid: ticket.customerid }
            });
            const channelName = `${HELPLINE_CHANNEL_PREFIX}${ticket.customerid}`;
            io.to(channelName).emit('helpline_update', { action: 'create', tickets });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.helpline.afterUpdate(async (ticket) => {
        try {
         
            const tickets = await db.helpline.findAll({
                where: { customerid: ticket.customerid }
            });
    
           
            const channelName = `${HELPLINE_CHANNEL_PREFIX}${ticket.customerid}`;
    
           
            io.to(channelName).emit('helpline_update', { action: 'update', tickets });
    
            console.log(`Sent update event to channel ${channelName}`);
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
           
        }
    });
    
    // After destroy hook
    db.helpline.afterDestroy(async (ticket) => {
        try {
            const tickets = await db.helpline.findAll({
                where: { customerid: ticket.customerid }
            });
            const channelName = `${HELPLINE_CHANNEL_PREFIX}${ticket.customerid}`;
            io.to(channelName).emit('helpline_update', { action: 'delete', tickets });
        } catch (error) {
            console.error('Error in afterDestroy hook:', error);
        }
    });
}
