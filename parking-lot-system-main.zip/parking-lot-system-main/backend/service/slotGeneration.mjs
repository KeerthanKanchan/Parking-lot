import db from '../models/index.cjs';
import { Op } from 'sequelize';
export default async function slotGeneration()
{

    try{
        const spaces = await db.parkingSpace.findAll();

        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const dateString = tomorrow.toISOString().split('T')[0];

        const availabilityData = spaces.map(space => ({
            space_id: space.id,
            date: dateString
        }));
        await db.spaceAvailability.bulkCreate(availabilityData);
    }
    catch(e)
    {
        console.log(e)

    }
}