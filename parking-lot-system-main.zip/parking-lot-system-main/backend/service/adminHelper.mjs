

import db from '../models/index.cjs';
import { Op } from 'sequelize';

const HELPLINE_CHANNEL_PREFIX = 'admin_helpline_changes'; 

export default function adminlistenToHelplineChanges(io) {
    
    io.on('connection', (socket) => {
        

       
        socket.on('subscribe_to_helpline_admin', async () => {
            try {
                
                  
                    const channelName = `${HELPLINE_CHANNEL_PREFIX}`;

                   
                    socket.join(channelName);
                    console.log(`Client ${socket.id} subscribed to channel ${channelName}`);

                   
                    const tickets = await db.helpline.findAll({
                        
                    });

                    
                    socket.emit('admin_helpline_initial_data', { tickets });

            
            } catch (error) {
                console.error('Error subscribing to helpline changes:', error);
                socket.emit('admin_subscription_failed', { error: 'Internal server error' });
            }
        });

        socket.on('disconnect', () => {
            console.log(`Client disconnected: ${socket.id}`);
        });
    });

    
    db.helpline.afterCreate(async (ticket) => {
        try {
            const tickets = await db.helpline.findAll({
               
            });
            const channelName = `${HELPLINE_CHANNEL_PREFIX}`;
            io.to(channelName).emit('admin_helpline_update', { action: 'create', tickets });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.helpline.afterUpdate(async (ticket) => {
        try {
         
            const tickets = await db.helpline.findAll({
                
            });
    
           
            const channelName = `${HELPLINE_CHANNEL_PREFIX}`;
    
           
            io.to(channelName).emit('admin_helpline_update', { action: 'update', tickets });
    
            console.log(`Sent update event to channel ${channelName}`);
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
           
        }
    });
    

}
