

import db from '../models/index.cjs';
import { Op, Sequelize, where } from 'sequelize';
import parking from '../models/parking.cjs';

const CHANNEL_PREFIX = 'dashboard_changes'; 

async  function getSlotDetails(dateString,formatedTime)
{ var detail= {2:{availableSlot:0,lockedSlot:0},4:{availableSlot:0,lockedSlot:0}}

    const space = await db.parkingSpace.findAll({  
        where:{enabled:true} 
    });
   
    for(var spaceObj of space)
        {
          
           var slot=await db.spaceAvailability.findOne({
               where:{date:dateString,[formatedTime]:true,space_id:spaceObj.id}})
           if(spaceObj.type==2)
           {
           if(!slot)
           {
            detail[2].lockedSlot+=1;
            
           }
           else{
            detail[2].availableSlot+=1;
           }
        }
        else{
            if(!slot)
                {
                 detail[4].lockedSlot+=1;
                 
                }
                else{
                 detail[4].availableSlot+=1;
                } 
        }

        }
        console.log(detail)
        return detail;
}

async function getPaymentData()
{
    const paymentData = await db.payments.findAll({
        attributes: [
            [Sequelize.fn('DATE', Sequelize.col('date')), 'date'],
            [Sequelize.fn('SUM', Sequelize.col('amount')), 'total_amount'],
        ],
        group: [Sequelize.fn('DATE', Sequelize.col('date'))],
        raw: true, 
    });
    return paymentData;
}

async function getReservationData(dateString)
{
    const reservationData = await db.reservations.findAll({
        attributes: [
            [Sequelize.fn('DATE', Sequelize.col('reservation_entry_time')), 'date'], 
            [Sequelize.fn('COUNT', Sequelize.col('id')), 'count'], 
        ],
        where:
            Sequelize.where(
                Sequelize.fn('DATE', Sequelize.col('reservation_entry_time')),
                dateString
            ),
        group: [Sequelize.fn('DATE', Sequelize.col('reservation_entry_time'))], 
        raw: true, 
    });
    return reservationData
}
async function getParkingData(dateString)
{
    var data=[]
    const parkingData = await db.parking.findAll({
                       
        where:
            Sequelize.where(
                Sequelize.fn('DATE', Sequelize.col('entry_time')),
                dateString
            ),
        raw: true, 
    });

    for(var parkingobj of parkingData)
    {
        var obj={};
            obj.entry_datetime=parkingobj.entry_time
            obj.exit_datetime=parkingobj.exit_time
            obj.id=parkingobj.id;
            obj.method=parkingobj.method;
            if(parkingobj.method=="reservation")
            {  var reservationDetail=await db.reservations.findOne({where:{id:parkingobj.reservation_id}})
             
                if(reservationDetail)
                {
                var space= await db.parkingSpace.findOne({where:{id:reservationDetail.space_id}})
                var vehicle= await db.vehicleDetails.findOne({where:{id:reservationDetail.vehicle_id}})
                obj.space_no= await space.space_no;
                obj.vehicleType=await space.type;
                obj.licence_no= await vehicle.licenceNo;
              
               }

                
            }
            else if(parkingobj.method=="offline")
            {
                var offlineDetail=await db.offlineEntry.findOne({where:{id:parkingobj.offline_id}})
            
                if(offlineDetail)
                {
                var space= await db.parkingSpace.findOne({where:{id:offlineDetail.space_id}})
            
                obj.space_no= await space.space_no;
                obj.vehicleType=await space.type;
                obj.licence_no= await offlineDetail.license_no;
              
               }
        }
        data.push(obj)
        console.log(obj);
    }
    return data
}
function formatDateTo12Hour(date) {
    const hours = date.getHours();
    const period = hours >= 12 ? 'PM' : 'AM';
    const formattedHour = ((hours + 11) % 12 + 1) + period;
    return formattedHour.toUpperCase();
}  
export default function dashbordChanges(io) {
      var data={payment:{},slot:{2:{lockedSlot:0,availableSlot:0},4:{lockedSlot:0,availableSlot:0},date:''},reservation:{},parking:{}}
       io.on('connection', (socket) => {
        

       
        socket.on('subscribe_to_dashboard_updates', async () => {
            try {
                    
                 
                    const channelName = `${CHANNEL_PREFIX}`;

                    
                    socket.join(channelName);
                    console.log(`Client ${socket.id} subscribed to channel ${channelName}`);

                    var datenow=new Date();
                    
                    var formatedTime=await formatDateTo12Hour(datenow);
                    const year = datenow.getFullYear();
   
                    const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
                    const day = String(datenow.getDate()).padStart(2, '0'); 
                    const dateString = `${year}-${month}-${day}`;
                   

                    data.slot["date"]=dateString;
                    data.slot["time"]=formatedTime;
                  
                   var slotDETAIL=await  getSlotDetails(dateString,formatedTime);
                   data.slot[2]["availableSlot"]=(await slotDETAIL)[2].availableSlot;
                   data.slot[2]["lockedSlot"]=(await slotDETAIL)[2].lockedSlot;
                   data.slot[4]["availableSlot"]=(await slotDETAIL)[4].availableSlot;
                   data.slot[4]["lockedSlot"]=(await slotDETAIL)[4].lockedSlot;

                
                    data.payment=await getPaymentData();            
                    data.reservation=await getReservationData(dateString);
                    data.parking=await getParkingData(dateString);

                    socket.emit('dashboard_initial_data', {data });

            
            } catch (error) {
                console.error('Error subscribing to dasboard changes:', error);
                socket.emit('dashbord_subscription_failed', { error: 'Internal server error' });
            }
        });

        socket.on('disconnect', () => {
            console.log(`Client disconnected: ${socket.id}`);
        });
    });

    
    db.payments.afterCreate(async () => {
        try {
            data.payment=await getPaymentData();
            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'create', data });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.payments.afterUpdate(async () => {
        try {
         
          
            const channelName = `${CHANNEL_PREFIX}`;
            data.payment=await getPaymentData();
            io.to(channelName).emit('dashboard_update', { action: 'update', data });
    
            console.log(`Sent update event to channel ${channelName}`);
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
           
        }
    });
    
    db.parkingSpace.afterCreate(async () => {
        try {

            var datenow=new Date();
                    
            var formatedTime=await formatDateTo12Hour(datenow);
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            data.slot["date"]=dateString;
            data.slot["time"]=formatedTime;
            var slotDETAIL=await  getSlotDetails(dateString,formatedTime);
            data.slot[2]["availableSlot"]=(await slotDETAIL)[2].availableSlot;
            data.slot[2]["lockedSlot"]=(await slotDETAIL)[2].lockedSlot;
            data.slot[4]["availableSlot"]=(await slotDETAIL)[4].availableSlot;
            data.slot[4]["lockedSlot"]=(await slotDETAIL)[4].lockedSlot;
            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'create', data });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.parkingSpace.afterUpdate(async () => {
       try {

            var datenow=new Date();
                    
            var formatedTime=await formatDateTo12Hour(datenow);
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            data.slot["date"]=dateString;
            data.slot["time"]=formatedTime;
            var slotDETAIL=await  getSlotDetails(dateString,formatedTime);
            data.slot[2]["availableSlot"]=(await slotDETAIL)[2].availableSlot;
            data.slot[2]["lockedSlot"]=(await slotDETAIL)[2].lockedSlot;
            data.slot[4]["availableSlot"]=(await slotDETAIL)[4].availableSlot;
            data.slot[4]["lockedSlot"]=(await slotDETAIL)[4].lockedSlot;
            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'update', data });
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
        }
    });


    db.spaceAvailability.afterCreate(async () => {
        try {

            var datenow=new Date();
                    
            var formatedTime=await formatDateTo12Hour(datenow);
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            data.slot["date"]=dateString;
            data.slot["time"]=formatedTime;
            var slotDETAIL=await  getSlotDetails(dateString,formatedTime);
            data.slot[2]["availableSlot"]=(await slotDETAIL)[2].availableSlot;
            data.slot[2]["lockedSlot"]=(await slotDETAIL)[2].lockedSlot;
            data.slot[4]["availableSlot"]=(await slotDETAIL)[4].availableSlot;
            data.slot[4]["lockedSlot"]=(await slotDETAIL)[4].lockedSlot;
            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'create', data });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.spaceAvailability.afterUpdate(async () => {
       try {

            var datenow=new Date();
                    
            var formatedTime=await formatDateTo12Hour(datenow);
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            data.slot["date"]=dateString;
            data.slot["time"]=formatedTime;
            var slotDETAIL=await  getSlotDetails(dateString,formatedTime);
            data.slot[2]["availableSlot"]=(await slotDETAIL)[2].availableSlot;
            data.slot[2]["lockedSlot"]=(await slotDETAIL)[2].lockedSlot;
            data.slot[4]["availableSlot"]=(await slotDETAIL)[4].availableSlot;
            data.slot[4]["lockedSlot"]=(await slotDETAIL)[4].lockedSlot;
            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'update', data });
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
        }
    });


    db.reservations.afterCreate(async () => {
        try {
            var datenow=new Date();
            const year = datenow.getFullYear();
            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;

            data.reservation=await getReservationData(dateString);

            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'create', data });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.reservations.afterUpdate(async () => {
        try {
         
            var datenow=new Date();
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            const channelName = `${CHANNEL_PREFIX}`;

             data.reservation=await getReservationData(dateString);
            io.to(channelName).emit('dashboard_update', { action: 'update', data });
    
            console.log(`Sent update event to channel ${channelName}`);
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
           
        }
    });


    db.parking.afterCreate(async () => {
        try {
            var datenow=new Date();
            const year = datenow.getFullYear();
            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;

            data.parking=await getParkingData(dateString);


            const channelName = `${CHANNEL_PREFIX}`;
            io.to(channelName).emit('dashboard_update', { action: 'create', data });
        } catch (error) {
            console.error('Error in afterCreate hook:', error);
        }
    });
    
    
    db.parking.afterUpdate(async () => {
        try {
         
            var datenow=new Date();
            const year = datenow.getFullYear();

            const month = String(datenow.getMonth() + 1).padStart(2, '0'); 
            const day = String(datenow.getDate()).padStart(2, '0'); 
            const dateString = `${year}-${month}-${day}`;
            const channelName = `${CHANNEL_PREFIX}`;

            data.parking=await getParkingData(dateString);

            io.to(channelName).emit('dashboard_update', { action: 'update', data });
    
            console.log(`Sent update event to channel ${channelName}`);
        } catch (error) {
            console.error('Error in afterUpdate hook:', error);
           
        }
    });
}
