import { where } from "sequelize"
import { Op } from "sequelize";
import  db  from "../models/index.cjs"
import fs from "fs";
import path from "path"
import { fileURLToPath } from "url";
import { v4 as uuidv4 } from 'uuid'
import Razorpay from 'razorpay';
import { title } from "process";
import { Console, error, log } from "console";
import helperFunctions from "../helper/helperFunction.mjs";

function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

export default class customerFuncions{
 
    //signup

    async signup(req,res) {
      try{
            if(req.body!=undefined&&req.body!=null)
            {
                
                const __filename = fileURLToPath(import.meta.url);
                const __dirname = path.dirname(__filename);

                var data=req.body;
                console.log(data)
                var emailUserDetail=await db.loginDetails.findOne({
                    where:{email:data.email,}})
                var phonenoUserDetail=await db.loginDetails.findOne({
                    where:{phoneNo:data.phoneNo,}})
                if(emailUserDetail)
                {
                    res.status(400).send({result:"user with this email already exists"})
                }
                else if(phonenoUserDetail)
                {
                    res.status(400).send({result:"user with this phone number already exists"})
                }
                else{
                    var logindetail=await db.loginDetails.create(data)
                    data["loginTableId"]=logindetail.id;

                    const profileImage = fs.readFileSync(path.join(__dirname, '../uploads/deafult.jpg'  ));
                    data["profile"] = profileImage;
                    await db.customerDetails.create(data)
                    res.send({result:"registered sucessfully"})
                }

              
            }
            else{
                res.status(400).send({result:"something went wrong"})
            }
      }
      catch(err)
      {
        console.log(err)
        res.status(400).send({result:"failed to register"})
      }
        
    }


    //update profile()
    async updateProfile(req,res) {
        try{

            var data=req.body;
  
            if(req.file)
                {
                    //update profile and send it back
                    console.log(req.file.buffer)
                    var customerDetail=await db.customerDetails.findOne({
                        where:{loginTableId:data.id,}})
                    customerDetail.profile=req.file.buffer;
                    customerDetail.updatedAt=new Date();
                    customerDetail.save();
                    res.send(customerDetail.profile.toString('base64'))

                }
            else if(data.email!=undefined|| data.phoneNo!=undefined)
                {
                    // update both login details and customer name 
                    var userLoginDetail=await db.loginDetails.findOne({
                        where:{id:data.id,}})

                    userLoginDetail.email=data.email;
                    userLoginDetail.phoneNo=data.phoneNo;
                    userLoginDetail.updatedAt=new Date();

                    var customerDetail=await db.customerDetails.findOne({
                        where:{loginTableId:data.id,}})

                    customerDetail.name=data.name;
                    customerDetail.updatedAt=new Date();
                    userLoginDetail.save();
                    customerDetail.save();
                    res.send({result:"personal details updated"})
                }
                
                else{
                    console.log(data)
                    var customerDetail=await db.customerDetails.findOne({
                        where:{loginTableId:data.id,}})
                    
                    customerDetail.address=data.address
                    customerDetail.landmark=data.landmark
                    customerDetail.state=data.state
                    customerDetail.city=data.city
                    customerDetail.country=data.country
                    customerDetail.pin=data.pin
                    customerDetail.updatedAt=new Date();
                
                    customerDetail.save();
                    res.send({result:"address details updated"})
                }
         } 
         catch(err){
            res.status(400).send({result:"failed to update profile"})
         }
    }


    async profileData(req,res) 
    {
        try{
        var data=req.body
        if(data){
            var userLoginDetail=await db.loginDetails.findOne({
                attributes: ['id', 'email', 'phoneNo'],
                where:{id:data.id,}})

            var customerDetail=await db.customerDetails.findOne({
                attributes: ['name', 'address', 'state','city','pin','profile','country','landmark'],
                where:{loginTableId:data.id,}})

                var result={...customerDetail.dataValues,...userLoginDetail.dataValues};
                
                
                result["profile"]= result.profile.toString('base64');
                res.send(result)
        }
        else{
        res.status(500).send({result:"invalid request"})
        }
    } catch(err){
        res.status(500).send({result:"something went wrong"})
    }
    }


    async addVehicle(req,res) {
        try{
         var data=req.body;
           
        if(data)
        {
            var customeridDetail=await db.customerDetails.findOne({
                attributes: ['id'],
                where:{loginTableId:data.customerId,}})
            console.log(customeridDetail)
            data.customerId=customeridDetail.dataValues.id;
        
            var vehicledata = await db.vehicleDetails.create(data).then((vehicle)=>{
                data["id"]=vehicle.id
            })
   
            res.send(data)
        }
        
         else{
             res.status(400).send({result:"send correct data"});   
         }
         
     }
     catch(e)
     {
         res.status(400).send({result:"something went wrong"});
     }
    }

    async editVehicle(req,res) {
        try{
         var data=req.body;
           
        if(data)
        {
            console.log(data)
            let vehicleDetail = await db.vehicleDetails.findOne({
                where: { id: data.id }
            });
        
            if (vehicleDetail) {
              
                vehicleDetail.licenceNo = data.licenceNo;
                vehicleDetail.updatedAt = new Date();
                vehicleDetail.manufacturer = data.manufacturer;
                vehicleDetail.model = data.model;
                vehicleDetail.color = data.color;
                vehicleDetail.additionalInfo = data.additionalInfo;
                vehicleDetail.vehicleType = data.vehicleType;
                await vehicleDetail.save();
                res.send(data)
            }
            else{
                res.status(400).send({result:"failed to edit data"})
            }
        }
        
         else{
             res.status(400).send({result:"send correct data"});   
         }
         
     }
     catch(e)
     {
        console.log(e)
         res.status(400).send({result:"something went wrong"});
     }
    }


    async deleteVehicle(req,res) {
        try{
         var data=req.body;
        
        if(data)
        {
            
            let vehicleDetail = await db.vehicleDetails.findOne({
                where: { id:data.id }
            });
        if(vehicleDetail)
        {
            vehicleDetail.deleted=true
            vehicleDetail.updatedAt=new Date();
            vehicleDetail.save()
            res.send({result:"vehicle deleted sucessfully"})
        }
        else{
            res.status(400).send({result:"failed to delete vehicle"})
        }
              
            
        }
        
         else{
             res.status(400).send({result:"send correct data"});   
         }
         
     }
     catch(e)
     {
        console.log(e)
         res.status(400).send({result:"something went wrong"});
     }
    }

 
    async getVehicle(req,res) {
        try{
         var data=req.body;
           
        if(data)
        {
            var customeridDetail=await db.customerDetails.findOne({
                attributes: ['id'],
                where:{loginTableId:data.customerId}})
            
            data.customerId=customeridDetail.dataValues.id;
            var vehicleDetail= await db.vehicleDetails.findAll({
                where: { customerId: data.customerId,deleted:false },
              });
            
            
            var result=[]
            for(var vehicle of vehicleDetail)
            {
                result.push(vehicle.dataValues )
           
            }
            res.send(result)
        }
        
         else{
             res.status(400).send({result:"send correct data"});   
         }
         
     }
     catch(e)
     {
        console.log(e)
         res.status(400).send({result:"something went wrong"});
     }
    }


    async getmyBooking(req,res)
    {

        try{
            var data=req.body;
              
           if(data)
           {
               var customeridDetail=await db.customerDetails.findOne({
                   where:{loginTableId:data.id}})
                var  loginDetail=await db.loginDetails.findOne({
                where:{id:data.id}})
               data.id=customeridDetail.dataValues.id;

              
               var reservationDetail=await db.reservations.findAll({
                attributes:["id","space_id","customer_id","vehicle_id","reservation_entry_time","reservation_exit_time","payment_id",],
                where:{customer_id:data.id}})

               console.log("hi",reservationDetail)
              
               var result=[]

               for(var reservation of reservationDetail)
               {
                var payment=await db.payments.findOne({attributes:["amount","date","paymentDetail"]
                    ,where:{id:reservation.payment_id}})

                var vehicleDetails=await db.vehicleDetails.findOne({
                    attributes:['licenceNo','vehicleType','color'],
                    where:{id:reservation.vehicle_id}})

                    var parkingSpaceDetail=await db.parkingSpace.findOne({
                        attributes:[ "id", "space_no","type"],
                        where:{id:reservation.space_id}})
                        
                    
                  var tempdata= {personalDetails:{...customeridDetail.dataValues,email:loginDetail.email,phoneNo:loginDetail.phoneNo},reservation:{...reservation.dataValues},vehicle:{...vehicleDetails.dataValues},parkingSpace:{...parkingSpaceDetail.dataValues},payment:{...payment.dataValues}}
                   result.push(tempdata)
               }
               res.send(result)
           }
           
            else{
                res.status(400).send({message:"send correct data"});   
            }
            
        }
        catch(e)
        {
           console.log(e)
            res.status(400).send({message: "something went wrong"});
        }

    }
    
    // send available slot and check if slot available at that

    async getSlot(req,res)
    {

       
        try{
  

            function checkFileExists(folderPath, filename) {
                try {
                    const files = fs.readdirSync(folderPath);
                    return files.includes(filename);
                } catch (error) {
                    console.error('Error checking file existence:', error);
                    return false;
                }
            }
         console.log(data)
            function formatDateTo12Hour(date) {
                const hours = date.getHours();
                const period = hours >= 12 ? 'PM' : 'AM';
                const formattedHour = ((hours + 11) % 12 + 1) + period;
                return formattedHour.toUpperCase();
            }

            var data=req.body;
            var avilable =true;
            var space=null;
            
            console.log(data)
           if(data)
           {
            var space_no=null;
            var entryTime= new Date(data.entryTime);
           var exitTime = new Date( data.exitTime);
           
            
            const timeDifference = exitTime - entryTime;
       
            var blockTime={};
            var ActivateTime={}
            
            var space=await db.parkingSpace.findAll({attributes:["id","space_no"],where:{
                "type":data.vehicleType,enabled:true
            }})
            if(space.length==0)
                {
                    avilable=await false;
                }
            for(var spaceObj of space)
            {
               
            
            avilable=true;
            blockTime={};
            ActivateTime={};
            var currentTime=new Date(entryTime);
            while (currentTime<exitTime) {
               
                currentTime.setHours(currentTime.getHours() + 1);  
                 var formatedTime= formatDateTo12Hour(currentTime)
               

                 const year = currentTime.getFullYear();

                 const month = String(currentTime.getMonth() + 1).padStart(2, '0'); 
                 const day = String(currentTime.getDate()).padStart(2, '0'); 
                 const dateString = `${year}-${month}-${day}`;

                var slot=await db.spaceAvailability.findOne({
                    where:{date:dateString,[formatedTime]:true,space_id:spaceObj.id}})
                
                    console.log("/n/n/n/n"+slot+" /n/n/n/n")
                if(!slot)
                {
                  avilable=false
                  break;
                }
                else{
                    if(!blockTime[dateString])
                    {
                        blockTime[dateString]=[formatedTime]
                        ActivateTime[(dateString)]=[formatedTime]
                    
                    }
                    else{
                        blockTime[(dateString)].push(formatedTime)
                        ActivateTime[(dateString)].push(formatedTime)
                    }
                }

            }
            if(avilable)
            {
                space=spaceObj.id;
                space_no=spaceObj.space_no
                break
            }
         }
        console.log(space)
       
            if(avilable)
            {

                const bookingDetails = await {
                    status: 'pending',
                    space_id:space,
                    userId:data.userId,
                    vehicleId:data.vehicle_id,
                    entryTime:formatDate(entryTime),
                    exitTime:formatDate(exitTime),
                    time:{...blockTime}
                };
                do {
                    var filePath = `./bookings/${uuidv4()}.json`;
                }
                while( await checkFileExists("./bookings" ,filePath))

                fs.writeFileSync(filePath, JSON.stringify(bookingDetails, null, 2));
               
                

                for (const date of Object.keys(blockTime)) {
                    const slot = await db.spaceAvailability.findOne({
                        where: { date: date,space_id:space }
                    });
                    for (const time of blockTime[date]) {
                        slot[time] = false;
                        
                    }
                    await slot.save();

                }

                

                setTimeout(async () => {
                    try{
                    const bookingData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
                    if (bookingData.status == 'pending') {
                        for (const date of Object.keys(blockTime)) {
                            const slot = await db.spaceAvailability.findOne({
                                where: { date: date ,space_id:space}
                            });
                            for (const time of blockTime[date]) {
                                slot[time] = true;
                            }

                            await slot.save();
                        }
                       
                        bookingData.status = 'PENDING_FAILED';
                        fs.writeFileSync(filePath, JSON.stringify(bookingData, null, 2));
                    } 
                    }catch(e)
                    {
                        console.log("may be deleted by other process")  
                    } 
                }, 5 * 60 * 1000);

                setTimeout(()=>{
                try{
                    const bookingData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
                    if (bookingData.status == 'PENDING_FAILED') {
                    fs.unlinkSync(filePath);
                    console.log("deleted")
                    }
                }
                catch(e)
                {
                    console.log("may be deleted by other process")
                }
                },10*60*1000)


              
            
            // Format the date in the specified options
            var final_price=await new helperFunctions().calculatePrice(entryTime,exitTime,data.vehicleType)
         
                res.send({  entryTime: data.entryTime,
                    exitTime: data.exitTime,space_id:space_no,bookingSlotFile:filePath,price:final_price});
            }
            else{ 
                res.status(400).send({message:"slot not available"})
            }

               
           }
          else
           {
                res.status(400).send({message:"send correct data"});   
           }
            
        }
        catch(e)
        {
           console.log(e)
            res.status(400).send({message:"something went wrong"});
        }
  
    }











    async genearateOrder(req,res)
    {
        try{

        function checkFileExists(filePath)
        {
            try {
                return fs.existsSync(filePath);
            } catch (error) {
                console.error('Error checking file existence:', error);
                return false;
            }
        }

        var data=req.body;
        if(data)
        {   console.log(data.bookingSlotFile)

            if(checkFileExists(data.bookingSlotFile))
            {
            
                let bookingDetails = JSON.parse(fs.readFileSync(data.bookingSlotFile, 'utf8'));
            
                if( bookingDetails.status == 'pending')
                {
                const razorpayInstance = new Razorpay({
                    key_id: 'rzp_test_QnZqng7pQVvf4L',        
                    key_secret: 'mzH81EeTbtuMtDu8wNXfpecd'
                    
                });

                const options = {
                    amount: data.amount * 100, 
                    currency: "INR",
                    payment_capture: 1 
                };

                const order = await razorpayInstance.orders.create(options);
            
                  
                bookingDetails.status = 'ORDER';
                bookingDetails.amount=data.amount
                fs.writeFileSync(data.bookingSlotFile, JSON.stringify(bookingDetails, null, 2));
            
              setTimeout(async()=>{
                try{
                if(checkFileExists(data.bookingSlotFile))
                    {
                        let bookingFile = JSON.parse(fs.readFileSync(data.bookingSlotFile, 'utf8'));
                        if(bookingFile.status=="ORDER")
                        {
                        
                        for(var date of Object.keys(bookingFile.time))
                        {
                            const slot = await db.spaceAvailability.findOne({
                                where: { date: date ,space_id:bookingFile.space_id}
                            });
                             for(var time of bookingFile[date])
                             {
                                slot[time]=true;
                             }
                             await slot.save();
                        }
                          bookingFile.status = 'ORDER_FAILED';
                          fs.writeFileSync(data.bookingSlotFile, JSON.stringify(bookingFile, null, 2));
                        }
                    }
                } catch(e)
                {

                }
                      
              },5*60*1000)

              setTimeout(()=>{
                try{
                    let bookingFile = JSON.parse(fs.readFileSync(data.bookingSlotFile, 'utf8'));
                    if (bookingFile.status === 'ORDER_FAILED') {
                        fs.unlinkSync(data.bookingSlotFile);
                        
                        }
                }
                catch(e)
                {

                }
              },10*60*1000)

                res.send({
                    id: order.id,
                    amount: order.amount/100,
                    currency: order.currency,
                    status: order.status,
                    bookingSlotFile:data.bookingSlotFile
                });
            }
            else{
                res.status(500).send({message:"required data not found"})
            }
        }
        else{
            res.status(500).send({message:"slot expired"})
        }
        }
        else{
            res.status(500).send({message:"slot expired"})
        }

     }
     catch(e)
     {
        console.log(e)
        res.status(500).send({message:"something wnet worng"})
     }
    }



    async reserve(req,res)
    {
        try{
            var data=req.body
                console.log(data)
            function checkFileExists(filePath)
            {
                try {
                    return fs.existsSync(filePath);
                } catch (error) {
                   console.error('Error checking file existence:', error);
                    return false;
                }
            }
    
            if(data)
                {   console.log(data.bookingSlotFile)
        
                    if(checkFileExists(data.bookingSlotFile))
                    {
                      
                        let bookingDetails = JSON.parse(fs.readFileSync(data.bookingSlotFile, 'utf8'));
                        console.log(bookingDetails)
                       
                   
                        
                        const dateTimeString =formatDate(new Date())

                       
                       
                        var reservation_entry_time=formatDate( new Date(bookingDetails.entryTime))
                        var reservation_exit_time=formatDate( new Date(bookingDetails.exitTime))
                        console.log(reservation_exit_time)
                        const payment = await db.payments.create({amount:bookingDetails.amount,date:dateTimeString,paymentDetail:data.paymentDetail
                        });
                       
                        
                        var customerDetail=await db.customerDetails.findOne({
                            where:{loginTableId:bookingDetails.userId,}})
                        
                        await db.reservations.create({space_id:bookingDetails.space_id,customer_id:customerDetail.id,vehicle_id:data.vehicle_id,reservation_entry_time:reservation_entry_time,reservation_exit_time:reservation_exit_time,payment_id:payment.id}) 
                        
                        try{
                            fs.unlinkSync(data.bookingSlotFile);
                        }
                        catch(e)
                        {
                            
                        }
                        res.send({message:"slot booked sucessfully "})

                    }
                    else{
                        res.status(500).send({message:"slot expired"})
                    }
                }
                else{
                    res.status(500).send({message:"something went wrong"})
                }
           

        }
        catch(e)
        {
            console.log(e)
            res.status(500).send({result:"something went wrong"})
        }
    }



    //create ticket

    async createTicket(req,res)
    {
       var data=req.body
       try{
            if(data)
            {

            var customerDetail=await db.customerDetails.findOne({
                    where:{loginTableId:data.id,}})
            var ticket=""
            var helpline=null;
             do{
                ticket=await uuidv4();
                  helpline=await db.helpline.findOne({
                    where: { ticket: ticket }
                });
                
             }
             while(helpline)
            console.log(ticket)
             const  newTicket= await db.helpline.create({ticket:ticket,title:data.title,description:data.description,customerid:customerDetail.id,
                chat:{admin:{},customer:{[new Date()]:"title: "+data.title+"\n description: "+data.description}}})
            res.send({result:"sucessfully added new querry"})
            }
            else{
                res.status(500).send({result:"something went wrong"})
            }
       }
       catch(e)
       {
        res.status(500).send({result:"something went wrong"})
       }
    }



    async getMyTicket(req,res)
    {
       var data=req.body
       try{
            if(data)
            {

            var customerDetail=await db.customerDetails.findOne({
                    where:{loginTableId:data.id,}})
           
             const  Ticket= await db.helpline.findAll({where:{customerid:customerDetail.id}})
            res.send(Ticket)
            }
            else{
                res.status(500).send({result:"something went wrong"})
            }
       }
       catch(e)
       {
        console.log(e)
        res.status(500).send({result:"something went wrong"})
       }
    }


}
