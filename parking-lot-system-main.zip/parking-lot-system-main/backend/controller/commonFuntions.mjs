import { where } from "sequelize"
import { Op } from "sequelize";
import  db  from "../models/index.cjs"
import Razorpay from "razorpay";



export default class commonFuncions{
 
    async login(req,res) {
       try{
        var data=req.body;
        console.log(data)
        if (data && (data.userName || data.password)) {

            var userDetail=await db.loginDetails.findOne({
                where:{
                    password:data.password,
                    deleted:false
                    ,
                    [Op.or]:[
                        {email:data.userName},{phoneNo:data.userName}
                    ]
                }
            })
           
            if (userDetail) {
                userDetail.password=null;
                res.send(userDetail);
            } else {
                res.status(400).send({result:"User not found"});
            }
        }
        else{
            res.status(400).send({result:"send correct data"});   
        }
        
    }
    catch(e)
    {
        res.status(400).send({result:"something went wrong"});
    }
}
  

async getProfile(req,res)
 { 
    try{

      var data=req.body
    console.log(data)
    if(data)
        {
            var customerDetail=await db.customerDetails.findOne({
            attributes: ['profile'],
            where:{loginTableId:data.id,}})
           var profile= customerDetail.dataValues.profile.toString('base64')
         
            res.send(profile)
        }
        else{
            res.status(500).send({result:"something went wrong"})
        }
    }
    catch(e)
    {
        res.status(500).send({result:"something wnet wrong"})
    }
}

async addMessage(req, res) {
    try {
        const data = req.body;

      
        if (!data || !data.ticket || !data.user || !data.message) {
            return res.status(400).send({ result: "Missing required fields" });
        }

 
        const ticket = await db.helpline.findOne({ where: { ticket: data.ticket } });

        if (!ticket) {
            return res.status(404).send({ result: "Ticket not found" });
        }

      
        let newChat = ticket.chat;

        if (data.user === "ADMIN") {
            newChat.admin[new Date()] = data.message;
        } else {
            newChat.customer[new Date()] = data.message;
        }

      
        await db.helpline.update(
            { chat: newChat },
            { where: { ticket: data.ticket } }
        );

      
        const updatedTicket = await db.helpline.findOne({ where: { ticket: data.ticket } });

  
        const channelName = `helpline_changes_${updatedTicket.customerid}`;
        const io = req.app.get('io');  
        const Tickets = await db.helpline.findAll({ where: { customerid: updatedTicket.customerid} });
        io.to(channelName).emit('helpline_update', { action: 'update', tickets: Tickets });



        const adchannelName = "admin_helpline_changes";
        const adio = req.app.get('io');  
        const adTickets = await db.helpline.findAll({});
        adio.to(adchannelName).emit('admin_helpline_update', { action: 'update', tickets: adTickets });

       
        console.log("Message added successfully");
        return res.status(200).send({ result: "success" });
    } catch (error) {
        console.error("Error adding message:", error);
        return res.status(500).send({ result: "Something went wrong" });
    }
}


async updateTicketStatus(req, res) {
    try {
        const data = req.body;

        console.log("65")
        if (!data||!data.status) {
            return res.status(400).send({ result: "Missing required fields" });
        }
console.log("dd")
 
        const ticket = await db.helpline.findOne({ where: { ticket: data.ticket } });
        console.log("5d")
        if (!ticket) {
            return res.status(404).send({ result: "Ticket not found" });
        }

      
       
      
        await db.helpline.update(
            { status: data.status },
            { where: { ticket: data.ticket } }
        );

      
        const updatedTicket = await db.helpline.findOne({ where: { ticket: data.ticket } });

  
        const channelName = `helpline_changes_${updatedTicket.customerid}`;
        const io = req.app.get('io');  
        const Tickets = await db.helpline.findAll({ where: { customerid: updatedTicket.customerid} });
        io.to(channelName).emit('helpline_update', { action: 'update', tickets: Tickets });



        const adchannelName = "admin_helpline_changes";
        const adio = req.app.get('io');  
        const adTickets = await db.helpline.findAll({});
        adio.to(adchannelName).emit('admin_helpline_update', { action: 'update', tickets: adTickets });

       
        console.log("status successfully");
        return res.status(200).send({ result: "success" });
    } catch (error) {
        console.error("Error adding message:", error);
        return res.status(500).send({ result: "Something went wrong" });
    }
}


async getReciept(req,res)
{
    try{
        var data=req.body;
    if(data)
    {
    const razorpayInstance = new Razorpay({
        key_id: 'rzp_test_QnZqng7pQVvf4L',        
        key_secret: 'mzH81EeTbtuMtDu8wNXfpecd'
        
    });
    

           
    var payerDetails=await razorpayInstance.payments.fetch(data.paymentId);
    
    res.send(payerDetails)
}
else{
    res.status(500).send({result:"something went wrong"})
}
}
catch(e)
{
    console.log(e)
    res.status(500).send({result:"something went wrong"})
}
}
}