import { where } from "sequelize"
import { Op } from "sequelize";
import  db  from "../models/index.cjs"
import { json, response } from "express";
import { Json, Where } from "sequelize/lib/utils";
import parking from "../models/parking.cjs";
import Razorpay from 'razorpay';
import payment from "../models/payment.cjs";
import offlineEntry from "../models/offlineEntry.cjs";


export default class adminFuncions{
 
async getAllParkingSpace(req,res) {
    try{
       
        var parkingSpaceDetail=await db.parkingSpace.findAll({
            attributes: ['id','space_no','type','enabled'],
            })
        res.send(parkingSpaceDetail)
    }
    catch(e)
    {
        res.status(400).send({result:"something went wrong"});
    }
}

async ChangeParkingSpaceStatus(req,res) {
    try{
      var data=req.body;
        if(data)
        {
          var parkingSpaceDetail=await db.parkingSpace.findOne({
            where:{id:data.id,}
            })
            console.log(parkingSpaceDetail)
            if(parkingSpaceDetail)
            {
                if(data.status==true)
                {
                    parkingSpaceDetail.enabled=data.status
                    parkingSpaceDetail.updatedAt=new Date();
                    parkingSpaceDetail.save();
                    res.send({result:"sucessfully enabaled  parking space"})
                   
                }
                else if(data.status==false)
                {
                    parkingSpaceDetail.enabled=data.status
                    parkingSpaceDetail.updatedAt=new Date();
                    parkingSpaceDetail.save();
                   
                    res.send({result:"sucessfully disabled  parking space"})
                
                }
                else{
                    res.status(400).send({result:"invalid status value"})
                }
            }
            else{
                res.status(400).send({result:"space data not found"})
            }
        }
        else{
        res.status(400).send({result:"send correct data"})
        }
    }
    catch(e)
    {
        res.status(400).send({result:"something went wrong"});
    }
}
async addParkingSpace(req,res) {
    try{

        function generateAvailabity(parkingSpace)
        {
            
         var spaceAvailabityRecord=[]
         var today=new Date();
        
         for( var i=0;i<=7;i++)
         {
            const nextDate = new Date(today);
            nextDate.setDate(today.getDate() + i);
            const year = nextDate.getFullYear();
            const month = String(nextDate.getMonth() + 1).padStart(2, '0'); 
            const day = String(nextDate.getDate()).padStart(2, '0'); 
        
            const dateString = `${year}-${month}-${day}`;
            spaceAvailabityRecord.push({date:dateString,space_id:parkingSpace.id})
            
         }
         return spaceAvailabityRecord
        }
        
      var data=req.body;
        if(data)
        {

            var parkingSpaceDetail=await db.parkingSpace.findOne({
                where:{space_no:data.space_no,}
                })
    
           if(parkingSpaceDetail)
           {
               res.status(400).send({result:"parking space number exists!"})
           }
           else
            {
                await db.parkingSpace.create(data).then(async(parkingSpace)=>{
                    
                    var spaceAvailabilityRecord=await generateAvailabity(parkingSpace)
                    await db.spaceAvailability.bulkCreate(spaceAvailabilityRecord)

                     res.send(parkingSpace)
                  })    
           }
        }
        else{
        res.status(400).send({result:"send correct data"})
        }
    }
    catch(e)
    {
        console.log(e)
        res.status(400).send({result:"something went wrong"});
    }
}


async editParkingSpace(req,res) {
    try{
        var data=req.body;
        if(data)
        {
            var parkingSpaceDetail=await db.parkingSpace.findOne({
                where:{id:data.id,}
                })
            if(parkingSpaceDetail)
            {
             
                parkingSpaceDetail.type=data.type
                parkingSpaceDetail.space_no=data.space_no
                parkingSpaceDetail.save();
                console.log(parkingSpaceDetail)
                res.send(parkingSpaceDetail);
            }
            else{
                res.status(400).send({result:"parking space not found"})
            }
          
        }
        else{
            res.status(400).send({result:"send the required data"})
        }
    }
    catch(e)
    {
        res.status(400).send({result:"something went wrong"});
    }
}

async vehicleEntryOffline (req, res) {
    try{
        var entryData = req.body;
        console.log(typeof(entryData));
        console.log(entryData);
        const now = new Date();

        const timeslot = now.getHours() > 12 ? (now.getHours() - 12)+ "PM": (now.getHours()+1)+"AM";

            var isParkingTypeAvailable = await db.parkingSpace.findAll({
                attributes: ["id", "space_no"],
                where: {
                    type: entryData.type,
                    enabled: true
                }
            })
    
            if (isParkingTypeAvailable.length !== 0) {
                console.log(isParkingTypeAvailable)
                var isAvailable = await db.spaceAvailability.findOne({
                    attributes: ["id","space_id",],
                    where: {
                        date:  now,
                        space_id: isParkingTypeAvailable.map(isavail => isavail.id),
                        [timeslot]: 1
                    }
                    })
                    console.log(typeof(isAvailable))
                    console.log(isAvailable)
                    console.log(!isAvailable)

                if (isAvailable) {
                    console.log("Is available",isAvailable)
    
                    const offlineTableData = {
                        license_no: entryData.license_no,
                        space_id: isAvailable.space_id,
                    }
    
                    //parking table

    
    
                    // 
                    console.log("timeslot: ",timeslot);
                    await db.offlineEntry.create(offlineTableData)
                    .then(async (resp)=>{
                        console.log(" id :"+resp.id);
                        const parkingTableData = {
                            entry_time: now,
                            method: 'offline',
                            offline_id: res.id, //only for offline entry
                        }
                        await db.parking.create(parkingTableData).then(
                            async (response)=>{
                                console.log(response)
                            console.log(isAvailable.id)
                            await db.spaceAvailability.update({[timeslot]: 0},{ where: {id: isAvailable.id, date: now}}).then((res)=>console.log(res));
                            res.send(response)
                        }
                        );
                    });
                } else {
                    console.log("Not found", isAvailable)
                    res.status(500).send({message: "Sorry, Parking is full."})
                }
            } else {
                console.log("Not found", isParkingTypeAvailable)
                    res.status(500).send({message: "Sorry, Parking is full."})
            }
    }
        // vehicle type: 2
        // contact number: 10 digit
        // }
        // get the licence Number, vehicle type, and contact number from client
        // check the spaceAvailability and aquire it
        //parking, offline entry, payment, parking space, reservation table
        
    catch(e) {
        console.log("Error", e);
        res.status(500).send({message: "error encountered", error: e})
    }
}

async vehicleEntryReservation (req, res) {
    const now = new Date();
    try {

        const reserveId = req.body;
        console.log(reserveId);
        
        var reservationDetails = await db.reservations.findOne({where:{id:reserveId.reservationId,[Op.and]: [{reservation_entry_time: {[Op.lte]: now}}, {reservation_exit_time: {[Op.gte]: now}}]} })
        console.log("Today: ",reservationDetails);
        // var reservationDetails = await db.reservations.findOne({where:{id:reserveId.reservationId}})
        if(reservationDetails) {
            console.log(reservationDetails)
            const parkingData = {
                entry_time: now,
                method: 'reservation',
                reservation_id: reservationDetails.id,
            }
            await db.parking.create(parkingData).then((response)=>
                {
                    console.log("data created: ", response)
                    res.send({reservationDetails, response})
                });
        } else {
            console.log("Error");
            console.log(reservationDetails)
            res.status(500).send({message: "Reservation Id/time is wrong, please try again"});
        }
    } catch(e) {
        console.log(e);
        res.status(500).send({message: "Something went wrong, please try again."});
    }
}

async generateOrder(req, res) {
    try {
        
    
    const now = new Date();

    const exitData = req.body;
    console.log(exitData);
    console.log(exitData.license_no);

    var parkingExit = await db.parking.findOne({where:{id: exitData.id}})
        console.log(parkingExit)
    if (parkingExit) {
        var licenceNo = await db.offlineEntry.findOne({where:{id: parkingExit.offline_id, license_no: exitData.license_no}})
        if (licenceNo) {
            console.log(licenceNo)

        const time_diff = Math.floor((now - parkingExit.entry_time)/(1000 * 60 * 60))
        console.log("diff:", time_diff)
        console.log("Table: ", parkingExit.entry_time)
        console.log("now: ", now)
        let amount = 0;
        if (exitData.type == 2)  {
            amount = 50;
        }  else {
            amount = 100;
        }
        const parkingPrice = await db.parkingPrice.findOne({ where: { type: exitData.type } });
        if (time_diff > 0) {
            amount = time_diff * parkingPrice.price;
        }
        
        console.log(amount)

        const razorpayInstance = new Razorpay({
            key_id: 'rzp_test_QnZqng7pQVvf4L',        
            key_secret: 'mzH81EeTbtuMtDu8wNXfpecd'
            
        });

        const options = {
            amount: amount*100, 
            currency: "INR",
            payment_capture: 1 
        };
    
        console.log("Order option: ",options)
        const order = await razorpayInstance.orders.create(options);
        console.log(order)
        res.send({parkingExit,order, time: time_diff});
    } else {
        res.status(500).send({message: "Vehicle No is incorrect, please try again"})
    }

    } else {
        res.status(500).send({message: "Parking not found, please try again"})
    }
} catch (error) {
    console.log(error)
    res.status(500).send({message: "Something went wrong, please try again"})
}

}

async vehicleExitOffline (req, res) {
    const now = new Date(); 
    try {
        
        // in front end call payment gatway and recive payment
        //Update payment
        const data = req.body;
        console.log(data)
        const orderDetails = data.order
        console.log("Hi: ",orderDetails.amount)
        // console.log(data.response)


        const paymentObject = {
            amount: orderDetails.order.amount,
            date: now,
            paymentDetail: data.res,
        }

        console.log(paymentObject)
            await db.payments.create(paymentObject).then(async (res)=> {console.log(res)
            // update offline table
            await db.offlineEntry.update({payment_id: res.id}, {where: {id: orderDetails.parkingExit.id}}).then((res)=>console.log(res))
            await db.parking.update({exit_time: now},{where: {id: orderDetails.parkingExit.id}}).then((res)=>console.log(res))
        })
            // update parking table
            // res.send(vehicleExit);
            res.send({message: "Payment is completed. Thank you."})


    } catch(e) {
        console.log(e)
        res.status(500).send({message:"Something went wrong, please try again."})
    }
}

async reservationExitOrderGeneration (req, res) {
    try {
        const now = new Date();
        const reserveId = req.body.reservationId;
        const type = req.body.vehicleType
        console.log("Hi")
        console.log(now)
        console.log(reserveId);
        console.log(req.body);

        var reservationDetails = await db.reservations.findOne({where:{id:reserveId}})
        if(reservationDetails) {
            console.log(reservationDetails);
            var parkingDetails = await db.parking.findOne({where: {reservation_id: reserveId}});
            console.log(parkingDetails);
            if (parkingDetails) {
                console.log("Hi")
                const reserved_hours = (reservationDetails.reservation_exit_time - reservationDetails.reservation_entry_time) / (1000 * 60 * 60);
                const parked_hours = (now - parkingDetails.entry_time) / (1000 * 60 * 60);
                console.log(reserved_hours, " : ", parked_hours)
                const parkingPrice = await db.parkingPrice.findOne({ where: { type: type } });
                if (reserved_hours < parked_hours) {
                    const diff = parked_hours - reserved_hours;
                    // calculate the amount
                    const diff_amount = diff * parkingPrice.price;
                    console.log(diff, " : ", diff_amount)

                    // generate payment order
                    const razorpayInstance = new Razorpay({
                        key_id: 'rzp_test_QnZqng7pQVvf4L',        
                        key_secret: 'mzH81EeTbtuMtDu8wNXfpecd'
                        
                    });
                    
                    const options = {
                        amount: Math.round(diff_amount*100), 
                        currency: "INR",
                        payment_capture: 1 
                    };
                    console.log(options)
                    const order = await razorpayInstance.orders.create(options);
                    console.log(order)
                    res.send({payment: true,reservationDetails, parkingDetails,order});
                } else {
                    await db.parking.update({exit_time: now}, {where: {id: parkingDetails.id}});
                    res.send({payment: false,message: "Parking updated"});
                }
            } else {
                res.status(500).send({message: "parking not found"})
            }
        } else {
            console.log("Error");
            console.log(reservationDetails)
            res.status(500).send({message: "Not reserved"});
        }
    } catch (error) {
        res.status(500).send({message: "Error", error: error})
    }
}
async vehicleExitReservation (req, res) {
    try {
        const exitData =req.body.data
        console.log(exitData)
        console.log(exitData)
        console.log(typeof(exitData));
        console.log(exitData.reservationDetails);
        console.log(exitData.parkingDetails);
        console.log(exitData.order);
        const reservationDetails = exitData.reservationDetails;
        const parkingDetails = exitData.parkingDetails;
        const order = exitData.order;
        const payment = req.body.payment;
        console.log(payment)
        const now = new Date();
        // payment entry
        const paymentData = {
            amount: order.amount,
            date: now,
            paymentDetail: payment,
        }
        var paymentEntry = await db.payments.create(paymentData);
        // offline entry
        const vehicle= await db.vehicleDetails.findOne(
            {
                where: {
                    id: reservationDetails.vehicle_id
                }
            }
        )
        console.log(vehicle)
        const offlineData = {
            license_no: vehicle.licenceNo,
            space_id: reservationDetails.space_id,
            payment_id: paymentEntry.id,
        }
        var offlineEntry = await db.offlineEntry.create(offlineData);

        // parking update

        var parkingUpdate = await db.parking.update({exit_time: now, offline_id: offlineEntry.id}, {where: {id: parkingDetails.id}});
        // res.send({message: "Parking updated"});
        // await db.parking.update({},{where:{id: exitData.id}})
        res.send(parkingUpdate)
    } catch (error) {
        console.log(error);
        res.status(500).send({message: "Error occured", error: error})
    }
}
 async  getPrices(req,res)
 {
    try{
            var prices=await db.parkingPrice.findAll({})
        console.log(prices)
            res.send(prices);
    }
    catch(e)
    {
        res.status(500).send({message:"something went wrong"})
    }
 }


 async  updatePrices(req,res)
 {
    try{
        var data=req.body
        if(data)
        {
            var updatedprice= await db.parkingPrice.findOne({where:{id:data.id}})
            if(updatedprice)
            {
            console.log(updatedprice)
            updatedprice.price=data.price;
            await updatedprice.save();
            res.send(updatedprice);
            }
            else{
                res.status(500).send({message:"something went wrong"})
            }
        }
        else{
            res.status(500).send({message:"something went wrong"})
        }
    }
    catch(e)
    {
        console.log(e)
        res.status(500).send({message:"something went wrong"})
    }
 }


  async getparking(req,res)
  {
 try{
    const today = new Date();
    var data=[];
    var parkingDteail=await db.parking.findAll({})   
    console.log(parkingDteail)
    for(var parkingobj of parkingDteail)
        {
            var obj={};
            obj.entry_datetime=parkingobj.entry_time
            obj.exit_datetime=parkingobj.exit_time
            obj.id=parkingobj.id;
            obj.method=parkingobj.method;
            if(parkingobj.method=="reservation")
            {  var reservationDetail=await db.reservations.findOne({where:{id:parkingobj.reservation_id}})
                obj.subTableId= await parkingobj.reservation_id;
                if(reservationDetail)
                {
                var space= await db.parkingSpace.findOne({where:{id:reservationDetail.space_id}})
                var vehicle= await db.vehicleDetails.findOne({where:{id:reservationDetail.vehicle_id}})
                obj.space_id= await space.space_no;
                obj.vehicleType=await space.type;
                obj.licence_no= await vehicle.licenceNo;
              
               }

                
            }
            else if(parkingobj.method=="offline")
            {
                var offlineDetail=await db.offlineEntry.findOne({where:{id:parkingobj.offline_id}})
                obj.subTableId= await parkingobj.offline_id;
                if(offlineDetail)
                {
                var space= await db.parkingSpace.findOne({where:{id:offlineDetail.space_id}})
            
                obj.space_id= await space.space_no;
                obj.vehicleType=await space.type;
                obj.licence_no= await offlineDetail.license_no;
              
               }
        }
        data.push(obj)
        
    }
    console.log(data)
    res.send(data)
 }
    
 catch(e)
 {res.status.send({message:"something went wrong"})

 }
 
  }

  async getReservationData(req,res)
  {
 try{
    var data=[]
    const today = new Date();
   
    var reservationDteail=await db.reservations.findAll({})

    for(var reservationDteailobj of reservationDteail)
    {
       var space= await db.parkingSpace.findOne({where:{id:reservationDteailobj.space_id}})
       var vehicle= await db.vehicleDetails.findOne({where:{id:reservationDteailobj.vehicle_id}})
       reservationDteailobj.space_id= await space.space_no;
       reservationDteailobj.vehicle_id= await vehicle.licenceNo;
        data.push(reservationDteailobj)
    }
    res.send(data)
 }
    
 catch(e)
 {res.status.send({message:"something went wrong"})

 }
}
}