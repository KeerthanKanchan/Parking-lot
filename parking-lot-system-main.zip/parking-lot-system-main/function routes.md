common function

address "common/login"
method: post
data:{userName:"email or phone number",password:password}
returned data: {email:"email",phone_no:"123",use_role:"role"}
content-type: application/json



customer functions





admin functions
